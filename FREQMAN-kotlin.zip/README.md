# FREQMAN

**Frequency Manager**: aplikasi radio internet untuk Android (Kotlin + Media3 ExoPlayer) dengan tampilan web yang juga bisa dipasang sebagai situs.

Dikembangkan oleh Nur Mukhammad Agus. © 2026 FREQMAN. All Rights Reserved.

## Isi repository

| Folder | Isi |
|---|---|
| `app/src/main/kotlin/` | Kode Android (Kotlin): `MainActivity` (WebView + jembatan JS), `PlaybackService` (ExoPlayer, notifikasi, layar kunci, timer tidur), `FreqManWidget`, `Artwork` |
| `app/src/main/assets/www/` | Tampilan aplikasi (HTML, CSS, JS hasil gabungan, font, lisensi) |
| `web-src/` | Sumber JavaScript yang dipecah per bagian + `build.sh` untuk menggabungkannya |
| `tests/` | Tes otomatis tampilan: `cd tests && npm install && npm test` |
| `.github/workflows/build.yml` | Build APK & AAB otomatis di GitHub Actions |

## Build otomatis (GitHub Actions)

Setiap push ke `main` membuat APK dan AAB yang ditandatangani, lalu menerbitkannya di halaman **Releases**.

Secrets yang dibutuhkan (Settings → Secrets and variables → Actions):

| Nama | Isi |
|---|---|
| `KEYSTORE_BASE64` | isi keystore dalam bentuk base64 |
| `KEYSTORE_PASSWORD` | kata sandi keystore |
| `KEY_ALIAS` | alias kunci (`freqman`) |
| `KEY_PASSWORD` | kata sandi kunci |

**Jangan pernah mengunggah file keystore (`.jks`) atau kata sandinya ke repository ini (repository publik).**

## Memperbarui dari HP

Unggah `FREQMAN-kotlin.zip` ke akar repository (Add file → Upload files). Workflow akan mengekstraknya, menyimpan isinya ke repository, lalu membuat APK baru.

## Sumber data & lisensi

Daftar stasiun dari [Radio Browser](https://www.radio-browser.info) (data domain publik). Komponen pihak ketiga: Media3 ExoPlayer (Apache 2.0), shadcn/ui (MIT), Geist & Orbitron (SIL OFL 1.1), Lucide (ISC), hls.js (Apache 2.0). Teks lisensinya ada di `app/src/main/assets/www/licenses/`.
