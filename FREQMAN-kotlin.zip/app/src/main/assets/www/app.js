/* FreqMan — Frequency Manager
 * Katalog: Radio Browser API (https://api.radio-browser.info), publik & gratis.
 * Dipakai bersama oleh versi web dan aplikasi Android (WebView).
 */
(function () {
  'use strict';

  // ================================================================== PENGATURAN
  // Isi email kontak untuk pemilik stasiun yang ingin stasiunnya dihapus dari FREQMAN.
  // Selama kosong, halaman "Tentang" hanya menampilkan nama pengembang tanpa tombol email.
  var CONTACT_EMAIL = 'madfxr@protonmail.com';
  // Opsional: alamat blocklist.json yang di-hosting online (mis. di server versi web),
  // agar stasiun bisa disembunyikan tanpa merilis APK baru. Server harus mengizinkan CORS.
  var BLOCKLIST_URL = '';
  var DEVELOPER = 'Nur Mukhammad Agus';
  var APP_VERSION = '1.0';

  // ------------------------------------------------------------------ Teks ID / EN
  var I18N = {
    id: {
      locale: 'id-ID',
      stations: function (n) { return n + ' di Katalog'; },
      loadingCatalog: 'Memuat Katalog',
      switchLanguage: 'Bahasa tampilan',
      themeToDark: 'Ganti ke mode gelap',
      themeToLight: 'Ganti ke mode terang',
      heroTitle: 'Dengarkan Radio',
      heroSubtitle: 'Pilih negara, cari stasiun, lalu ketuk untuk memutar.',
      worldwide: 'Seluruh Dunia',
      changeCountry: 'Ganti negara',
      searchPlaceholder: 'Cari Stasiun, Genre, atau Kota…',
      clearSearch: 'Hapus pencarian',
      tabBrowse: 'Jelajahi',
      tabFavorites: 'Favorit',
      tabHistory: 'Riwayat',
      sortGroup: 'Urutkan',
      sorts: { popular: 'Terpopuler', name: 'Nama A–Z', city: 'Kota A–Z', hq: 'HQ' },
      unknownLocation: 'Lokasi tidak diketahui',
      saveFavorite: 'Simpan ke favorit',
      removeFavorite: 'Hapus dari favorit',
      savedToFavorites: 'Disimpan ke Favorit',
      removedFromFavorites: 'Dihapus dari Favorit',
      refreshing: 'Memperbarui…',
      loadingMore: 'Memuat stasiun lain…',
      loadMoreFailed: 'Gagal memuat. Coba Lagi',
      live: 'Live',
      liveBroadcast: 'Siaran langsung',
      play: 'Putar',
      pause: 'Jeda',
      closePlayer: 'Tutup pemutar',
      playbackFailedTitle: 'Gagal Memutar Siaran',
      playbackFailedDesc: 'Siaran ini sedang tidak bisa diputar. Coba stasiun lain.',
      emptyFavTitle: 'Belum Ada Favorit',
      emptyFavDesc: 'Ketuk ikon hati di samping stasiun untuk menyimpannya di sini.',
      browseStations: 'Jelajahi Stasiun',
      errorTitle: 'Katalog Tidak Bisa Dimuat',
      errorDesc: 'Periksa koneksi internet, lalu coba lagi.',
      retry: 'Coba Lagi',
      notFoundTitle: 'Stasiun tidak ditemukan',
      notFoundDesc: function (q, c) { return 'Tidak ada stasiun, genre, atau kota “' + q + '” di ' + c + '. Coba kata lain atau ganti negara.'; },
      noStationsTitle: 'Belum ada stasiun',
      noStationsDesc: function (c) { return 'Katalog belum punya stasiun aktif untuk ' + c + '.'; },
      pickOtherCountry: 'Pilih negara lain',
      pickCountryTitle: 'Pilih Negara',
      pickCountryDesc: 'Daftar stasiun akan menyesuaikan negara yang kamu pilih.',
      searchCountry: 'Cari Negara…',
      loadingCountries: 'Memuat daftar negara…',
      countryNotFound: 'Negara tidak ditemukan.',
      groupGeneral: 'Umum',
      groupCountries: 'Negara',
      failedLastTime: 'Terakhir Gagal',
      hqEmptyTitle: 'Belum Ada Stasiun Kualitas Tinggi',
      hqEmptyDesc: function (c) { return 'Tidak ada stasiun 256 kbps ke atas atau lossless di ' + c + '.'; },
      showAll: 'Tampilkan Semua Stasiun',
      emptyHistTitle: 'Belum Ada Riwayat',
      emptyHistDesc: 'Stasiun yang pernah kamu putar akan muncul di sini.',
      clearHistory: 'Hapus Riwayat',
      historyCleared: 'Riwayat Dihapus',
      openPlayer: 'Buka pemutar',
      nowPlayingTitle: 'Sedang Diputar',
      sleepTimer: 'Timer Tidur',
      sleepOff: 'Mati',
      sleepMin: function (n) { return n + ' mnt'; },
      sleepLeft: function (t) { return 'Radio berhenti dalam ' + t; },
      sleepIdle: 'Radio berhenti otomatis setelah waktu yang dipilih.',
      sleepSetTitle: 'Timer Tidur Aktif',
      sleepSetDesc: function (n) { return 'Radio berhenti dalam ' + n + ' menit.'; },
      sleepEndTitle: 'Timer Tidur Selesai',
      sleepEndDesc: 'Radio dihentikan.',
      offlineTitle: 'Koneksi Terputus',
      offlineDesc: 'Siaran tersambung lagi otomatis saat internet kembali.',
      aboutOpen: 'Tentang & Lisensi',
      aboutTitle: 'Tentang & Lisensi',
      version: 'Versi',
      developedBy: 'Dikembangkan oleh',
      statementTitle: 'Pernyataan',
      statement1: 'FREQMAN adalah direktori dan pemutar radio internet. FREQMAN tidak menyimpan, merekam, atau memancarkan ulang siaran apa pun, karena audio diputar langsung dari server milik masing-masing stasiun.',
      statement2: 'Seluruh siaran, nama, dan logo stasiun adalah milik pemiliknya masing-masing. Pencantuman stasiun di FREQMAN tidak berarti ada kerja sama atau dukungan dari stasiun tersebut.',
      sourceTitle: 'Sumber Data',
      source1: 'Daftar stasiun berasal dari Radio Browser, katalog radio terbuka yang dikelola komunitas dengan lisensi data domain publik:',
      ownersTitle: 'Untuk Pemilik Stasiun',
      owners1: 'Ingin stasiun Anda dihapus dari FREQMAN, atau datanya diperbaiki? Kirim permintaan beserta nama stasiun Anda, dan stasiun akan disembunyikan dari aplikasi.',
      ownersContact: 'Hubungi pengembang:',
      ownersMailSubject: 'Permintaan penghapusan stasiun dari FREQMAN',
      ownersFix: 'Perbaikan data stasiun (nama, logo, genre) juga bisa diajukan langsung di',
      privacyTitle: 'Privasi',
      privacy1: 'FREQMAN tidak mengumpulkan data pribadi dan tidak memerlukan akun. Favorit, bahasa, tema, dan negara pilihan hanya tersimpan di perangkat ini.',
      privacy2: 'Saat stasiun diputar, aplikasi mengirim satu hitungan anonim ke Radio Browser untuk peringkat popularitas, dan perangkat Anda tersambung langsung ke server stasiun tersebut.',
      licensesTitle: 'Lisensi Pihak Ketiga',
      licensesIntro: 'FREQMAN memakai komponen sumber terbuka berikut. Ketuk untuk membaca lisensinya.',
      licenseLoading: 'Memuat…'
    },
    en: {
      locale: 'en-US',
      stations: function (n) { return n + ' in Catalog'; },
      loadingCatalog: 'Loading Catalog',
      switchLanguage: 'Display language',
      themeToDark: 'Switch to dark mode',
      themeToLight: 'Switch to light mode',
      heroTitle: 'Listen to Radio',
      heroSubtitle: 'Pick a country, search for a station, then tap to play.',
      worldwide: 'Worldwide',
      changeCountry: 'Change country',
      searchPlaceholder: 'Search Station, Genre, or City…',
      clearSearch: 'Clear search',
      tabBrowse: 'Browse',
      tabFavorites: 'Favorites',
      tabHistory: 'Recent',
      sortGroup: 'Sort by',
      sorts: { popular: 'Most Popular', name: 'Name A–Z', city: 'City A–Z', hq: 'HQ' },
      sortsShort: { popular: 'Popular' }, // dipakai di layar < 400 px agar tidak terpotong
      unknownLocation: 'Unknown location',
      saveFavorite: 'Save to favorites',
      removeFavorite: 'Remove from favorites',
      savedToFavorites: 'Saved to Favorites',
      removedFromFavorites: 'Removed from Favorites',
      refreshing: 'Refreshing…',
      loadingMore: 'Loading more stations…',
      loadMoreFailed: 'Couldn’t load. Try Again',
      live: 'Live',
      liveBroadcast: 'Live broadcast',
      play: 'Play',
      pause: 'Pause',
      closePlayer: 'Close player',
      playbackFailedTitle: 'Couldn’t Play This Station',
      playbackFailedDesc: 'This stream is unavailable right now. Try another station.',
      emptyFavTitle: 'No Favorites Yet',
      emptyFavDesc: 'Tap the heart next to a station to save it here.',
      browseStations: 'Browse Stations',
      errorTitle: 'Couldn’t Load the Catalog',
      errorDesc: 'Check your internet connection, then try again.',
      retry: 'Try Again',
      notFoundTitle: 'No stations found',
      notFoundDesc: function (q, c) { return 'No station, genre, or city matching “' + q + '” in ' + c + '. Try another word or change the country.'; },
      noStationsTitle: 'No stations yet',
      noStationsDesc: function (c) { return 'The catalog has no active stations for ' + c + ' yet.'; },
      pickOtherCountry: 'Pick another country',
      pickCountryTitle: 'Choose a Country',
      pickCountryDesc: 'The station list follows the country you choose.',
      searchCountry: 'Search Countries…',
      loadingCountries: 'Loading countries…',
      countryNotFound: 'No country found.',
      groupGeneral: 'General',
      groupCountries: 'Countries',
      failedLastTime: 'Failed Last Time',
      hqEmptyTitle: 'No High-Quality Stations',
      hqEmptyDesc: function (c) { return 'No stations at 256 kbps and up, or lossless, in ' + c + '.'; },
      showAll: 'Show All Stations',
      emptyHistTitle: 'No Recent Stations',
      emptyHistDesc: 'Stations you play will appear here.',
      clearHistory: 'Clear History',
      historyCleared: 'History Cleared',
      openPlayer: 'Open player',
      nowPlayingTitle: 'Now Playing',
      sleepTimer: 'Sleep Timer',
      sleepOff: 'Off',
      sleepMin: function (n) { return n + ' min'; },
      sleepLeft: function (t) { return 'Radio stops in ' + t; },
      sleepIdle: 'The radio stops automatically after the chosen time.',
      sleepSetTitle: 'Sleep Timer On',
      sleepSetDesc: function (n) { return 'The radio stops in ' + n + ' minutes.'; },
      sleepEndTitle: 'Sleep Timer Ended',
      sleepEndDesc: 'The radio has been stopped.',
      offlineTitle: 'Connection Lost',
      offlineDesc: 'The broadcast reconnects automatically when the internet is back.',
      aboutOpen: 'About & Licenses',
      aboutTitle: 'About & Licenses',
      version: 'Version',
      developedBy: 'Developed by',
      statementTitle: 'Statement',
      statement1: 'FREQMAN is an internet radio directory and player. FREQMAN does not store, record, or rebroadcast any broadcast, as audio is played directly from each station’s own server.',
      statement2: 'All broadcasts, station names, and logos belong to their respective owners. Listing a station in FREQMAN does not imply any partnership with or endorsement by that station.',
      sourceTitle: 'Data Source',
      source1: 'The station list comes from Radio Browser, a community-run open radio catalog whose data is in the public domain:',
      ownersTitle: 'For Station Owners',
      owners1: 'Want your station removed from FREQMAN, or its details corrected? Send a request with your station name and it will be hidden from the app.',
      ownersContact: 'Contact the developer:',
      ownersMailSubject: 'Station removal request for FREQMAN',
      ownersFix: 'Station details (name, logo, genre) can also be corrected directly at',
      privacyTitle: 'Privacy',
      privacy1: 'FREQMAN collects no personal data and needs no account. Favorites, language, theme, and chosen country are stored only on this device.',
      privacy2: 'When a station plays, the app sends one anonymous count to Radio Browser for popularity rankings, and your device connects directly to that station’s server.',
      licensesTitle: 'Third-Party Licenses',
      licensesIntro: 'FREQMAN uses the following open-source components. Tap to read each license.',
      licenseLoading: 'Loading…'
    }
  };

  // ------------------------------------------------------------------ Ikon (Lucide, ISC)
  var ICON = {
    history: '<path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l4 2"/>',
    clock: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
    heart: '<path d="M2 9.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5l-5.492 5.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5"/>',
    play: '<path d="M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z"/>',
    pause: '<rect x="14" y="3" width="5" height="18" rx="1"/><rect x="5" y="3" width="5" height="18" rx="1"/>',
    loader: '<path d="M21 12a9 9 0 1 1-6.219-8.56"/>',
    check: '<path d="M20 6 9 17l-5-5"/>',
    circleCheck: '<circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/>',
    alert: '<circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/>',
    heartOff: '<path d="M10.5 4.893a5.5 5.5 0 0 1 1.091.931.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5c0 1.872-1.002 3.356-2.187 4.655"/><path d="m16.967 16.967-3.459 3.346a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5a5.5 5.5 0 0 1 2.747-4.761"/><path d="m2 2 20 20"/>',
    wifiOff: '<path d="M12 20h.01"/><path d="M8.5 16.429a5 5 0 0 1 7 0"/><path d="M5 12.859a10 10 0 0 1 5.17-2.69"/><path d="M19 12.859a10 10 0 0 0-2.007-1.523"/><path d="M2 8.82a15 15 0 0 1 4.177-2.643"/><path d="M22 8.82a15 15 0 0 0-11.288-3.764"/><path d="m2 2 20 20"/>',
    searchX: '<path d="m13.5 8.5-5 5"/><path d="m8.5 8.5 5 5"/><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
    tower: '<path d="M4.9 16.1C1 12.2 1 5.8 4.9 1.9"/><path d="M7.8 4.7a6.14 6.14 0 0 0-.8 7.5"/><circle cx="12" cy="9" r="2"/><path d="M16.2 4.8c2 2 2.26 5.11.8 7.47"/><path d="M19.1 1.9a9.96 9.96 0 0 1 0 14.1"/><path d="M9.5 18h5"/><path d="m8 22 4-11 4 11"/>'
  };
  function svg(name, size, opts) {
    opts = opts || {};
    return '<svg width="' + (size || 16) + '" height="' + (size || 16) + '" viewBox="0 0 24 24" fill="' + (opts.fill ? 'currentColor' : 'none') +
      '" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"' +
      (opts.cls ? ' class="' + opts.cls + '"' : '') + '>' + ICON[name] + '</svg>';
  }

  // ------------------------------------------------------------------ Util
  function $(id) { return document.getElementById(id); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  var store = {
    get: function (k, d) { try { var v = localStorage.getItem('freqman:' + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem('freqman:' + k, JSON.stringify(v)); } catch (e) { /* penyimpanan penuh/nonaktif */ } }
  };

  var navLang = (navigator.language || 'en').toLowerCase();
  var navRegion = ((navigator.language || '').split('-')[1] || '').toUpperCase();
  var isIndonesian = navLang.indexOf('id') === 0 || navLang.indexOf('in') === 0;
  var savedCountry = store.get('country', null);

  var state = {
    lang: store.get('lang', isIndonesian ? 'id' : 'en'),
    country: savedCountry !== null ? savedCountry : (/^[A-Z]{2}$/.test(navRegion) ? navRegion : (isIndonesian ? 'ID' : '')),
    query: '',
    sort: 'popular',
    tab: 'browse',
    stations: [],
    offset: 0,
    loading: false,
    loadingMore: false,
    endReached: false,
    error: false,
    countries: [],
    countriesLoading: false,
    countryFilter: '',
    favorites: store.get('favs', []),
    history: store.get('history', []),
    nowTitle: '',        // judul lagu dari stasiun (bila dikirim)
    sleepEnd: 0,         // waktu timer tidur berakhir (0 = mati)
    waitingNetwork: false,
    current: null,
    playing: false,
    buffering: false
  };
  if (I18N[state.lang] === undefined) state.lang = 'id';
  function T() { return I18N[state.lang]; }

  function fmt(n) { try { return new Intl.NumberFormat(T().locale).format(n); } catch (e) { return String(n); } }
  var displayNames = {};
  function countryName(code, fallback) {
    if (!code) return T().worldwide;
    try {
      if (!displayNames[state.lang]) displayNames[state.lang] = new Intl.DisplayNames([T().locale], { type: 'region' });
      var n = displayNames[state.lang].of(code);
      if (n && n !== code) return n;
    } catch (e) { /* browser lama */ }
    return fallback || code;
  }

  // ------------------------------------------------------------------ Radio Browser API
  var FALLBACK_SERVERS = ['de1.api.radio-browser.info', 'de2.api.radio-browser.info', 'fi1.api.radio-browser.info'];
  // Langsung pakai alamat utama (round-robin DNS) + cadangan; daftar server lengkap
  // diambil di belakang layar tanpa menunda pencarian pertama.
  var hostList = ['all.api.radio-browser.info'].concat(FALLBACK_SERVERS);
  var API_TIMEOUT_MS = 6000; // server yang macet dilewati setelah 6 detik
  fetchWithTimeout('https://all.api.radio-browser.info/json/servers', null, API_TIMEOUT_MS)
    .then(function (r) { return r.ok ? r.json() : []; })
    .then(function (list) {
      (list || []).forEach(function (sv) { if (sv && sv.name && hostList.indexOf(sv.name) < 0) hostList.push(sv.name); });
    })
    .catch(function () { /* tetap pakai daftar cadangan */ });

  function fetchWithTimeout(url, outerSignal, ms) {
    if (typeof AbortController === 'undefined') return fetch(url);
    var ctrl = new AbortController();
    var timedOut = false;
    var timer = setTimeout(function () { timedOut = true; ctrl.abort(); }, ms);
    var onOuterAbort = function () { ctrl.abort(); };
    if (outerSignal) {
      if (outerSignal.aborted) ctrl.abort();
      else outerSignal.addEventListener('abort', onOuterAbort);
    }
    return fetch(url, { signal: ctrl.signal })
      .then(function (r) { return r; }, function (e) {
        if (timedOut) { var te = new Error('timeout'); te.name = 'TimeoutError'; throw te; }
        throw e; // AbortError dari pemanggil diteruskan apa adanya
      })
      .then(function (r) { clearTimeout(timer); if (outerSignal) outerSignal.removeEventListener('abort', onOuterAbort); return r; },
        function (e) { clearTimeout(timer); if (outerSignal) outerSignal.removeEventListener('abort', onOuterAbort); throw e; });
  }

  function api(path, signal) {
    var hosts = hostList.slice();
    var i = 0;
    function attempt(lastErr) {
      if (signal && signal.aborted) { var ae = new Error('aborted'); ae.name = 'AbortError'; return Promise.reject(ae); }
      if (i >= hosts.length) return Promise.reject(lastErr || new Error('no server'));
      var host = hosts[i++];
      return fetchWithTimeout('https://' + host + path, signal, API_TIMEOUT_MS)
        .then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
        .catch(function (e) { if (e && e.name === 'AbortError') throw e; return attempt(e); });
    }
    return attempt(null);
  }

  // Format yang tidak bisa diputar di HP maupun browser (WMA, RealAudio, protokol mms/rtsp/rtmp)
  // disembunyikan dari daftar, supaya tidak muncul lalu gagal saat diketuk.
  var UNSUPPORTED_CODEC = /^(wma|wmav1|wmav2|wmapro|asf|ra|rm|real|realaudio)$/i;
  var UNSUPPORTED_URL = /^(mms|mmsh|mmst|rtsp|rtmp|rtmps|pnm):/i;
  var UNSUPPORTED_EXT = /\.(wma|wax|wvx|ram|rm|ra)(\?|$)/i;
  function isPlayable(s) {
    var urls = [s.url_resolved, s.url].map(function (u) { return String(u || '').trim(); }).filter(Boolean);
    var codec = String(s.codec || '').trim();
    if (UNSUPPORTED_CODEC.test(codec)) return false;
    return urls.some(function (u) { return /^https?:\/\//i.test(u) && !UNSUPPORTED_EXT.test(u); }) &&
      !urls.every(function (u) { return UNSUPPORTED_URL.test(u); });
  }

  // ---- Stasiun yang terakhir gagal diputar (disimpan di HP ini, kedaluwarsa 24 jam)
  var FAIL_TTL = 24 * 60 * 60 * 1000;
  var fails = store.get('fails', {});
  (function pruneFails() {
    var now = Date.now(), keys = Object.keys(fails);
    keys.forEach(function (k) { if (!(now - fails[k] < FAIL_TTL)) delete fails[k]; });
    keys = Object.keys(fails).sort(function (a, b) { return fails[b] - fails[a]; });
    keys.slice(500).forEach(function (k) { delete fails[k]; }); // batasi ukuran
    store.set('fails', fails);
  })();
  function hasFailed(s) { var t = s && fails[s.stationuuid]; return !!t && Date.now() - t < FAIL_TTL; }
  function markFailed(s) { if (!s) return; fails[s.stationuuid] = Date.now(); store.set('fails', fails); }
  function markPlayed(s) {
    if (!s) return;
    addHistory(s);
    if (!fails[s.stationuuid]) return;
    delete fails[s.stationuuid]; store.set('fails', fails);
    refreshItems();
  }

  // ---- Riwayat: 30 stasiun terakhir yang berhasil diputar (disimpan di HP ini)
  var HISTORY_MAX = 30;
  function addHistory(s) {
    var item = slim(s);
    state.history = [item].concat(state.history.filter(function (h) { return h.stationuuid !== s.stationuuid; })).slice(0, HISTORY_MAX);
    store.set('history', state.history);
    if (state.tab === 'hist') renderHistory();
  }
  function visibleHistory() { return state.history.filter(function (h) { return !isBlocked(h); }); }

  // ---- Pemeriksaan cepat: hanya stasiun yang servernya menjawab (dalam 5 detik) yang ditampilkan.
  // Koneksi langsung ditutup begitu server menjawab, jadi kuota yang terpakai sangat kecil.
  var PROBE_TIMEOUT = 5000, PROBE_PARALLEL = 8, PROBE_TTL = 6 * 60 * 60 * 1000;
  var probeCache = store.get('probe', {}); // id -> { ok: 1|0, url: alamat yang menjawab, t: waktu }
  (function pruneProbe() {
    var now = Date.now();
    Object.keys(probeCache).forEach(function (k) { if (!(now - probeCache[k].t < PROBE_TTL)) delete probeCache[k]; });
    var keys = Object.keys(probeCache);
    if (keys.length > 3000) {
      keys.sort(function (a, b) { return probeCache[a].t - probeCache[b].t; })
        .slice(0, keys.length - 3000).forEach(function (k) { delete probeCache[k]; });
    }
    store.set('probe', probeCache);
  })();
  var saveProbeTimer = null;
  function saveProbeSoon() {
    clearTimeout(saveProbeTimer);
    saveProbeTimer = setTimeout(function () { store.set('probe', probeCache); }, 600);
  }
  var shownIds = {}; // yang sudah tampil tidak dihilangkan sampai daftar dimuat ulang
  function verdict(s) {
    if (shownIds[s.stationuuid]) return 'ok';
    if (hasFailed(s)) return 'fail';
    var c = probeCache[s.stationuuid];
    if (c && Date.now() - c.t < PROBE_TTL) return c.ok ? 'ok' : 'fail';
    return 'pending';
  }
  function okUrl(s) { var c = probeCache[s.stationuuid]; return c && c.ok ? c.url : ''; }

  function probeOne(url) {
    return new Promise(function (resolve) {
      var ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
      var done = false;
      var timer = setTimeout(function () { if (done) return; done = true; if (ctrl) ctrl.abort(); resolve(false); }, PROBE_TIMEOUT);
      fetch(url, { mode: 'no-cors', cache: 'no-store', credentials: 'omit', referrerPolicy: 'no-referrer', signal: ctrl ? ctrl.signal : undefined })
        .then(function () { if (done) return; done = true; clearTimeout(timer); if (ctrl) ctrl.abort(); resolve(true); },
          function () { if (done) return; done = true; clearTimeout(timer); resolve(false); });
    });
  }
  // Semua alamat stasiun dicoba bersamaan; alamat pertama yang menjawab dipakai saat diputar
  function probeAny(urls) {
    return new Promise(function (resolve) {
      var left = urls.length, settled = false;
      if (!left) { resolve(''); return; }
      urls.forEach(function (u) {
        probeOne(u).then(function (ok) {
          if (settled) return;
          if (ok) { settled = true; resolve(u); return; }
          if (--left === 0) resolve('');
        });
      });
    });
  }
  var probeQueue = [], probeRunning = 0, probeGen = 0, renderSoonTimer = null;
  var HOLD_MS = 1500;          // stasiun lambat hanya menahan yang di bawahnya maksimal 1,5 detik
  // Hemat kuota: hanya stasiun di sekitar layar yang dicek; sisanya dicek saat daftar digulir
  var PROBE_AHEAD = 24, probeHorizon = PROBE_AHEAD;
  function growProbeHorizon() {
    if (probeRunning > 0) return true; // tunggu kelompok yang sedang dicek selesai dulu
    if (!probeQueue.length) return false;
    var nextIdx = stationIndex[probeQueue[0].stationuuid] || 0;
    probeHorizon = Math.max(probeHorizon, nextIdx) + PROBE_AHEAD;
    pumpProbes();
    return true;
  }
  var probeStart = {}, skippedIds = {};
  function renderSoon() {
    if (renderSoonTimer) return;
    renderSoonTimer = setTimeout(function () { renderSoonTimer = null; renderList(); maybeLoadMore(); }, 120);
  }
  function queueProbes(list) {
    list.forEach(function (st) { if (verdict(st) === 'pending') probeQueue.push(st); });
    pumpProbes();
  }
  function pumpProbes() {
    while (probeRunning < PROBE_PARALLEL && probeQueue.length) {
      var idx = stationIndex[probeQueue[0].stationuuid];
      if (idx !== undefined && idx >= probeHorizon) break; // belum dekat layar
      (function (st, gen) {
        probeRunning++;
        probeStart[st.stationuuid] = Date.now();
        probeAny(streamCandidates(st)).then(function (url) {
          probeRunning--;
          probeCache[st.stationuuid] = { ok: url ? 1 : 0, url: url, t: Date.now() };
          // Lolos setelah dilewati: ditambahkan di akhir daftar agar baris lain tidak bergeser
          saveProbeSoon();
          if (gen === probeGen) renderSoon();
          pumpProbes();
        });
      })(probeQueue.shift(), probeGen);
    }
  }
  // Daftar yang tampil: urutan asli dipertahankan, ditampilkan sampai stasiun pertama yang belum selesai diperiksa
  function visibleStations() {
    var out = [], pending = false, now = Date.now();
    for (var i = 0; i < state.stations.length; i++) {
      var st = state.stations[i], id = st.stationuuid;
      if (isBlocked(st)) continue;
      if (skippedIds[id] && !shownIds[id]) {
        // Lambat dicek: tidak menahan yang di bawahnya, tapi bila lolos tampil di posisi urutannya sendiri
        var sv = verdict(st);
        if (sv === 'pending') pending = true;
        else if (sv === 'ok') out.push(st);
        continue;
      }
      var v = verdict(st);
      if (v === 'pending') {
        pending = true;
        var started = probeStart[id];
        if (!started) break; // belum mulai dicek (menunggu giliran / di luar jangkauan layar)
        if (now - started < HOLD_MS) {
          // tahan sebentar, lalu tampilkan ulang saat batas tahan habis
          setTimeout(renderSoon, Math.max(50, HOLD_MS - (started ? now - started : 0)));
          break;
        }
        skippedIds[id] = 1; // terlalu lama: jangan tahan stasiun di bawahnya
        continue;
      }
      if (v === 'ok') out.push(st);
    }
    return { list: out, pending: pending };
  }

  // ---- Blocklist: stasiun yang disembunyikan (mis. atas permintaan pemilik stasiun)
  var blocked = { ids: {}, names: {}, domains: [] };
  function normName(n) { return String(n || '').trim().toLowerCase().replace(/\s+/g, ' '); }
  function addBlocklist(data) {
    if (!data || typeof data !== 'object') return;
    (data.stations || []).forEach(function (id) { if (id) blocked.ids[String(id).trim()] = 1; });
    (data.names || []).forEach(function (n) { if (n) blocked.names[normName(n)] = 1; });
    (data.domains || []).forEach(function (d) {
      d = String(d || '').trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '');
      if (d && blocked.domains.indexOf(d) < 0) blocked.domains.push(d);
    });
  }
  function hostOf(u) { var m = /^https?:\/\/([^\/:?#]+)/i.exec(String(u || '')); return m ? m[1].toLowerCase() : ''; }
  function isBlocked(s) {
    if (!s) return false;
    if (blocked.ids[s.stationuuid]) return true;
    if (blocked.names[normName(s.name)]) return true;
    if (!blocked.domains.length) return false;
    return [s.url_resolved, s.url, s.homepage].some(function (u) {
      var h = hostOf(u);
      return h && blocked.domains.some(function (d) { return h === d || h.slice(-(d.length + 1)) === '.' + d; });
    });
  }
  function visibleFavorites() { return state.favorites.filter(function (f) { return !isBlocked(f); }); }
  function loadBlocklist() {
    var jobs = [fetch('blocklist.json', { cache: 'no-cache' }).then(function (r) { return r.ok ? r.json() : null; }).catch(function () { return null; })];
    if (BLOCKLIST_URL) {
      addBlocklist(store.get('remoteBlocklist', null)); // salinan terakhir, dipakai bila sedang offline
      jobs.push(fetch(BLOCKLIST_URL, { cache: 'no-cache' }).then(function (r) { return r.ok ? r.json() : null; })
        .then(function (d) { if (d) store.set('remoteBlocklist', d); return d; }).catch(function () { return null; }));
    }
    Promise.all(jobs).then(function (lists) {
      lists.forEach(addBlocklist);
      renderStatic(); renderList(); renderFavs();
    });
  }

  var SORTS = {
    popular: { order: 'clickcount', reverse: 'true' },
    name: { order: 'name', reverse: 'false' },
    city: { order: 'state', reverse: 'false' },
    hq: { order: 'bitrate', reverse: 'true' } // kualitas tertinggi dulu (lihat sortStations)
  };
  var PAGE = 60;
  var FULL_LIMIT = 2500; // batas satu negara dimuat sekaligus (Indonesia ±615 stasiun)
  var TIER_RANK = { lossless: 2, hq: 1, '': 0 };
  // Urutan seperti manusia membaca: huruf besar/kecil sama, simbol & spasi di depan diabaikan, 2 sebelum 10
  var LEAD_JUNK = (function () { try { return new RegExp('^[^\\p{L}\\p{N}]+', 'u'); } catch (e) { return /^[^A-Za-z0-9\u00C0-\uFFFF]+/; } })();
  function textCollator() {
    try { return new Intl.Collator(state.lang === 'en' ? 'en' : 'id', { sensitivity: 'base', numeric: true }); }
    catch (e) { return { compare: function (a, b) { return a.toLowerCase().localeCompare(b.toLowerCase()); } }; }
  }
  function nameKey(s) { return stationName(s).replace(LEAD_JUNK, '') || stationName(s); }
  function cityKey(s) { return localRegion(s.state, String(s.countrycode || '').toUpperCase(), s.country) || ''; }
  function sortStations(list) {
    var by = state.sort;
    var col = textCollator();
    return list.slice().sort(function (a, b) {
      if (by === 'name') return col.compare(nameKey(a), nameKey(b));
      if (by === 'city') {
        // Stasiun tanpa kota/provinsi ditaruh paling bawah
        var ca = cityKey(a), cb = cityKey(b);
        if (!ca !== !cb) return ca ? -1 : 1;
        return col.compare(ca, cb) || col.compare(nameKey(a), nameKey(b));
      }
      // HQ: Lossless dulu, lalu HQ (256 kbps ke atas), lalu lainnya; masing-masing dari kbps tertinggi
      if (by === 'hq') return (TIER_RANK[qualityTier(b)] - TIER_RANK[qualityTier(a)]) || ((b.bitrate || 0) - (a.bitrate || 0)) || ((b.clickcount || 0) - (a.clickcount || 0));
      return (b.clickcount || 0) - (a.clickcount || 0);
    });
  }
  var stationIndex = {};
  function indexStations() {
    stationIndex = {};
    state.stations.forEach(function (st, i) { stationIndex[st.stationuuid] = i; });
  }
  var reqId = 0;
  var controller = null;

  function loadStations(reset) {
    if (reset) {
      if (controller) controller.abort();
      state.offset = 0; state.endReached = false; state.error = false; state.loading = true; state.loadingMore = false;
      state.autoPages = 0;
      probeGen++; probeQueue = []; shownIds = {}; probeStart = {}; skippedIds = {}; probeHorizon = PROBE_AHEAD;
    } else {
      if (state.loading || state.loadingMore || state.endReached || state.error) return;
      if (visibleStations().pending) return; // tunggu halaman ini selesai diperiksa dulu
      // Pengaman: jangan terus memuat halaman bila hampir tidak ada stasiun yang lolos pemeriksaan
      if (visibleStations().list.length < 10) {
        if ((state.autoPages || 0) >= 5) return;
        state.autoPages = (state.autoPages || 0) + 1;
      }
      state.loadingMore = true;
    }
    renderList();
    var my = ++reqId;
    controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
    var offset = reset ? 0 : state.offset;
    // Nama / Kota / HQ di satu negara: ambil seluruh daftar negara itu sekaligus lalu urutkan dengan benar
    // (urutan bawaan katalog per karakter & per halaman tidak cocok untuk dibaca)
    var full = state.sort !== 'popular' && !!state.country;
    var limit = full ? FULL_LIMIT : PAGE;
    var q = state.query.trim();
    // Pencarian mencakup nama stasiun, genre (tag), dan kota/provinsi: tiga permintaan sekaligus
    var fields = q ? ['name', 'tag', 'state'] : [null];
    // HQ: hanya stasiun 256 kbps ke atas, ditambah stasiun FLAC (lossless, sering tercatat 0 kbps)
    var tiers = state.sort === 'hq' ? [{ bitrateMin: '256' }, { codec: 'FLAC' }] : [{}];
    var requests = [];
    fields.forEach(function (field) { tiers.forEach(function (tier) { requests.push({ field: field, tier: tier }); }); });
    var signal = controller ? controller.signal : undefined;
    Promise.all(requests.map(function (rq) {
      var p = new URLSearchParams({
        order: SORTS[state.sort].order, reverse: SORTS[state.sort].reverse, hidebroken: 'true',
        offset: String(offset), limit: String(limit)
      });
      if (state.country) p.set('countrycode', state.country);
      if (rq.field) p.set(rq.field, q);
      Object.keys(rq.tier).forEach(function (k) { p.set(k, rq.tier[k]); });
      return api('/json/stations/search?' + p.toString(), signal).then(function (r) { return Array.isArray(r) ? r : []; });
    }))
      .then(function (results) {
        if (my !== reqId) return;
        var more = !full && results.some(function (r) { return r.length >= PAGE; });
        var raw = [].concat.apply([], results);
        if (state.sort === 'hq') raw = raw.filter(function (st) { return qualityTier(st) !== ''; }); // hanya HQ & Lossless
        if (results.length > 1 || state.sort !== 'popular') raw = sortStations(raw);
        var page = raw.filter(function (s) { return s && s.stationuuid && (s.url_resolved || s.url) && isPlayable(s) && !isBlocked(s); });
        var merged = (reset ? [] : state.stations).concat(page);
        var seen = {};
        state.stations = merged.filter(function (s) { if (seen[s.stationuuid]) return false; seen[s.stationuuid] = 1; return true; });
        state.offset = offset + (results.length > 1 ? PAGE : raw.length);
        state.endReached = !more;
        indexStations();
        state.loading = false; state.loadingMore = false;
        queueProbes(page);
        renderList();
        maybeLoadMore();
      })
      .catch(function (e) {
        if (e && e.name === 'AbortError') return;
        if (my !== reqId) return;
        state.error = true; state.loading = false; state.loadingMore = false;
        renderList();
      });
  }

  function loadCountries() {
    if (state.countries.length || state.countriesLoading) return;
    state.countriesLoading = true;
    api('/json/countries?order=stationcount&reverse=true&hidebroken=true')
      .then(function (raw) {
        var map = {};
        (raw || []).forEach(function (c) {
          var code = String(c.iso_3166_1 || '').toUpperCase();
          if (!/^[A-Z]{2}$/.test(code) || !c.stationcount) return;
          if (!map[code]) map[code] = { code: code, name: c.name, count: 0, best: 0 };
          map[code].count += c.stationcount;
          if (c.stationcount > map[code].best) { map[code].best = c.stationcount; map[code].name = c.name; }
        });
        state.countries = Object.keys(map).map(function (k) { return map[k]; }).sort(function (a, b) { return b.count - a.count; });
      })
      .catch(function () { /* dicoba lagi saat pemilih negara dibuka */ })
      .then(function () { state.countriesLoading = false; renderStatic(); if (!$('drawer').hidden) renderCountries(); });
  }

  function registerClick(s) { api('/json/url/' + encodeURIComponent(s.stationuuid)).catch(function () {}); }

  // ------------------------------------------------------------------ Data stasiun
  function stationName(s) { return String(s.name || '').trim() || 'Radio'; }
  // Nama provinsi/kota Indonesia dalam dua bahasa: [Indonesia, English, ...ejaan lain]
  var ID_REGIONS = [
    ['Aceh', 'Aceh', 'nanggroe aceh darussalam', 'nad', 'di aceh'],
    ['Sumatera Utara', 'North Sumatra', 'sumatra utara', 'north sumatera', 'sumut'],
    ['Sumatera Barat', 'West Sumatra', 'sumatra barat', 'west sumatera', 'sumbar'],
    ['Riau', 'Riau'],
    ['Kepulauan Riau', 'Riau Islands', 'kepri'],
    ['Jambi', 'Jambi'],
    ['Sumatera Selatan', 'South Sumatra', 'sumatra selatan', 'south sumatera', 'sumsel'],
    ['Kepulauan Bangka Belitung', 'Bangka Belitung Islands', 'bangka belitung', 'babel'],
    ['Bengkulu', 'Bengkulu'],
    ['Lampung', 'Lampung'],
    ['DKI Jakarta', 'Jakarta', 'jakarta', 'dki', 'jakarta raya', 'special capital region of jakarta'],
    ['Jakarta Pusat', 'Central Jakarta'],
    ['Jakarta Selatan', 'South Jakarta'],
    ['Jakarta Barat', 'West Jakarta'],
    ['Jakarta Timur', 'East Jakarta'],
    ['Jakarta Utara', 'North Jakarta'],
    ['Jawa Barat', 'West Java', 'jabar'],
    ['Banten', 'Banten'],
    ['Jawa Tengah', 'Central Java', 'jateng'],
    ['DI Yogyakarta', 'Special Region of Yogyakarta', 'yogyakarta', 'daerah istimewa yogyakarta', 'diy', 'jogja', 'jogjakarta', 'yogya'],
    ['Jawa Timur', 'East Java', 'jatim'],
    ['Bali', 'Bali'],
    ['Nusa Tenggara Barat', 'West Nusa Tenggara', 'ntb'],
    ['Nusa Tenggara Timur', 'East Nusa Tenggara', 'ntt'],
    ['Kalimantan Barat', 'West Kalimantan', 'kalbar'],
    ['Kalimantan Tengah', 'Central Kalimantan', 'kalteng'],
    ['Kalimantan Selatan', 'South Kalimantan', 'kalsel'],
    ['Kalimantan Timur', 'East Kalimantan', 'kaltim'],
    ['Kalimantan Utara', 'North Kalimantan', 'kaltara'],
    ['Sulawesi Utara', 'North Sulawesi', 'sulut'],
    ['Gorontalo', 'Gorontalo'],
    ['Sulawesi Tengah', 'Central Sulawesi', 'sulteng'],
    ['Sulawesi Barat', 'West Sulawesi', 'sulbar'],
    ['Sulawesi Selatan', 'South Sulawesi', 'sulsel'],
    ['Sulawesi Tenggara', 'Southeast Sulawesi', 'sultra'],
    ['Maluku', 'Maluku', 'moluccas'],
    ['Maluku Utara', 'North Maluku', 'malut'],
    ['Papua', 'Papua'],
    ['Papua Barat', 'West Papua'],
    ['Papua Barat Daya', 'Southwest Papua'],
    ['Papua Tengah', 'Central Papua'],
    ['Papua Pegunungan', 'Highland Papua'],
    ['Papua Selatan', 'South Papua']
  ];
  function regionKey(x) { return String(x || '').toLowerCase().replace(/[.,_()-]/g, ' ').replace(/\s+/g, ' ').trim(); }
  var REGION_MAP = {};
  ID_REGIONS.forEach(function (row) { row.forEach(function (name) { REGION_MAP[regionKey(name)] = row; }); });
  function localRegion(name, countryCode, countryText) {
    var raw = String(name || '').trim();
    if (!raw) return '';
    var isIndonesia = countryCode === 'ID' || /indonesia/i.test(countryText || '');
    var row = isIndonesia ? REGION_MAP[regionKey(raw)] : null;
    if (row) return state.lang === 'en' ? row[1] : row[0];
    return raw === raw.toLowerCase() ? titleTag(raw) : raw; // "jakarta" -> "Jakarta"
  }
  function localCountry(s) {
    var code = String(s.countrycode || '').toUpperCase();
    if (/^[A-Z]{2}$/.test(code)) return countryName(code, s.country);
    return String(s.country || '').trim();
  }
  function stationLocation(s) {
    var code = String(s.countrycode || '').toUpperCase();
    return [localRegion(s.state, code, s.country), localCountry(s)].filter(Boolean).join(', ');
  }
  // Genre/kategori dengan huruf kapital di awal kata: "pop, news" -> "Pop, News"
  var TAG_FIX = {
    'rnb': 'R&B', 'r&b': 'R&B', 'r & b': 'R&B', 'edm': 'EDM', 'idm': 'IDM', 'ebm': 'EBM', 'mpb': 'MPB',
    'fm': 'FM', 'am': 'AM', 'dj': 'DJ', 'djs': 'DJs', 'uk': 'UK', 'us': 'US', 'usa': 'USA',
    'npr': 'NPR', 'bbc': 'BBC', 'rri': 'RRI', 'lgbt': 'LGBT', 'lgbtq': 'LGBTQ', 'lgbtq+': 'LGBTQ+',
    'kpop': 'K-Pop', 'k-pop': 'K-Pop', 'jpop': 'J-Pop', 'j-pop': 'J-Pop', 'cpop': 'C-Pop', 'c-pop': 'C-Pop',
    'opm': 'OPM', 'aac': 'AAC', 'mp3': 'MP3'
  };
  var CAP_RE = (function () { try { return new RegExp('(^|[\\s\\-/&(])([\\p{L}\\d])', 'gu'); } catch (e) { return /(^|[\s\-\/&(])([a-z0-9])/g; } })();
  function titleTag(tag) {
    var k = tag.toLowerCase();
    if (TAG_FIX[k]) return TAG_FIX[k];
    return k.replace(CAP_RE, function (m, p, c) { return p + c.toUpperCase(); });
  }
  function stationGenres(s) {
    var seen = {};
    return String(s.tags || '').split(',').map(function (x) { return x.trim(); }).filter(function (x) {
      var k = x.toLowerCase();
      if (!x || seen[k]) return false;
      seen[k] = 1; return true;
    }).slice(0, 3).map(titleTag).join(', ');
  }
  // Kualitas tinggi: lossless (FLAC/ALAC/WAV) atau 256 kbps ke atas
  var LOSSLESS_CODEC = /^(flac|alac|wav|pcm|ape|wavpack)/i;
  function qualityTier(s) {
    var codec = String(s.codec || '').trim();
    if (LOSSLESS_CODEC.test(codec) || /\.flac(\?|$)/i.test(s.url_resolved || s.url || '')) return 'lossless';
    if ((s.bitrate || 0) >= 256) return 'hq';
    return '';
  }
  function qualityBadge(s) {
    var tier = qualityTier(s);
    // HQ+ = lossless (FLAC dsb.), HQ = 256 kbps ke atas
    return tier ? '<span class="q-badge">' + (tier === 'lossless' ? 'HQ+' : 'HQ') + '</span>' : '';
  }
  function stationDetail(s) {
    var genres = stationGenres(s);
    var q = s.codec ? (s.bitrate > 0 ? s.codec + ' ' + s.bitrate + ' kbps' : s.codec) : '';
    return [genres, q].filter(Boolean).join(' / ');
  }
  function initials(name) {
    var parts = name.split(/\s+/).filter(Boolean);
    return ((parts[0] || '?').charAt(0) + (parts[1] ? parts[1].charAt(0) : '')).toUpperCase();
  }
  function slim(s) {
    return {
      stationuuid: s.stationuuid, name: s.name, url: s.url, url_resolved: s.url_resolved, favicon: s.favicon,
      tags: s.tags, country: s.country, countrycode: s.countrycode, state: s.state, codec: s.codec, bitrate: s.bitrate, hls: s.hls, homepage: s.homepage
    };
  }
  function isFav(id) { return state.favorites.some(function (f) { return f.stationuuid === id; }); }
  function findStation(id) {
    var all = state.stations.concat(state.favorites, state.history);
    for (var i = 0; i < all.length; i++) if (all[i].stationuuid === id) return all[i];
    return null;
  }

  // ------------------------------------------------------------------ Render
  // Warna latar untuk stasiun tanpa cover art: tampak acak, tapi tetap sama untuk stasiun yang sama.
  // Semua warna cukup gelap agar inisial putih tetap terbaca (kontras >= 4.5:1).
  var TILE_COLORS = ['#b91c1c', '#c2410c', '#a16207', '#4d7c0f', '#15803d', '#0f766e', '#0e7490',
    '#0369a1', '#1d4ed8', '#4338ca', '#6d28d9', '#a21caf', '#be185d', '#be123c', '#475569'];
  function tileColor(s) {
    var key = String(s.stationuuid || s.name || ''), h = 0;
    for (var i = 0; i < key.length; i++) h = (h * 31 + key.charCodeAt(i)) >>> 0;
    return TILE_COLORS[h % TILE_COLORS.length];
  }
  // 5 garis seperti logo FREQMAN (lihat .bars di styles.css)
  var BARS_HTML = '<span class="bars" aria-hidden="true"><span></span><span></span><span></span><span></span><span></span></span>';
  function artUrl(s) { return /^https?:\/\//i.test(s.favicon || '') ? s.favicon : ''; }
  // Cover art resmi ditampilkan apa adanya (tanpa warna). Warna + inisial hanya dipakai
  // bila stasiun tidak punya cover art, atau cover art-nya gagal dimuat / terlalu kecil.
  window.FreqManArtFail = function (img) {
    var tile = img.parentNode;
    if (tile) {
      tile.classList.remove('has-art');
      tile.style.background = tile.getAttribute('data-color') || '';
    }
    if (img.parentNode) img.parentNode.removeChild(img);
  };
  function mediaAttrs(s) {
    return artUrl(s)
      ? ' class="media has-art" data-color="' + tileColor(s) + '"'
      : ' class="media" data-color="' + tileColor(s) + '" style="background:' + tileColor(s) + '"';
  }
  function mediaHtml(s, showBars) {
    var art = artUrl(s);
    return '<span class="media-initials">' + esc(initials(stationName(s))) + '</span>' +
      (art ? '<img src="' + esc(art) + '" alt="" loading="lazy" referrerpolicy="no-referrer" onerror="FreqManArtFail(this)" onload="if(this.naturalWidth<24||this.naturalHeight<24)FreqManArtFail(this)">' : '') +
      (showBars ? BARS_HTML : '');
  }
  // Animasi "sedang diputar" dipasang/dilepas tanpa menyentuh gambar logo
  function setBars(media, on) {
    if (!media) return;
    var bars = media.querySelector('.bars');
    if (on && !bars) media.insertAdjacentHTML('beforeend', BARS_HTML);
    else if (!on && bars) media.removeChild(bars);
  }

  function itemHtml(s) {
    var t = T();
    var name = stationName(s);
    var cur = state.current && state.current.stationuuid === s.stationuuid;
    var fav = isFav(s.stationuuid);
    var loc = stationLocation(s) || t.unknownLocation;
    var detail = stationDetail(s);
    return '<div class="item' + (cur ? ' item-current' : '') + '" data-id="' + esc(s.stationuuid) + '">' +
      '<button type="button" class="item-main" data-action="play" aria-label="' + esc((cur && state.playing ? t.pause : t.play) + ': ' + name) + '">' +
      '<span' + mediaAttrs(s) + '>' + mediaHtml(s, cur && state.playing) + '</span>' +
      '<span class="item-content"><span class="item-title-row"><span class="item-title">' + esc(name) + '</span>' +
      qualityBadge(s) +
      '<span class="fail-badge"' + (hasFailed(s) ? '' : ' hidden') + '>' + esc(t.failedLastTime) + '</span></span>' +
      '<span class="item-desc">' + esc(loc) + '</span>' +
      (detail ? '<span class="item-desc xs">' + esc(detail) + '</span>' : '') +
      '</span></button>' +
      '<button type="button" class="btn btn-ghost btn-icon-lg" data-action="fav" aria-pressed="' + fav + '" aria-label="' + esc((fav ? t.removeFavorite : t.saveFavorite) + ': ' + name) + '">' +
      svg('heart', 16, { fill: fav }) + '</button></div>';
  }

  // Label tombol dalam ID & EN ditumpuk (yang tidak aktif disembunyikan): lebar tombol sama di kedua bahasa
  function bothLangs(key) {
    return '<span class="same-width">' + ['id', 'en'].map(function (lang) {
      var txt = esc(I18N[lang][key]);
      return lang === state.lang ? '<span>' + txt + '</span>' : '<span class="ghost" aria-hidden="true">' + txt + '</span>';
    }).join('') + '</span>';
  }
  function emptyHtml(icon, title, desc, actionKey, action, dashed) {
    return '<div class="empty' + (dashed ? ' dashed' : '') + '"><div class="empty-media">' + svg(icon, 24) + '</div>' +
      '<h2>' + esc(title) + '</h2><p>' + esc(desc) + '</p>' +
      (actionKey ? '<button type="button" class="btn btn-outline" data-action="' + action + '">' + bothLangs(actionKey) + '</button>' : '') + '</div>';
  }

  function skeletonHtml() {
    var w = [['62%', '40%'], ['54%', '36%'], ['70%', '44%'], ['48%', '32%'], ['64%', '42%'], ['58%', '38%'], ['66%', '40%'], ['52%', '34%']];
    return w.map(function (x) {
      return '<div class="skeleton-row" aria-hidden="true"><div class="skeleton" style="width:44px;height:44px"></div>' +
        '<div style="display:flex;flex-direction:column;gap:8px;flex:1"><div class="skeleton" style="height:14px;width:' + x[0] + '"></div>' +
        '<div class="skeleton" style="height:12px;width:' + x[1] + '"></div></div></div>';
    }).join('');
  }

  function currentCountryLabel() {
    var c = state.countries.filter(function (x) { return x.code === state.country; })[0];
    return countryName(state.country, c ? c.name : '');
  }

  // Perbarui satu baris stasiun di tempat: status putar, hati, label, lokasi.
  function updateItem(el, s) {
    var t = T();
    var fb = el.querySelector('.fail-badge');
    if (fb) {
      fb.hidden = !hasFailed(s);
      if (fb.textContent !== t.failedLastTime) fb.textContent = t.failedLastTime;
    }
    var name = stationName(s);
    var cur = !!(state.current && state.current.stationuuid === s.stationuuid);
    var playingHere = cur && state.playing;
    var fav = isFav(s.stationuuid);
    el.classList.toggle('item-current', cur);
    var main = el.querySelector('[data-action="play"]');
    if (main) main.setAttribute('aria-label', (playingHere ? t.pause : t.play) + ': ' + name);
    setBars(el.querySelector('.media'), playingHere);
    var loc = el.querySelector('.item-desc');
    var locText = stationLocation(s) || t.unknownLocation;
    if (loc && loc.textContent !== locText) loc.textContent = locText;
    var heart = el.querySelector('[data-action="fav"]');
    if (heart) {
      if (heart.getAttribute('aria-pressed') !== String(fav)) {
        heart.setAttribute('aria-pressed', String(fav));
        heart.innerHTML = svg('heart', 16, { fill: fav });
      }
      heart.setAttribute('aria-label', (fav ? t.removeFavorite : t.saveFavorite) + ': ' + name);
    }
  }

  function htmlToElement(html) {
    var tpl = document.createElement('template');
    tpl.innerHTML = html.trim();
    return tpl.content.firstChild;
  }

  // Cocokkan isi daftar dengan data berdasarkan id stasiun: baris yang sudah ada dipakai ulang
  // (gambar logonya tidak dimuat ulang), hanya baris baru yang dibuat, yang hilang dihapus.
  function syncItems(container, stations, headHtml, footHtml) {
    Array.prototype.slice.call(container.children).forEach(function (ch) {
      if (!ch.classList.contains('item')) container.removeChild(ch);
    });
    var existing = {};
    Array.prototype.forEach.call(container.children, function (el) { existing[el.getAttribute('data-id')] = el; });
    var cursor = container.firstElementChild;
    stations.forEach(function (s) {
      var el = existing[s.stationuuid];
      if (el) { delete existing[s.stationuuid]; updateItem(el, s); }
      else el = htmlToElement(itemHtml(s));
      if (el === cursor) cursor = cursor.nextElementSibling;
      else container.insertBefore(el, cursor);
    });
    Object.keys(existing).forEach(function (id) { var el = existing[id]; if (el.parentNode) el.parentNode.removeChild(el); });
    if (headHtml) container.insertAdjacentHTML('afterbegin', headHtml);
    if (footHtml) container.insertAdjacentHTML('beforeend', footHtml);
  }

  function renderList() {
    var t = T();
    var list = $('list');
    var html = null;
    var vis = visibleStations();
    var mayLoadMore = !state.endReached && !state.error && (state.autoPages || 0) < 5;
    if (state.loading && !vis.list.length) {
      html = skeletonHtml();
    } else if (state.error && !vis.list.length) {
      html = emptyHtml('wifiOff', t.errorTitle, t.errorDesc, 'retry', 'retry');
    } else if (!vis.list.length && (vis.pending || state.loadingMore || mayLoadMore)) {
      html = skeletonHtml(); // masih memeriksa stasiun
    } else if (!vis.list.length && state.sort === 'hq') {
      html = emptyHtml('tower', t.hqEmptyTitle, t.hqEmptyDesc(currentCountryLabel()), 'showAll', 'showAll');
    } else if (!vis.list.length && state.query.trim()) {
      html = emptyHtml('searchX', t.notFoundTitle, t.notFoundDesc(state.query.trim(), currentCountryLabel()), 'clearSearch', 'clear');
    } else if (!vis.list.length) {
      html = emptyHtml('tower', t.noStationsTitle, t.noStationsDesc(currentCountryLabel()), 'pickOtherCountry', 'country');
    }
    if (html !== null) { list.innerHTML = html; return; }
    var head = state.loading ? '<div class="list-footer">' + svg('loader', 16, { cls: 'spinner' }) + esc(t.refreshing) + '</div>' : '';
    var foot = '';
    if (state.loadingMore || vis.pending) foot = '<div class="list-footer">' + svg('loader', 20, { cls: 'spinner' }) + '<span class="sr-only">' + esc(t.loadingMore) + '</span></div>';
    else if (state.error) foot = '<div class="list-footer"><button type="button" class="btn btn-outline" data-action="more">' + bothLangs('loadMoreFailed') + '</button></div>';
    vis.list.forEach(function (st) { shownIds[st.stationuuid] = 1; });
    syncItems(list, vis.list, head, foot);
  }

  function renderHistory() {
    var t = T();
    var box = $('histList');
    var list = visibleHistory();
    if (!list.length) {
      box.innerHTML = emptyHtml('history', t.emptyHistTitle, t.emptyHistDesc, 'browseStations', 'browse', true);
      return;
    }
    syncItems(box, list, '', '<div class="list-footer"><button type="button" class="btn btn-outline" data-action="clearHistory">' + bothLangs('clearHistory') + '</button></div>');
  }

  function renderFavs() {
    var t = T();
    var box = $('favList');
    var favs = visibleFavorites();
    if (!favs.length) {
      box.innerHTML = emptyHtml('heart', t.emptyFavTitle, t.emptyFavDesc, 'browseStations', 'browse', true);
      return;
    }
    syncItems(box, favs, '', '');
  }

  // Hanya memperbarui status baris yang sudah tampil (dipakai saat putar/jeda & favorit)
  function refreshItems() {
    ['list', 'favList', 'histList'].forEach(function (id) {
      Array.prototype.forEach.call($(id).querySelectorAll('.item'), function (el) {
        var s = findStation(el.getAttribute('data-id'));
        if (s) updateItem(el, s);
      });
    });
  }

  function renderStatic() {
    var t = T();
    document.documentElement.lang = state.lang;
    document.title = 'FREQMAN — Frequency Manager';
    Array.prototype.forEach.call(document.querySelectorAll('[data-t]'), function (el) { el.textContent = t[el.getAttribute('data-t')]; });
    $('langGroup').setAttribute('aria-label', t.switchLanguage);
    $('aboutBtn').setAttribute('aria-label', 'FREQMAN, ' + t.aboutOpen);
    Array.prototype.forEach.call(document.querySelectorAll('#langGroup button'), function (b) {
      b.setAttribute('aria-checked', String(b.getAttribute('data-lang') === state.lang));
    });
    var search = $('search');
    search.placeholder = t.searchPlaceholder;
    search.setAttribute('aria-label', t.searchPlaceholder);
    $('clearSearch').setAttribute('aria-label', t.clearSearch);
    $('clearSearch').hidden = !state.query;
    $('countrySearch').placeholder = t.searchCountry;
    $('countrySearch').setAttribute('aria-label', t.searchCountry);

    var label = currentCountryLabel();
    $('countryCode').textContent = state.country || 'ALL';
    $('countryLabel').textContent = label;
    $('countryBtn').setAttribute('aria-label', t.changeCountry + ': ' + label);

    var count = state.country
      ? (state.countries.filter(function (c) { return c.code === state.country; })[0] || { count: 0 }).count
      : state.countries.reduce(function (a, c) { return a + c.count; }, 0);
    // Teks ID dan EN ditumpuk di tempat yang sama (yang tidak aktif disembunyikan),
    // jadi lebar badge selalu sama di kedua bahasa tanpa perlu ukuran tetap.
    var labels = ['id', 'en'].map(function (lang) {
      var d = I18N[lang];
      var n = count > 0 ? (function () { try { return new Intl.NumberFormat(d.locale).format(count); } catch (e) { return String(count); } })() : '';
      return { lang: lang, text: count > 0 ? d.stations(n) : d.loadingCatalog };
    });
    $('countBadge').innerHTML = (count > 0 ? '' : svg('loader', 12, { cls: 'spinner' })) +
      '<span class="same-width">' + labels.map(function (l) {
        return l.lang === state.lang ? '<span>' + esc(l.text) + '</span>' : '<span class="ghost" aria-hidden="true">' + esc(l.text) + '</span>';
      }).join('') + '</span>';

    $('tabBrowse').textContent = t.tabBrowse;
    var favCount = visibleFavorites().length;
    $('tabFav').textContent = favCount ? t.tabFavorites + ' (' + favCount + ')' : t.tabFavorites;
    $('tabHist').textContent = t.tabHistory;
    $('tabBrowse').setAttribute('aria-selected', String(state.tab === 'browse'));
    $('tabFav').setAttribute('aria-selected', String(state.tab === 'fav'));
    $('tabHist').setAttribute('aria-selected', String(state.tab === 'hist'));
    $('browsePane').hidden = state.tab !== 'browse';
    $('sortRow').hidden = state.tab !== 'browse';
    $('favPane').hidden = state.tab !== 'fav';
    $('histPane').hidden = state.tab !== 'hist';

    var sg = $('sortGroup');
    sg.setAttribute('aria-label', t.sortGroup);
    sg.innerHTML = Object.keys(SORTS).map(function (k) {
      var short = t.sortsShort && t.sortsShort[k];
      var label = short ? '<span class="lbl-long">' + esc(t.sorts[k]) + '</span><span class="lbl-short">' + esc(short) + '</span>' : esc(t.sorts[k]);
      return '<button type="button" role="radio" data-sort="' + k + '" aria-checked="' + (state.sort === k) + '" aria-label="' + esc(t.sorts[k]) + '">' + label + '</button>';
    }).join('');
  }

  function renderPlayer() {
    var t = T();
    var s = state.current;
    var player = $('player');
    document.body.classList.toggle('has-player', !!s);
    player.hidden = !s;
    if (!s) return;
    var name = stationName(s);
    var pm = $('playerMedia');
    if (pm.getAttribute('data-id') !== s.stationuuid) {
      pm.setAttribute('data-id', s.stationuuid);
      var art = !!artUrl(s);
      pm.classList.toggle('has-art', art);
      pm.setAttribute('data-color', tileColor(s));
      pm.style.background = art ? '' : tileColor(s);
      pm.innerHTML = mediaHtml(s, state.playing);
    } else {
      setBars(pm, state.playing);
    }
    $('playerTitle').textContent = name;
    $('playerOpen').setAttribute('aria-label', t.openPlayer + ': ' + name);
    var badge;
    badge = state.playing ? '<span class="badge badge-status badge-live"><span class="live-dot"></span>' + esc(t.live) + '</span>' : '';
    $('playerBadge').innerHTML = badge;
    // Judul lagu (bila stasiun mengirimkannya) menggantikan lokasi
    $('playerSub').textContent = state.nowTitle ? '♪ ' + state.nowTitle : (stationLocation(s) || t.liveBroadcast);
    // Sama seperti di daftar: genre / kualitas siaran
    var detail = stationDetail(s);
    $('playerDetail').textContent = detail;
    $('playerDetail').hidden = !detail;
    var active = state.playing || state.buffering;
    var toggle = $('playerToggle');
    toggle.setAttribute('aria-label', active ? t.pause : t.play);
    toggle.innerHTML = state.buffering ? svg('loader', 16, { cls: 'spinner' }) : svg(state.playing ? 'pause' : 'play', 16, { fill: true });
    $('playerClose').setAttribute('aria-label', t.closePlayer);
  }

  function renderCountries() {
    var t = T();
    var f = state.countryFilter.trim().toLowerCase();
    var rows = state.countries.map(function (c) { return { c: c, name: countryName(c.code, c.name) }; })
      .filter(function (r) {
        return !f || r.name.toLowerCase().indexOf(f) >= 0 || String(r.c.name).toLowerCase().indexOf(f) >= 0 || r.c.code.toLowerCase() === f;
      });
    var html = '';
    if (!f) {
      html += '<div class="command-heading">' + esc(t.groupGeneral) + '</div>' +
        '<button type="button" class="command-item" role="option" data-country="" aria-selected="' + (!state.country) + '">' +
        '<span class="code-chip">ALL</span><span class="grow">' + esc(t.worldwide) + '</span>' +
        (!state.country ? svg('check') : '') + '</button>';
    }
    if (!state.countries.length) {
      html += '<div class="command-empty" style="display:flex;justify-content:center;gap:8px">' + svg('loader', 16, { cls: 'spinner' }) + esc(t.loadingCountries) + '</div>';
    } else if (!rows.length) {
      html += '<div class="command-empty">' + esc(t.countryNotFound) + '</div>';
    } else {
      html += '<div class="command-heading">' + esc(t.groupCountries) + '</div>' + rows.map(function (r) {
        var sel = r.c.code === state.country;
        return '<button type="button" class="command-item" role="option" data-country="' + r.c.code + '" aria-selected="' + sel + '">' +
          '<span class="code-chip">' + r.c.code + '</span><span class="grow ellipsis">' + esc(r.name) + '</span>' +
          (sel ? svg('check') : '<span class="count">' + fmt(r.c.count) + '</span>') + '</button>';
      }).join('');
    }
    $('countryList').innerHTML = html;
  }

  function renderAll() { renderStatic(); renderList(); renderFavs(); renderHistory(); renderPlayer(); }

  // ------------------------------------------------------------------ Toast
  var toastTimer = null;
  var toastData = null; // { title: kunci teks, desc: kunci teks atau teks bebas, descIsKey, icon }
  function renderToast() {
    var el = $('toast');
    if (!toastData || el.hidden) return;
    var t = T();
    var title = t[toastData.title];
    var desc = toastData.descIsKey ? t[toastData.desc] : toastData.desc;
    el.innerHTML = svg(toastData.icon || 'circleCheck') + '<div class="toast-text"><span class="toast-title">' + esc(title) + '</span>' +
      (desc ? '<span class="muted">' + esc(desc) + '</span>' : '') + '</div>';
  }
  function toast(titleKey, desc, icon, descIsKey) {
    var el = $('toast');
    toastData = { title: titleKey, desc: desc, descIsKey: !!descIsKey, icon: icon };
    el.hidden = false;
    renderToast();
    el.style.animation = 'none'; void el.offsetWidth; el.style.animation = '';
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.hidden = true; }, 3500);
  }
  $('toast').addEventListener('click', function () { $('toast').hidden = true; });

  // ------------------------------------------------------------------ Pemutar audio
  var audio = new Audio();
  audio.preload = 'none';
  var hls = null;
  var streamActive = false;
  var stallTimer = null;
  var hlsLoader = null;

  function loadHls() {
    if (window.Hls) return Promise.resolve(window.Hls);
    if (!hlsLoader) {
      hlsLoader = new Promise(function (resolve) {
        var sc = document.createElement('script');
        sc.src = 'hls.light.min.js';
        sc.onload = function () { resolve(window.Hls || null); };
        sc.onerror = function () { resolve(null); };
        document.head.appendChild(sc);
      });
    }
    return hlsLoader;
  }

  // ---- Daftar alamat yang dicoba berurutan untuk satu stasiun:
  // alamat terselesaikan, alamat asli, lalu variasi http <-> https dari keduanya.
  function streamCandidates(s) {
    var list = [];
    function add(u) {
      u = String(u || '').trim();
      if (/^https?:\/\//i.test(u) && list.indexOf(u) < 0) list.push(u);
    }
    var base = [s.url_resolved, s.url];
    var verified = okUrl(s);
    if (verified) {
      // Sudah terbukti menjawab saat diperiksa: cukup alamat itu + satu cadangan (cepat mulai / cepat gagal)
      add(verified);
      base.forEach(function (u) { if (list.length < 2) add(u); });
    } else {
      base.forEach(add);
      base.forEach(function (u) {
        u = String(u || '').trim();
        if (/^http:\/\//i.test(u)) add('https://' + u.slice(7));
        else if (/^https:\/\//i.test(u)) add('http://' + u.slice(8));
      });
      list = list.slice(0, 3);
    }
    // Di halaman https (versi web), browser menolak http: dahulukan https.
    if (!nativeAudio && location.protocol === 'https:') {
      list = list.filter(function (u) { return /^https:/i.test(u); }).concat(list.filter(function (u) { return !/^https:/i.test(u); }));
    }
    return list;
  }

  // Di aplikasi Android, suara diputar pemutar bawaan Android (lebih banyak format, HLS tanpa
  // batasan CORS). Bila semua alamat gagal di sana, pemutar browser dicoba sebagai cadangan.
  var nativeAudio = !!(window.FreqManAndroid && window.FreqManAndroid.nativePlay);
  var candidates = [];
  var candIdx = 0;
  var useWebAudio = !nativeAudio;

  function teardown() {
    streamActive = false;
    clearTimeout(stallTimer);
    if (hls) { try { hls.destroy(); } catch (e) { /* abaikan */ } hls = null; }
    try { audio.pause(); } catch (e) { /* abaikan */ }
    audio.removeAttribute('src');
    try { audio.load(); } catch (e) { /* abaikan */ }
    if (nativeAudio) { try { window.FreqManAndroid.nativeStop(); } catch (e) { /* abaikan */ } }
  }

  function armStallTimer() {
    clearTimeout(stallTimer);
    // Alamat yang tidak merespons dalam 8 detik dilewati
    stallTimer = setTimeout(function () { if (streamActive && state.buffering) onStreamError(); }, 8000);
  }

  // Mulai dari awal (saat stasiun dipilih atau tombol Putar ditekan lagi)
  // Batas waktu total sejak stasiun diketuk: lewat dari ini langsung "Gagal Memutar Siaran"
  var START_DEADLINE_MS = 30000;
  var startedAt = 0, deadlineTimer = null;

  // ---- Urutan pemutar untuk satu stasiun.
  // Pemutar Android dulu (HLS & playlist tanpa batasan, judul lagu), lalu pemutar web sebagai cadangan.
  // Kecuali stasiun bitrate rendah: pemutar Android mengisi buffer dengan jumlah data tetap, sehingga
  // stasiun 32–64 kbps bisa butuh puluhan detik untuk mulai; pemutar web mulai dalam 1–2 detik.
  var LOW_BITRATE = 96;
  var plan = ['web'], planIdx = 0;
  // Aplikasi versi Kotlin memakai ExoPlayer: cepat di semua bitrate, jadi selalu pemutar Android dulu.
  var exoEngine = (function () { try { return window.FreqManAndroid.engine() === 'exoplayer'; } catch (e) { return false; } })();
  function playerPlan(s) {
    if (!nativeAudio) return ['web'];
    if (exoEngine) return ['native', 'web'];
    var first = candidates[0] || '';
    var needsNative = s.hls === 1 || /\.m3u8(\?|$)/i.test(first) || /\.(pls|m3u|asx|xspf)(\?|$)/i.test(first);
    var lowRate = (s.bitrate > 0 && s.bitrate < LOW_BITRATE) || /aac\+|he-?aac/i.test(String(s.codec || ''));
    return (lowRate && !needsNative) ? ['web', 'native'] : ['native', 'web'];
  }
  // Pemutar ini gagal: coba pemutar satunya selama sisa waktu masih ada (bukan langsung "Gagal")
  function nextPlayer() {
    if (playedThisStream || planIdx + 1 >= plan.length) return false;
    if (Date.now() - startedAt > START_DEADLINE_MS - 3000) return false;
    planIdx++;
    useWebAudio = plan[planIdx] === 'web';
    candIdx = 0;
    openCandidate();
    return true;
  }
  function startStream() {
    var s = state.current;
    if (!s) return;
    startedAt = Date.now();
    clearTimeout(deadlineTimer);
    deadlineTimer = setTimeout(function () {
      if (streamActive && !playedThisStream) { useWebAudio = true; candIdx = candidates.length; failPlayback(); }
    }, START_DEADLINE_MS);
    candidates = streamCandidates(s);
    candIdx = 0;
    plan = playerPlan(s); planIdx = 0;
    useWebAudio = plan[0] === 'web';
    playedThisStream = false;
    reconnects = 0;
    if (!candidates.length) { failPlayback(); return; }
    openCandidate();
  }

  function openCandidate() {
    var s = state.current;
    teardown();
    streamActive = true;
    state.buffering = true; state.playing = false;
    syncPlayback();
    if (!useWebAudio) {
      try { window.FreqManAndroid.nativePlay(JSON.stringify(candidates)); }
      catch (e) { useWebAudio = true; openCandidate(); }
      return;
    }
    armStallTimer();
    var url = candidates[candIdx];
    var isHls = s.hls === 1 || /\.m3u8(\?|$)/i.test(url);
    if (isHls && !audio.canPlayType('application/vnd.apple.mpegurl')) {
      loadHls().then(function (Hls) {
        if (state.current !== s || !streamActive) return;
        if (!Hls || !Hls.isSupported()) { onStreamError(); return; }
        hls = new Hls();
        hls.on(Hls.Events.ERROR, function (e, d) { if (d && d.fatal) onStreamError(); });
        hls.loadSource(url);
        hls.attachMedia(audio);
        audio.play().catch(onPlayRejected);
      });
    } else {
      audio.src = url;
      audio.play().catch(onPlayRejected);
    }
  }

  function onPlayRejected(err) {
    if (!streamActive) return;
    if (err && err.name === 'AbortError') return;
    if (err && err.name === 'NotAllowedError') { // browser menolak autoplay
      teardown(); state.playing = false; state.buffering = false; syncPlayback(); return;
    }
    onStreamError();
  }

  // Satu alamat gagal di pemutar browser: coba alamat berikutnya sebelum menyerah
  var playedThisStream = false, reconnects = 0;
  function onStreamError() {
    if (!state.current) return;
    // Sempat berbunyi lalu putus (mis. ganti Wi-Fi ke data): sambung ulang alamat yang sama dulu
    if (useWebAudio && playedThisStream && reconnects < 2 && navigator.onLine !== false) {
      reconnects++;
      openCandidate();
      return;
    }
    if (useWebAudio && candIdx + 1 < candidates.length) {
      candIdx++;
      openCandidate();
      return;
    }
    if (!nextPlayer()) failPlayback();
  }

  function failPlayback() {
    // Internet sedang putus: jangan anggap stasiun mati; sambung lagi otomatis saat online
    if (navigator.onLine === false) {
      teardown();
      state.playing = false; state.buffering = false; state.waitingNetwork = true;
      syncPlayback();
      toast('offlineTitle', 'offlineDesc', 'wifiOff', true);
      return;
    }
    // Sempat berbunyi lalu putus: gangguan sementara, stasiun tidak disembunyikan
    if (!playedThisStream) {
      markFailed(state.current);
      if (state.current) { probeCache[state.current.stationuuid] = { ok: 0, url: '', t: Date.now() }; saveProbeSoon(); }
    }
    teardown();
    state.playing = false; state.buffering = false;
    syncPlayback();
    toast('playbackFailedTitle', 'playbackFailedDesc', 'alert', true);
  }

  // Laporan dari pemutar bawaan Android
  function onNativeState(st) {
    if (st === 'sleep') { sleepFired(); return; } // timer tidur dari layanan Android
    if (!nativeAudio || !state.current || !streamActive || useWebAudio) return;
    if (st === 'playing') {
      playedThisStream = true;
      markPlayed(state.current);
      state.playing = true; state.buffering = false; syncPlayback();
    } else if (st === 'buffering') {
      state.buffering = true; syncPlayback();
    } else if (st === 'error') {
      // Semua alamat gagal di pemutar Android: coba pemutar web (bila belum dan waktu masih ada)
      if (!nextPlayer()) failPlayback();
    } else if (st === 'stopped') {
      // Dihentikan sistem: headset dicabut atau aplikasi lain memutar audio
      streamActive = false;
      state.playing = false; state.buffering = false; syncPlayback();
    }
  }

  audio.addEventListener('playing', function () {
    if (!streamActive) return;
    playedThisStream = true;
    markPlayed(state.current);
    clearTimeout(stallTimer);
    state.playing = true; state.buffering = false; syncPlayback();
  });
  audio.addEventListener('waiting', function () {
    if (!streamActive) return;
    state.buffering = true; syncPlayback(); armStallTimer();
  });
  audio.addEventListener('pause', function () {
    if (!streamActive || !useWebAudio) return; // jeda dari sistem (mis. headset dicabut)
    teardown(); state.playing = false; state.buffering = false; syncPlayback();
  });
  audio.addEventListener('error', function () { if (streamActive && useWebAudio && !hls) onStreamError(); });

  function playStation(s) {
    state.current = slim(s);
    state.nowTitle = '';
    startStream();
    registerClick(s);
  }
  // Radio siaran langsung: jeda = putus koneksi; putar lagi = sambung ulang ke siaran terkini.
  function togglePlay() {
    if (!state.current) return;
    if (state.playing || state.buffering) {
      teardown(); state.playing = false; state.buffering = false; syncPlayback();
    } else {
      state.waitingNetwork = false;
      startStream();
    }
  }
  function closePlayer() {
    teardown();
    state.current = null; state.playing = false; state.buffering = false;
    state.nowTitle = ''; state.waitingNetwork = false;
    if (state.sleepEnd) setSleep(0, true);
    closeNp();
    syncPlayback();
  }

  function syncPlayback() {
    renderPlayer();
    refreshItems();
    updateNowPlaying();
    updateMediaSession();
    notifyNative();
    updateScreenLock();
  }

  function updateMediaSession() {
    if (!('mediaSession' in navigator)) return;
    var s = state.current;
    try {
      if (!s) { navigator.mediaSession.metadata = null; navigator.mediaSession.playbackState = 'none'; return; }
      var art = /^https?:\/\//i.test(s.favicon || '') ? [{ src: s.favicon, sizes: '512x512' }] : [];
      navigator.mediaSession.metadata = new MediaMetadata({ title: stationName(s), artist: stationLocation(s) || T().liveBroadcast, album: 'FREQMAN', artwork: art });
      navigator.mediaSession.playbackState = state.playing ? 'playing' : 'paused';
    } catch (e) { /* tidak didukung */ }
  }
  if ('mediaSession' in navigator) {
    try {
      navigator.mediaSession.setActionHandler('play', function () { if (!state.playing && !state.buffering) togglePlay(); });
      navigator.mediaSession.setActionHandler('pause', function () { if (state.playing || state.buffering) togglePlay(); });
      navigator.mediaSession.setActionHandler('stop', closePlayer);
    } catch (e) { /* tidak didukung */ }
  }

  // Jembatan ke aplikasi Android (notifikasi, layar kunci, putar di latar belakang)
  function notifyNative() {
    var bridge = window.FreqManAndroid;
    if (!bridge || !bridge.onPlaybackState) return;
    var s = state.current;
    var t = T();
    try {
      // Info tambahan untuk kontrol media di HP: status Live, cover art, atau warna + inisial
      bridge.onPlaybackState(!!s, !!(state.playing || state.buffering), s ? stationName(s) : '',
        s ? (stationLocation(s) || t.liveBroadcast) : '', t.pause, t.play, t.closePlayer,
        !!state.playing, t.live, s ? artUrl(s) : '', s ? tileColor(s) : '', s ? initials(stationName(s)) : '');
    } catch (e) { /* abaikan */ }
  }

  // ------------------------------------------------------------------ Laci negara
  var lastFocus = null;
  function openDrawer() {
    loadCountries();
    state.countryFilter = '';
    $('countrySearch').value = '';
    renderCountries();
    lastFocus = document.activeElement;
    $('drawer').hidden = false;
    document.body.classList.add('lock');
    setTimeout(function () { $('countryList').scrollTop = 0; }, 0);
  }
  function closeDrawer() {
    if ($('drawer').hidden) return false;
    $('drawer').hidden = true;
    document.body.classList.remove('lock');
    if (lastFocus && lastFocus.focus) lastFocus.focus();
    return true;
  }

  // ------------------------------------------------------------------ Sedang Diputar + Timer Tidur
  var SLEEP_OPTIONS = [0, 15, 30, 60, 90];
  var sleepTimer = null, sleepTick = null;
  function fmtLeft(ms) {
    var sec = Math.max(0, Math.round(ms / 1000)), h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), x = sec % 60;
    function two(n) { return (n < 10 ? '0' : '') + n; }
    return h ? h + ':' + two(m) + ':' + two(x) : m + ':' + two(x);
  }
  function setSleep(min, silent) {
    clearTimeout(sleepTimer);
    state.sleepEnd = min ? Date.now() + min * 60000 : 0;
    state.sleepMinutes = min || 0;
    // Di Android, layanan pemutar ikut menghitung agar tetap tepat saat aplikasi di latar belakang
    var bridge = window.FreqManAndroid;
    if (bridge && bridge.setSleepTimer) { try { bridge.setSleepTimer(min ? min * 60000 : 0); } catch (e) { /* abaikan */ } }
    if (min) {
      sleepTimer = setTimeout(sleepFired, min * 60000);
      if (!silent) toast('sleepSetTitle', T().sleepSetDesc(min), 'clock');
    }
    updateNowPlaying();
  }
  function sleepFired() {
    if (!state.sleepEnd) return;
    clearTimeout(sleepTimer);
    state.sleepEnd = 0; state.sleepMinutes = 0;
    if (state.playing || state.buffering) {
      teardown(); state.playing = false; state.buffering = false; syncPlayback();
    }
    toast('sleepEndTitle', 'sleepEndDesc', 'clock', true);
    updateNowPlaying();
  }

  function renderNowPlaying() {
    var s = state.current;
    if (!s) return;
    var t = T();
    var body = $('npBody');
    body.setAttribute('data-id', s.stationuuid);
    body.innerHTML =
      '<h2 id="npTitle" class="sr-only">' + esc(t.nowPlayingTitle) + '</h2>' +
      '<div class="np-art"><span' + mediaAttrs(s) + ' id="npMedia">' + mediaHtml(s, state.playing) + '</span></div>' +
      '<div class="np-info">' +
        '<div class="np-kicker"><span id="npKicker"></span><span id="npBadge"></span></div>' +
        '<div class="np-name">' + esc(stationName(s)) + '</div>' +
        '<div class="np-song" id="npSong"></div>' +
        '<div class="np-meta" id="npLoc"></div>' +
        '<div class="np-meta" id="npDetail"></div>' +
      '</div>' +
      '<div class="np-controls">' +
        '<button type="button" class="btn btn-outline btn-icon-lg" id="npFav"></button>' +
        '<button type="button" class="btn btn-default btn-icon-lg" id="npToggle"></button>' +
      '</div>' +
      '<section class="np-sleep">' +
        '<h3>' + esc(t.sleepTimer) + '</h3>' +
        '<div class="toggle-group np-sleep-group" role="radiogroup" aria-label="' + esc(t.sleepTimer) + '">' +
          SLEEP_OPTIONS.map(function (m) {
            return '<button type="button" role="radio" data-sleep="' + m + '">' + esc(m ? t.sleepMin(m) : t.sleepOff) + '</button>';
          }).join('') +
        '</div>' +
        '<p class="np-sleep-info" id="npSleepInfo"></p>' +
      '</section>';
    updateNowPlaying();
  }
  // Perbarui bagian yang berubah tanpa membangun ulang (logo tidak dimuat ulang)
  function updateNowPlaying() {
    if ($('np').hidden) return;
    var s = state.current;
    if (!s) { closeNp(); return; }
    var body = $('npBody');
    if (body.getAttribute('data-id') !== s.stationuuid) { renderNowPlaying(); return; }
    var t = T();
    setBars($('npMedia'), state.playing);
    $('npKicker').textContent = t.nowPlayingTitle;
    $('npBadge').innerHTML = (state.playing ? '<span class="badge badge-status badge-live"><span class="live-dot"></span>' + esc(t.live) + '</span>' : '') + qualityBadge(s);
    $('npSong').textContent = state.nowTitle ? '♪ ' + state.nowTitle : '';
    $('npSong').hidden = !state.nowTitle;
    $('npLoc').textContent = stationLocation(s) || t.liveBroadcast;
    var detail = stationDetail(s);
    $('npDetail').textContent = detail; $('npDetail').hidden = !detail;
    var fav = isFav(s.stationuuid);
    $('npFav').innerHTML = svg('heart', 16, { fill: fav });
    $('npFav').setAttribute('aria-pressed', String(fav));
    $('npFav').setAttribute('aria-label', fav ? t.removeFavorite : t.saveFavorite);
    var active = state.playing || state.buffering;
    $('npToggle').innerHTML = state.buffering ? svg('loader', 16, { cls: 'spinner' }) : svg(state.playing ? 'pause' : 'play', 16, { fill: true });
    $('npToggle').setAttribute('aria-label', active ? t.pause : t.play);
    Array.prototype.forEach.call(body.querySelectorAll('[data-sleep]'), function (b) {
      b.setAttribute('aria-checked', String(+b.getAttribute('data-sleep') === (state.sleepEnd ? state.sleepMinutes : 0)));
    });
    $('npSleepInfo').textContent = state.sleepEnd ? t.sleepLeft(fmtLeft(state.sleepEnd - Date.now())) : t.sleepIdle;
  }
  var npLastFocus = null;
  function openNp() {
    if (!state.current) return;
    npLastFocus = document.activeElement;
    $('np').hidden = false;
    document.body.classList.add('lock');
    renderNowPlaying();
    clearInterval(sleepTick);
    sleepTick = setInterval(function () { if (state.sleepEnd) updateNowPlaying(); }, 1000);
  }
  function closeNp() {
    if ($('np').hidden) return false;
    $('np').hidden = true;
    clearInterval(sleepTick);
    if ($('drawer').hidden && $('about').hidden) document.body.classList.remove('lock');
    if (npLastFocus && npLastFocus.focus) npLastFocus.focus();
    return true;
  }
  $('playerOpen').addEventListener('click', openNp);
  $('np').addEventListener('click', function (e) {
    if (e.target.closest('[data-close]')) { closeNp(); return; }
    var sl = e.target.closest('[data-sleep]');
    if (sl) { setSleep(+sl.getAttribute('data-sleep')); return; }
    if (e.target.closest('#npToggle')) { togglePlay(); return; }
    if (e.target.closest('#npFav') && state.current) { toggleFavorite(state.current); updateNowPlaying(); }
  });

  // ------------------------------------------------------------------ Tentang & Lisensi
  var LICENSES = [
    { name: 'Radio Browser', type: 'Public Domain', file: null, url: 'https://www.radio-browser.info' },
    { name: 'shadcn/ui', type: 'MIT', file: 'licenses/shadcn-ui-MIT.txt' }, // dasar desain antarmuka (warna, ukuran, gaya komponen)
    { name: 'Geist', type: 'SIL OFL 1.1', file: 'licenses/Geist-OFL.txt' },
    { name: 'Orbitron', type: 'SIL OFL 1.1', file: 'licenses/Orbitron-OFL.txt' },
    { name: 'Lucide Icons', type: 'ISC', file: 'licenses/Lucide-ISC.txt' },
    { name: 'hls.js', type: 'Apache 2.0', file: 'licenses/hlsjs-Apache-2.0.txt' }
  ];
  var EXTERNAL = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/></svg>';
  var CHEVRON = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>';
  function renderAbout() {
    var t = T();
    // Nama pengembang menjadi tautan email (subjek sudah terisi)
    var devName = CONTACT_EMAIL
      ? '<a href="mailto:' + esc(CONTACT_EMAIL) + '?subject=' + encodeURIComponent(t.ownersMailSubject) + '">' + esc(DEVELOPER) + '</a>'
      : esc(DEVELOPER);
    var contact = '<p>' + esc(t.ownersContact) + ' ' + devName + '.</p>';
    var rbLink = '<a href="https://www.radio-browser.info" target="_blank" rel="noopener">radio-browser.info</a>';
    var lic = LICENSES.map(function (l) {
      if (!l.file) {
        // Radio Browser: membuka situsnya (ikon tautan luar), bukan teks lisensi
        // Hanya ikon yang menjadi tautan; nama & lisensi teks biasa
        return '<div class="license"><div class="lic-link">' +
          '<span class="lic-name">' + esc(l.name) + '</span><span class="lic-type">' + esc(l.type) + '</span>' +
          '<a class="lic-ext" href="' + l.url + '" target="_blank" rel="noopener" aria-label="' + esc(l.name) + ': radio-browser.info">' + EXTERNAL + '</a>' +
          '</div></div>';
      }
      return '<details class="license" data-file="' + l.file + '"><summary><span class="lic-name">' + esc(l.name) + '</span><span class="lic-type">' + esc(l.type) + '</span>' + CHEVRON + '</summary><pre>' + esc(t.licenseLoading) + '</pre></details>';
    }).join('');
    $('aboutBody').innerHTML =
      '<div class="about-head">' +
        '<span class="mark" aria-hidden="true"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 10.5v3M8 7.5v9M12 4v16M16 7.5v9M20 10.5v3"/></svg></span>' +
        '<h2 id="aboutTitle" class="sr-only">' + esc(t.aboutTitle) + '</h2>' +
        '<span class="about-name">FREQMAN</span>' +
        '<span class="about-meta">Frequency Manager</span>' +
        '<span class="about-meta">' + esc(t.developedBy) + ' ' + esc(DEVELOPER) + '</span>' +
      '</div>' +
      '<section class="about-sec"><h3>' + esc(t.statementTitle) + '</h3><p>' + esc(t.statement1) + '</p><p>' + esc(t.statement2) + '</p></section>' +
      '<section class="about-sec"><h3>' + esc(t.sourceTitle) + '</h3><p>' + esc(t.source1) + ' <a href="https://www.radio-browser.info" target="_blank" rel="noopener">radio-browser.info</a></p></section>' +
      '<section class="about-sec"><h3>' + esc(t.ownersTitle) + '</h3><p>' + esc(t.owners1) + '</p>' + contact + '<p>' + esc(t.ownersFix) + ' ' + rbLink + '.</p></section>' +
      '<section class="about-sec"><h3>' + esc(t.privacyTitle) + '</h3><p>' + esc(t.privacy1) + '</p><p>' + esc(t.privacy2) + '</p></section>' +
      '<section class="about-sec"><h3>' + esc(t.licensesTitle) + '</h3><p>' + esc(t.licensesIntro) + '</p>' + lic + '</section>' +
      '<p class="about-copy">© 2026 FREQMAN. All Rights Reserved.<br>' + esc(t.version) + ' ' + APP_VERSION + '</p>';
    // Teks lisensi dimuat dari berkas yang ikut di dalam aplikasi saat dibuka
    Array.prototype.forEach.call($('aboutBody').querySelectorAll('details.license'), function (d) {
      d.addEventListener('toggle', function () {
        if (!d.open || d.getAttribute('data-loaded')) return;
        d.setAttribute('data-loaded', '1');
        fetch(d.getAttribute('data-file')).then(function (r) { return r.text(); })
          .then(function (txt) { d.querySelector('pre').textContent = txt; })
          .catch(function () { d.querySelector('pre').textContent = d.getAttribute('data-file'); });
      });
    });
  }
  var aboutLastFocus = null;
  function openAbout() {
    renderAbout();
    aboutLastFocus = document.activeElement;
    $('about').hidden = false;
    document.body.classList.add('lock');
    $('aboutBody').scrollTop = 0;
  }
  function closeAbout() {
    if ($('about').hidden) return false;
    $('about').hidden = true;
    if ($('drawer').hidden) document.body.classList.remove('lock');
    if (aboutLastFocus && aboutLastFocus.focus) aboutLastFocus.focus();
    return true;
  }
  $('aboutBtn').addEventListener('click', openAbout);
  $('about').addEventListener('click', function (e) { if (e.target.closest('[data-close]')) closeAbout(); });

  // Geser ke bawah untuk menutup laci negara (sentuh & mouse)
  function setupSheetSwipe(rootSel, scrollId, onClose) {
    var sheet = document.querySelector(rootSel + ' .drawer');
    var scrim = document.querySelector(rootSel + ' .scrim');
    var list = $(scrollId);
    var startY = 0, lastY = 0, lastT = 0, velocity = 0, dy = 0;
    var active = false, decided = false;

    function begin(y, target) {
      if (target.closest('input')) return false;
      var fromList = !!target.closest('#' + scrollId);
      if (fromList && list.scrollTop > 0) return false; // daftar sedang di-scroll
      active = true;
      decided = !fromList; // dari daftar: tunggu arah gerakan dulu
      startY = lastY = y; lastT = Date.now(); dy = 0; velocity = 0;
      return true;
    }
    function move(y, e) {
      if (!active) return;
      var delta = y - startY;
      if (!decided) {
        if (Math.abs(delta) < 6) return;
        if (delta < 0 || list.scrollTop > 0) { active = false; return; } // biarkan daftar scroll ke atas
        decided = true;
      }
      if (e && e.cancelable) e.preventDefault();
      var now = Date.now();
      velocity = (y - lastY) / Math.max(1, now - lastT);
      lastY = y; lastT = now;
      dy = Math.max(0, delta);
      sheet.classList.add('dragging');
      sheet.style.transform = 'translateY(' + dy + 'px)';
      scrim.style.opacity = String(Math.max(0, 1 - dy / sheet.offsetHeight));
    }
    function reset() {
      sheet.classList.remove('dragging', 'settling');
      scrim.classList.remove('settling');
      sheet.style.transform = '';
      scrim.style.opacity = '';
    }
    function end() {
      if (!active) return;
      active = false;
      if (!decided || dy === 0) { reset(); return; }
      sheet.classList.remove('dragging');
      sheet.classList.add('settling');
      scrim.classList.add('settling');
      var close = dy > Math.min(140, sheet.offsetHeight * 0.25) || velocity > 0.5;
      if (close) {
        sheet.style.transform = 'translateY(100%)';
        scrim.style.opacity = '0';
        setTimeout(function () { onClose(); reset(); }, 220);
      } else {
        sheet.style.transform = '';
        scrim.style.opacity = '';
        setTimeout(reset, 220);
      }
    }
    sheet.addEventListener('touchstart', function (e) { if (e.touches.length === 1) begin(e.touches[0].clientY, e.target); }, { passive: true });
    sheet.addEventListener('touchmove', function (e) { if (active) move(e.touches[0].clientY, e); }, { passive: false });
    sheet.addEventListener('touchend', end);
    sheet.addEventListener('touchcancel', end);
    sheet.addEventListener('mousedown', function (e) {
      if (!e.target.closest('.drawer-grab, .drawer-header, .about-head, .np-art')) return;
      if (begin(e.clientY, e.target)) e.preventDefault();
    });
    window.addEventListener('mousemove', function (e) { if (active) move(e.clientY, e); });
    window.addEventListener('mouseup', end);
  }
  setupSheetSwipe('#drawer', 'countryList', function () { closeDrawer(); });
  setupSheetSwipe('#about', 'aboutBody', function () { closeAbout(); });
  setupSheetSwipe('#np', 'npBody', function () { closeNp(); });

  // ------------------------------------------------------------------ Event
  function toggleFavorite(s) {
    var t = T();
    if (isFav(s.stationuuid)) {
      state.favorites = state.favorites.filter(function (f) { return f.stationuuid !== s.stationuuid; });
      toast('removedFromFavorites', stationName(s), 'heartOff');
    } else {
      state.favorites = [slim(s)].concat(state.favorites);
      toast('savedToFavorites', stationName(s), 'circleCheck');
    }
    store.set('favs', state.favorites);
    renderStatic();
    refreshItems();
    renderFavs();
  }

  function onListClick(e) {
    var btn = e.target.closest('[data-action]');
    if (!btn) return;
    var action = btn.getAttribute('data-action');
    var item = btn.closest('.item');
    var s = item ? findStation(item.getAttribute('data-id')) : null;
    if (action === 'play' && s) {
      if (state.current && state.current.stationuuid === s.stationuuid) togglePlay(); else playStation(s);
    } else if (action === 'fav' && s) {
      toggleFavorite(s);
    } else if (action === 'retry') {
      loadStations(true);
    } else if (action === 'more') {
      state.error = false; loadStations(false);
    } else if (action === 'clear') {
      setQuery('');
    } else if (action === 'country') {
      openDrawer();
    } else if (action === 'showAll') {
      state.sort = 'popular'; // kembali ke semua stasiun
      renderStatic(); loadStations(true);
    } else if (action === 'clearHistory') {
      state.history = []; store.set('history', []);
      renderHistory();
      toast('historyCleared', '', 'circleCheck');
    } else if (action === 'browse') {
      state.tab = 'browse'; renderStatic(); renderList();
    }
  }
  $('list').addEventListener('click', onListClick);
  $('favList').addEventListener('click', onListClick);
  $('histList').addEventListener('click', onListClick);

  var searchTimer = null;
  function setQuery(q) {
    state.query = q;
    $('search').value = q;
    $('clearSearch').hidden = !q;
    clearTimeout(searchTimer);
    searchTimer = setTimeout(function () { loadStations(true); }, q ? 400 : 0);
  }
  $('search').addEventListener('input', function (e) { setQuery(e.target.value); });
  $('search').addEventListener('keydown', function (e) { if (e.key === 'Enter') e.target.blur(); });
  $('clearSearch').addEventListener('click', function () { setQuery(''); $('search').focus(); });

  $('langGroup').addEventListener('click', function (e) {
    var b = e.target.closest('[data-lang]');
    if (!b) return;
    state.lang = b.getAttribute('data-lang');
    store.set('lang', state.lang);
    renderAll();
    renderThemeButton();
    renderToast();
    if (!$('about').hidden) renderAbout();
    if (!$('np').hidden) renderNowPlaying();
    if (!$('drawer').hidden) renderCountries();
    updateMediaSession(); notifyNative();
  });

  $('sortGroup').addEventListener('click', function (e) {
    var b = e.target.closest('[data-sort]');
    if (!b || b.getAttribute('data-sort') === state.sort) return;
    state.sort = b.getAttribute('data-sort');
    renderStatic();
    loadStations(true);
  });

  $('tabBrowse').addEventListener('click', function () { state.tab = 'browse'; renderStatic(); renderList(); });
  $('tabFav').addEventListener('click', function () { state.tab = 'fav'; renderStatic(); renderFavs(); });
  $('tabHist').addEventListener('click', function () { state.tab = 'hist'; renderStatic(); renderHistory(); });

  $('countryBtn').addEventListener('click', openDrawer);
  $('drawer').addEventListener('click', function (e) {
    if (e.target.closest('[data-close]')) { closeDrawer(); return; }
    var b = e.target.closest('[data-country]');
    if (!b) return;
    state.country = b.getAttribute('data-country');
    store.set('country', state.country);
    closeDrawer();
    renderStatic();
    window.scrollTo(0, 0);
    loadStations(true);
  });
  $('countrySearch').addEventListener('input', function (e) { state.countryFilter = e.target.value; renderCountries(); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') { if (!closeNp() && !closeAbout()) closeDrawer(); } });

  $('playerToggle').addEventListener('click', togglePlay);
  $('playerClose').addEventListener('click', closePlayer);

  function maybeLoadMore() {
    if (state.tab !== 'browse') return;
    var r = $('sentinel').getBoundingClientRect();
    if (r.top < window.innerHeight + 600) wantMoreStations();
  }
  // Dekat bawah daftar: cek stasiun berikutnya dulu, baru muat halaman katalog baru
  function wantMoreStations() {
    if (!growProbeHorizon()) loadStations(false);
  }
  if ('IntersectionObserver' in window) {
    new IntersectionObserver(function (entries) {
      if (entries.some(function (en) { return en.isIntersecting; })) wantMoreStations();
    }, { rootMargin: '600px 0px' }).observe($('sentinel'));
  } else {
    window.addEventListener('scroll', maybeLoadMore, { passive: true });
  }

  // API untuk aplikasi Android
  function onNativeTitle(title) {
    // Buang awalan yang sering ditulis stasiun sendiri (ikon ♪ sudah menandainya)
    title = String(title || '').trim().replace(/^(now\s*playing|np|on\s*air|playing|sedang\s*diputar)\s*[:\-–|]\s*/i, '').trim();
    if (!state.current || title === state.nowTitle) return;
    state.nowTitle = title;
    renderPlayer();
    updateNowPlaying();
  }

  window.FreqMan = {
    nativeState: onNativeState,
    nativeTitle: onNativeTitle,
    systemTheme: function (dark) { if (!themePref) applyTheme(dark ? 'dark' : 'light', false); },
    togglePlay: togglePlay,
    close: closePlayer,
    onBack: function () {
      if ($('splash')) return false;
      if (closeNp()) return true;
      if (closeAbout()) return true;
      if (closeDrawer()) return true;
      if (state.tab !== 'browse') { state.tab = 'browse'; renderStatic(); renderList(); return true; }
      return false;
    }
  };

  window.addEventListener('online', function () {
    if (state.waitingNetwork && state.current) { state.waitingNetwork = false; startStream(); }
  });

  // ------------------------------------------------------------------ Tema terang / gelap
  var themePref = store.get('theme', null); // 'light' | 'dark' | null (ikuti sistem)
  var splashActive = !!document.getElementById('splash'); // splash selalu gelap
  function currentTheme() { return document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light'; }
  function applyTheme(theme, save) {
    document.documentElement.setAttribute('data-theme', theme);
    var meta = $('themeColor');
    if (meta) meta.setAttribute('content', splashActive || theme === 'dark' ? '#0a0a0a' : '#ffffff');
    if (save) { themePref = theme; store.set('theme', theme); }
    renderThemeButton();
    var bridge = window.FreqManAndroid;
    if (bridge && bridge.onThemeChange) { try { bridge.onThemeChange(splashActive || theme === 'dark'); } catch (e) { /* abaikan */ } }
  }
  function renderThemeButton() {
    var t = T();
    var label = currentTheme() === 'dark' ? t.themeToLight : t.themeToDark;
    $('themeBtn').setAttribute('aria-label', label);
    $('themeBtn').setAttribute('title', label);
  }
  $('themeBtn').addEventListener('click', function () { applyTheme(currentTheme() === 'dark' ? 'light' : 'dark', true); });
  if (window.matchMedia) {
    var mq = window.matchMedia('(prefers-color-scheme: dark)');
    var onSystemTheme = function (e) { if (!themePref) applyTheme(e.matches ? 'dark' : 'light', false); };
    if (mq.addEventListener) mq.addEventListener('change', onSystemTheme); else if (mq.addListener) mq.addListener(onSystemTheme);
  }
  applyTheme(themePref || currentTheme(), false);

  // ------------------------------------------------------------------ Logo simetris
  // "Frequency Manager" diberi jarak huruf agar persis selebar "FREQMAN" (atau sebaliknya
  // bila tulisan kecil lebih lebar). Diukur di perangkat, jadi tepat untuk font apa pun.
  function fitLockups() {
    Array.prototype.forEach.call(document.querySelectorAll('[data-lockup-base]'), function (box) {
      var name = box.querySelector('[data-lockup="name"]');
      var tag = box.querySelector('[data-lockup="tag"]');
      if (!name || !tag) return;
      var base = parseFloat(box.getAttribute('data-lockup-base')) || 0;
      function set(el, ls) { el.style.letterSpacing = ls + 'px'; el.style.marginRight = (-ls) + 'px'; }
      function visible(el, ls) { return el.getBoundingClientRect().width - ls; }
      set(name, base); set(tag, 0);
      var nameW = visible(name, base), tagW = visible(tag, 0);
      if (!nameW || !tagW) return; // belum tampil
      var gapsName = Math.max(1, name.textContent.length - 1), gapsTag = Math.max(1, tag.textContent.length - 1);
      if (tagW < nameW) set(tag, (nameW - tagW) / gapsTag);
      else set(name, base + (tagW - nameW) / gapsName);
    });
  }
  fitLockups();
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(fitLockups);
  if (document.fonts && document.fonts.addEventListener) document.fonts.addEventListener('loadingdone', fitLockups);
  window.addEventListener('resize', fitLockups);

  // ------------------------------------------------------------------ Splash 5 detik
  // Katalog sudah mulai dimuat di belakang layar selama splash tampil.
  // Tampil sekali per pembukaan aplikasi; memuat ulang halaman di sesi yang sama tidak memunculkannya lagi.
  var SPLASH_MS = 5000;
  var splashSeen = false;
  try { splashSeen = sessionStorage.getItem('freqman:splash') === '1'; sessionStorage.setItem('freqman:splash', '1'); } catch (e) { /* abaikan */ }
  function endSplash(fade) {
    var sp = $('splash');
    if (!sp) return;
    splashActive = false;
    applyTheme(currentTheme(), false); // kembalikan warna status bar sesuai tema
    if ($('drawer').hidden) document.body.classList.remove('lock');
    if (!fade) { sp.parentNode.removeChild(sp); return; }
    sp.classList.add('hide');
    setTimeout(function () { if (sp.parentNode) sp.parentNode.removeChild(sp); }, 450);
  }
  if (splashSeen) endSplash(false); else setTimeout(function () { endSplash(true); }, SPLASH_MS);

  // ------------------------------------------------------------------ Layar tetap menyala
  // Hanya selama radio diputar (hemat baterai). Versi web: Screen Wake Lock browser;
  // di aplikasi Android diatur oleh Android lewat status pemutaran.
  var wakeLock = null;
  function updateScreenLock() {
    if (state.playing || state.buffering) keepScreenOn();
    else if (wakeLock) { try { wakeLock.release(); } catch (e) { /* abaikan */ } wakeLock = null; }
  }
  function keepScreenOn() {
    if (!(state.playing || state.buffering)) return;
    if (window.FreqManAndroid || wakeLock || !('wakeLock' in navigator) || document.visibilityState !== 'visible') return;
    navigator.wakeLock.request('screen').then(function (lock) {
      wakeLock = lock;
      lock.addEventListener('release', function () { wakeLock = null; });
    }).catch(function () { /* tidak didukung / ditolak browser */ });
  }
  document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'visible') keepScreenOn(); });
  document.addEventListener('pointerdown', keepScreenOn, { passive: true }); // sebagian browser butuh sentuhan dulu
  keepScreenOn();

  // ------------------------------------------------------------------ Mulai
  renderAll();
  loadBlocklist();
  loadCountries();
  loadStations(true);
})();
