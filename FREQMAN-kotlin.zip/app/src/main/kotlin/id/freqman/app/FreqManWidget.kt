package id.freqman.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.widget.RemoteViews

/**
 * Widget layar utama FREQMAN: logo stasiun, nama, judul lagu / "Live", dan tombol Putar/Jeda.
 * Mengetuk widget membuka aplikasi. Saat tidak ada yang diputar, widget mengajak membuka FREQMAN.
 */
class FreqManWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        // Dipanggil saat widget dipasang / HP dinyalakan ulang: tampilkan keadaan diam
        showIdle(context)
    }

    companion object {
        private fun openApp(c: Context): PendingIntent = PendingIntent.getActivity(
            c, 10, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        private fun push(c: Context, v: RemoteViews) {
            val m = AppWidgetManager.getInstance(c)
            val ids = m.getAppWidgetIds(ComponentName(c, FreqManWidget::class.java))
            if (ids != null && ids.isNotEmpty()) m.updateAppWidget(ids, v)
        }

        /** Sedang ada stasiun (diputar atau dijeda). */
        fun showPlaying(c: Context, title: String, subtitle: String, art: Bitmap?, playing: Boolean) {
            try {
                val v = RemoteViews(c.packageName, R.layout.widget_freqman)
                v.setTextViewText(R.id.widget_title, title)
                v.setTextViewText(R.id.widget_subtitle, subtitle)
                if (art != null) v.setImageViewBitmap(R.id.widget_art, art)
                else v.setImageViewResource(R.id.widget_art, R.drawable.ic_launcher_foreground)
                v.setImageViewResource(R.id.widget_toggle, if (playing) R.drawable.ic_pause else R.drawable.ic_play)
                v.setContentDescription(R.id.widget_toggle, if (playing) "Pause" else "Play")
                v.setOnClickPendingIntent(R.id.widget_root, openApp(c))
                // Layanan pemutar sedang berjalan, jadi tombol bisa langsung putar/jeda di latar belakang
                v.setOnClickPendingIntent(
                    R.id.widget_toggle, PendingIntent.getService(
                        c, 11, Intent(c, PlaybackService::class.java).setAction(PlaybackService.ACTION_TOGGLE),
                        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                    )
                )
                push(c, v)
            } catch (ignored: Exception) {
                // widget belum dipasang / launcher menolak: abaikan
            }
        }

        /** Tidak ada stasiun: ketuk untuk membuka aplikasi. */
        fun showIdle(c: Context) {
            try {
                val v = RemoteViews(c.packageName, R.layout.widget_freqman)
                v.setTextViewText(R.id.widget_title, "FREQMAN")
                v.setTextViewText(R.id.widget_subtitle, c.getString(R.string.widget_idle))
                v.setImageViewResource(R.id.widget_art, R.drawable.widget_mark)
                v.setImageViewResource(R.id.widget_toggle, R.drawable.ic_play)
                v.setContentDescription(R.id.widget_toggle, c.getString(R.string.widget_idle))
                v.setOnClickPendingIntent(R.id.widget_root, openApp(c))
                v.setOnClickPendingIntent(R.id.widget_toggle, openApp(c))
                push(c, v)
            } catch (ignored: Exception) {
            }
        }
    }
}
