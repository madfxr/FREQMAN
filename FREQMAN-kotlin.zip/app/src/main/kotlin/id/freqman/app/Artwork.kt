package id.freqman.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import java.net.HttpURLConnection
import java.net.URL

/** Cover art untuk notifikasi & widget: logo stasiun (alas putih seperti di aplikasi) atau kotak warna + inisial. */
object Artwork {
    private const val SIZE = 256

    /** Unduh logo stasiun; null bila gagal / kosong / terlalu kecil (sama seperti di aplikasi). */
    fun download(url: String, userAgent: String): Bitmap? {
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 6000
                readTimeout = 6000
                instanceFollowRedirects = true
                setRequestProperty("User-Agent", userAgent)
            }
            val src = conn.inputStream.use { BitmapFactory.decodeStream(it) } ?: return null
            if (src.width < 24 || src.height < 24) return null
            val out = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
            val c = Canvas(out)
            c.drawColor(Color.WHITE) // logo bulat/transparan tetap persegi
            val side = minOf(src.width, src.height)
            val left = (src.width - side) / 2
            val top = (src.height - side) / 2
            c.drawBitmap(
                src, Rect(left, top, left + side, top + side), RectF(0f, 0f, SIZE.toFloat(), SIZE.toFloat()),
                Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            )
            out
        } catch (e: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }

    fun initialsTile(color: String, initials: String): Bitmap {
        val out = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val bg = try { Color.parseColor(color) } catch (e: Exception) { Color.parseColor("#475569") }
        c.drawColor(bg)
        if (initials.isNotEmpty()) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                this.color = Color.WHITE
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
                textSize = SIZE * 0.34f
            }
            val fm = p.fontMetrics
            c.drawText(initials, SIZE / 2f, SIZE / 2f - (fm.ascent + fm.descent) / 2f, p)
        }
        return out
    }
}
