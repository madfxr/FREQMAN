package id.freqman.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.window.OnBackInvokedCallback
import android.window.OnBackInvokedDispatcher
import org.json.JSONArray
import java.io.ByteArrayInputStream
import java.io.IOException

/**
 * FREQMAN: menampilkan aplikasi web (assets/www) di WebView.
 * Berkas lokal disajikan lewat https://appassets.androidplatform.net agar font, penyimpanan lokal,
 * dan fetch ke Radio Browser API berjalan normal. Suara diputar oleh [PlaybackService] (ExoPlayer).
 */
class MainActivity : Activity() {

    companion object {
        const val HOST = "appassets.androidplatform.net"
        const val START_URL = "https://$HOST/index.html"
        private const val DARK = 0xFF0A0A0A.toInt()
        private const val LIGHT = 0xFFFFFFFF.toInt()

        @Volatile
        var instance: MainActivity? = null
            private set

        /** Dipanggil notifikasi / layar kunci / layanan untuk mengendalikan halaman. */
        fun runJs(script: String) {
            val a = instance ?: return
            a.runOnUiThread { a.web?.evaluateJavascript(script, null) }
        }
    }

    private var web: WebView? = null
    private lateinit var root: FrameLayout
    private var backCallback: OnBackInvokedCallback? = null

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        instance = this

        root = FrameLayout(this)
        val view = WebView(this).apply {
            setBackgroundColor(DARK)
            // Tanpa efek pantul/regang Android saat digeser melewati ujung halaman
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        web = view
        root.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        setupEdgeToEdge()
        applySystemBars(true) // splash selalu gelap; halaman memberi tahu tema setelahnya

        view.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            // Banyak stream radio masih memakai http://
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            allowFileAccess = false
            allowContentAccess = false
            userAgentString = "$userAgentString FREQMAN/1.0"
        }
        view.addJavascriptInterface(Bridge(), "FreqManAndroid")
        view.webViewClient = AssetClient()
        view.loadUrl(START_URL)

        registerBack()
        requestNotificationPermission()
    }

    // ------------------------------------------------------------ Edge-to-edge (wajib di Android 15+)

    /**
     * Android 15+ selalu menggambar aplikasi di bawah status bar & bar navigasi. Isi halaman diberi jarak
     * sebesar bar tersebut (dan keyboard), dan latar di belakang bar mengikuti warna tema.
     */
    private fun setupEdgeToEdge() {
        if (Build.VERSION.SDK_INT < 35) return
        root.setOnApplyWindowInsetsListener { v, insets ->
            val bars = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            val ime = insets.getInsets(WindowInsets.Type.ime())
            v.setPadding(bars.left, bars.top, bars.right, maxOf(bars.bottom, ime.bottom))
            WindowInsets.CONSUMED
        }
    }

    @Suppress("DEPRECATION")
    private fun applySystemBars(night: Boolean) {
        val bg = if (night) DARK else LIGHT
        root.setBackgroundColor(bg)
        if (Build.VERSION.SDK_INT < 35) {
            window.statusBarColor = bg
            window.navigationBarColor = bg
        }
        if (Build.VERSION.SDK_INT >= 30) {
            val mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            window.insetsController?.setSystemBarsAppearance(if (night) 0 else mask, mask)
        } else {
            var flags = 0
            if (!night) {
                flags = flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                if (Build.VERSION.SDK_INT >= 27) flags = flags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            }
            window.decorView.systemUiVisibility = flags
        }
    }

    // ------------------------------------------------------------ Penyaji berkas lokal

    private inner class AssetClient : WebViewClient() {
        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
            val url = request.url
            if (HOST != url.host) return null
            var path = url.path
            if (path.isNullOrEmpty() || path == "/") path = "/index.html"
            if (path.contains("..")) return notFound()
            return try {
                val input = assets.open("www$path")
                val mime = mimeFor(path)
                val textual = mime.startsWith("text/") || mime.contains("javascript") || mime.contains("json") || mime.contains("svg")
                WebResourceResponse(mime, if (textual) "utf-8" else null, input).apply {
                    responseHeaders = mapOf("Cache-Control" to "no-cache")
                }
            } catch (e: IOException) {
                notFound()
            }
        }

        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val url = request.url
            if (HOST == url.host) return false
            try {
                startActivity(Intent(Intent.ACTION_VIEW, url))
            } catch (ignored: Exception) {
                // tidak ada aplikasi untuk membuka tautan (mis. mailto: tanpa aplikasi email)
            }
            return true
        }
    }

    private fun notFound() =
        WebResourceResponse("text/plain", "utf-8", 404, "Not Found", emptyMap(), ByteArrayInputStream(ByteArray(0)))

    private fun mimeFor(path: String): String {
        val p = path.lowercase()
        return when {
            p.endsWith(".html") -> "text/html"
            p.endsWith(".js") -> "application/javascript"
            p.endsWith(".css") -> "text/css"
            p.endsWith(".json") || p.endsWith(".webmanifest") -> "application/json"
            p.endsWith(".svg") -> "image/svg+xml"
            p.endsWith(".png") -> "image/png"
            p.endsWith(".woff2") -> "font/woff2"
            p.endsWith(".txt") -> "text/plain"
            else -> "application/octet-stream"
        }
    }

    // ------------------------------------------------------------ Jembatan JavaScript

    inner class Bridge {
        /** Halaman mengenali pemutar ini: ExoPlayer cepat mulai di semua bitrate. */
        @JavascriptInterface
        fun engine(): String = "exoplayer"

        /** Halaman meminta pemutar Android memutar salah satu alamat (dicoba berurutan). */
        @JavascriptInterface
        fun nativePlay(urlsJson: String) {
            val urls = ArrayList<String>()
            try {
                val arr = JSONArray(urlsJson)
                for (i in 0 until arr.length()) urls.add(arr.getString(i))
            } catch (ignored: Exception) {
                // daftar kosong -> layanan melapor gagal
            }
            runOnUiThread { PlaybackService.play(this@MainActivity, urls) }
        }

        /** Timer tidur: layanan pemutar menghentikan radio tepat waktu walau aplikasi di latar belakang. */
        @JavascriptInterface
        fun setSleepTimer(ms: Long) {
            runOnUiThread { PlaybackService.setSleep(ms) }
        }

        @JavascriptInterface
        fun nativeStop() {
            runOnUiThread { PlaybackService.stopPlayback() }
        }

        /** Dipanggil saat tombol terang/gelap ditekan (atau tema sistem berubah). */
        @JavascriptInterface
        fun onThemeChange(dark: Boolean) {
            runOnUiThread {
                applySystemBars(dark)
                web?.setBackgroundColor(if (dark) DARK else LIGHT)
            }
        }

        @JavascriptInterface
        fun onPlaybackState(
            hasStation: Boolean, playing: Boolean, title: String, subtitle: String,
            pauseLabel: String, playLabel: String, closeLabel: String, live: Boolean,
            liveLabel: String, artUrl: String, tileColor: String, initials: String
        ) {
            runOnUiThread {
                // Layar tetap menyala hanya selama radio diputar (dan FREQMAN tampil di layar)
                if (hasStation && playing) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                if (hasStation) {
                    PlaybackService.update(
                        this@MainActivity, playing, title, subtitle, pauseLabel, playLabel, closeLabel,
                        live, liveLabel, artUrl, tileColor, initials
                    )
                } else {
                    PlaybackService.stop()
                }
            }
        }
    }

    // ------------------------------------------------------------ Navigasi & siklus hidup

    /** Tombol / gestur Kembali: halaman menutup lembar yang terbuka dulu; bila tidak ada, aplikasi ke latar belakang. */
    private fun handleBack() {
        val w = web
        if (w == null) {
            moveTaskToBack(true)
            return
        }
        w.evaluateJavascript("(window.FreqMan && window.FreqMan.onBack()) ? 'handled' : 'none'") { value ->
            if (value == null || !value.contains("handled")) moveTaskToBack(true) // radio tetap berputar
        }
    }

    private fun registerBack() {
        if (Build.VERSION.SDK_INT >= 33) {
            val cb = OnBackInvokedCallback { handleBack() }
            onBackInvokedDispatcher.registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT, cb)
            backCallback = cb
        }
    }

    @Deprecated("Android 12 ke bawah")
    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        handleBack()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Halaman yang memutuskan: ikut sistem, kecuali pengguna sudah memilih tema sendiri.
        web?.evaluateJavascript("window.FreqMan && FreqMan.systemTheme(${isNight()})", null)
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        if (Build.VERSION.SDK_INT >= 33) backCallback?.let { onBackInvokedDispatcher.unregisterOnBackInvokedCallback(it) }
        PlaybackService.stop()
        web?.apply {
            removeJavascriptInterface("FreqManAndroid")
            destroy()
        }
        web = null
        super.onDestroy()
    }

    private fun isNight(): Boolean =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

}
