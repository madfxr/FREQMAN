package id.freqman.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.drawable.Icon
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Metadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.extractor.metadata.icy.IcyInfo
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

/**
 * Menjaga radio tetap berputar saat aplikasi di latar belakang, memutar stream dengan Media3 ExoPlayer,
 * serta menampilkan notifikasi media dan kontrol layar kunci / headset (Putar, Jeda, Tutup).
 *
 * Halaman web tetap mengendalikan pemutaran: tombol di notifikasi / widget diteruskan ke halaman,
 * dan layanan melaporkan keadaan ('playing', 'buffering', 'error', 'stopped', 'sleep') serta judul lagu.
 */
@OptIn(markerClass = [UnstableApi::class])
class PlaybackService : Service() {

    companion object {
        private const val CHANNEL_ID = "playback"
        private const val NOTIFICATION_ID = 1
        private const val ACTION_UPDATE = "id.freqman.app.UPDATE"
        const val ACTION_TOGGLE = "id.freqman.app.TOGGLE"
        private const val ACTION_CLOSE = "id.freqman.app.CLOSE"
        private const val CUSTOM_CLOSE = "id.freqman.app.CUSTOM_CLOSE"
        private const val USER_AGENT = "FREQMAN/1.0 (Android)"

        // Batas waktu: setiap alamat 8 detik, total 15 detik untuk pemutar Android (sisanya pemutar web; batas total 30 detik)
        private const val PREPARE_TIMEOUT_MS = 8000L
        private const val TOTAL_BUDGET_MS = 15000L
        private const val STALL_TIMEOUT_MS = 10000L // siaran macet lebih dari 10 detik: sambung ulang
        private val HREF = Regex("(?i)href\\s*=\\s*\"([^\"]+)\"")

        @Volatile
        private var instance: PlaybackService? = null
        private var pendingUrls: ArrayList<String>? = null

        // ------------------------------------------------------------ API untuk MainActivity

        fun update(
            context: Context, playing: Boolean, title: String, subtitle: String,
            pauseLabel: String, playLabel: String, closeLabel: String,
            live: Boolean, liveLabel: String, artUrl: String, tileColor: String, initials: String
        ) {
            val i = Intent(context, PlaybackService::class.java)
                .setAction(ACTION_UPDATE)
                .putExtra("playing", playing)
                .putExtra("title", title)
                .putExtra("subtitle", subtitle)
                .putExtra("pause", pauseLabel)
                .putExtra("play", playLabel)
                .putExtra("close", closeLabel)
                .putExtra("live", live)
                .putExtra("liveLabel", liveLabel)
                .putExtra("art", artUrl)
                .putExtra("color", tileColor)
                .putExtra("initials", initials)
            val s = instance
            if (s != null) {
                s.apply(i)
                return
            }
            try {
                context.startForegroundService(i)
            } catch (ignored: Exception) {
                // Android menolak memulai layanan dari latar belakang; audio tetap jalan selama aplikasi hidup.
            }
        }

        fun stop() {
            instance?.shutdown()
        }

        /** Putar daftar alamat stream secara berurutan sampai ada yang berhasil. */
        fun play(context: Context, urls: ArrayList<String>) {
            val s = instance
            if (s != null) {
                s.startPlayback(urls)
                return
            }
            pendingUrls = urls
            try {
                context.startForegroundService(
                    Intent(context, PlaybackService::class.java).setAction(ACTION_UPDATE).putExtra("playing", true)
                )
            } catch (e: Exception) {
                pendingUrls = null
                notifyJs("error")
            }
        }

        fun stopPlayback() {
            instance?.stopPlayer()
        }

        /** Timer tidur dari halaman; 0 = batalkan. */
        fun setSleep(ms: Long) {
            val s = instance ?: return // tanpa layanan aktif, timer di halaman yang bekerja
            s.sleepHandler.removeCallbacks(s.sleepRunnable)
            if (ms > 0) s.sleepHandler.postDelayed(s.sleepRunnable, ms)
        }

        private fun notifyJs(state: String) {
            MainActivity.runJs("window.FreqMan && FreqMan.nativeState && FreqMan.nativeState('$state')")
        }

        private fun isHls(url: String): Boolean =
            Uri.parse(url).path?.lowercase()?.endsWith(".m3u8") == true

        private fun isPlaylist(url: String): Boolean {
            val path = Uri.parse(url).path?.lowercase() ?: return false
            return path.endsWith(".pls") || path.endsWith(".m3u") || path.endsWith(".asx") || path.endsWith(".xspf")
        }

        private fun text(value: String?, fallback: String) = if (value.isNullOrEmpty()) fallback else value
    }

    private val handler = Handler(Looper.getMainLooper())
    private val sleepHandler = Handler(Looper.getMainLooper()) // terpisah: tidak ikut terhapus saat ganti stasiun

    private var session: MediaSession? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var playing = false

    // ------------------------------------------------------------ Pemutar (Media3 ExoPlayer)

    private var exo: ExoPlayer? = null
    private val candidates = ArrayList<String>()
    private var candidateIndex = 0
    private var currentUrl: String? = null
    private var everPlayed = false
    private var reconnects = 0
    private var token = 0
    private var playbackStartedAt = 0L
    private var songTitle: String? = null

    private val sleepRunnable = Runnable {
        stopPlayer()
        notifyJs("sleep") // halaman menampilkan "Timer Tidur Selesai"
    }

    private val prepareTimeout = Runnable { failCurrent() } // server tidak merespons: coba alamat berikutnya

    private val stallWatchdog = Runnable {
        val url = currentUrl
        if (reconnects < 2 && url != null) {
            reconnects++
            open(url) // sambung ulang alamat yang sama
        } else {
            failCurrent() // tetap macet: coba alamat berikutnya
        }
    }

    private fun buildPlayer(): ExoPlayer {
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(USER_AGENT)
            .setAllowCrossProtocolRedirects(true) // banyak stasiun mengalihkan http <-> https
            .setConnectTimeoutMs(8000)
            .setReadTimeoutMs(12000)
        // Mulai bersuara setelah 1 detik audio (bukan menunggu buffer besar): cepat di semua bitrate
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15000, 50000, 1000, 2000)
            .build()
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()
        return ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(this).setDataSourceFactory(DefaultDataSource.Factory(this, http)))
            .setLoadControl(loadControl)
            .setAudioAttributes(audioAttributes, true) // jeda saat telepon, pelankan saat navigasi bersuara
            .setHandleAudioBecomingNoisy(true)          // headset dicabut: berhenti
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()
            .also { it.addListener(listener) }
    }

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            if (!isPlaying) return
            handler.removeCallbacks(prepareTimeout)
            handler.removeCallbacks(stallWatchdog)
            everPlayed = true
            notifyJs("playing")
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            val p = exo ?: return
            when (playbackState) {
                Player.STATE_BUFFERING -> if (everPlayed) {
                    notifyJs("buffering")
                    handler.removeCallbacks(stallWatchdog)
                    handler.postDelayed(stallWatchdog, STALL_TIMEOUT_MS)
                }
                Player.STATE_ENDED -> {
                    // Siaran langsung tidak pernah "selesai": koneksi putus, sambung ulang (maks. 2x)
                    val url = currentUrl
                    if (everPlayed && reconnects < 2 && url != null) {
                        reconnects++
                        notifyJs("buffering")
                        val tok = token
                        handler.postDelayed({ if (tok == token) open(url) }, 1000)
                    } else {
                        failCurrent()
                    }
                }
                Player.STATE_READY -> if (p.playWhenReady) handler.removeCallbacks(stallWatchdog)
                else -> Unit
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            // Sempat berbunyi lalu putus (mis. ganti Wi-Fi ke data): sambung ulang alamat yang sama
            val url = currentUrl
            if (everPlayed && reconnects < 2 && url != null) {
                reconnects++
                notifyJs("buffering")
                val tok = token
                handler.postDelayed({ if (tok == token) open(url) }, 1500)
            } else {
                failCurrent()
            }
        }

        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
            // Aplikasi lain memutar audio, atau headset dicabut: berhenti dan beri tahu halaman
            if (!playWhenReady && (reason == Player.PLAY_WHEN_READY_CHANGE_REASON_AUDIO_FOCUS_LOSS ||
                        reason == Player.PLAY_WHEN_READY_CHANGE_REASON_AUDIO_BECOMING_NOISY)
            ) {
                stopPlayer()
                notifyJs("stopped")
            }
        }

        override fun onMetadata(metadata: Metadata) {
            // Judul lagu yang dikirim stasiun (metadata ICY / "StreamTitle")
            for (i in 0 until metadata.length()) {
                val entry = metadata.get(i)
                if (entry is IcyInfo) {
                    val title = entry.title?.trim().orEmpty()
                    if (title.isNotEmpty() && title != "-" && title != songTitle) {
                        songTitle = title
                        MainActivity.runJs("window.FreqMan && FreqMan.nativeTitle && FreqMan.nativeTitle(" + JSONObject.quote(title) + ")")
                        lastIntent?.let { apply(it) }
                    }
                }
            }
        }
    }

    private fun startPlayback(urls: List<String>) {
        stopPlayer()
        songTitle = null
        candidates.clear()
        candidates.addAll(urls)
        candidateIndex = 0
        everPlayed = false
        reconnects = 0
        playbackStartedAt = SystemClock.elapsedRealtime()
        tryNext()
    }

    private fun tryNext() {
        releasePlayer()
        val overBudget = !everPlayed && SystemClock.elapsedRealtime() - playbackStartedAt > TOTAL_BUDGET_MS
        if (candidateIndex >= candidates.size || overBudget) {
            stopPlayer()
            notifyJs("error")
            return
        }
        val url = candidates[candidateIndex++]
        if (isPlaylist(url)) resolvePlaylist(url, token) else open(url)
    }

    private fun open(url: String) {
        currentUrl = url
        val p = exo ?: buildPlayer().also { exo = it }
        handler.removeCallbacks(prepareTimeout)
        handler.removeCallbacks(stallWatchdog)
        try {
            val item = MediaItem.Builder().setUri(url)
            if (isHls(url)) item.setMimeType(MimeTypes.APPLICATION_M3U8)
            p.setMediaItem(item.build())
            p.prepare()
            p.playWhenReady = true
            if (!everPlayed) handler.postDelayed(prepareTimeout, PREPARE_TIMEOUT_MS)
        } catch (e: Exception) {
            failCurrent()
        }
    }

    private fun failCurrent() {
        handler.removeCallbacks(prepareTimeout)
        releasePlayer()
        tryNext()
    }

    /** Ambil alamat stream asli dari file playlist (.pls/.m3u/.asx) di latar belakang. */
    private fun resolvePlaylist(url: String, tok: Int) {
        Thread {
            val found = ArrayList<String>()
            var conn: HttpURLConnection? = null
            try {
                conn = (URL(url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 8000
                    readTimeout = 8000
                    instanceFollowRedirects = true
                    setRequestProperty("User-Agent", USER_AGENT)
                }
                BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8)).use { reader ->
                    var lines = 0
                    while (lines++ < 500) {
                        var line = reader.readLine()?.trim() ?: break
                        if (line.lowercase().startsWith("file") && line.contains("=")) line = line.substringAfter('=').trim()
                        HREF.find(line)?.let { line = it.groupValues[1].trim() }
                        if ((line.startsWith("http://") || line.startsWith("https://")) && line !in found) found.add(line)
                    }
                }
            } catch (ignored: Exception) {
                // playlist tidak bisa dibaca: lanjut ke alamat berikutnya
            } finally {
                conn?.disconnect()
            }
            handler.post {
                if (tok != token) return@post
                candidates.addAll(candidateIndex, found)
                tryNext()
            }
        }.start()
    }

    private fun releasePlayer() {
        handler.removeCallbacks(prepareTimeout)
        handler.removeCallbacks(stallWatchdog)
        exo?.let {
            try {
                it.stop()
                it.clearMediaItems()
            } catch (ignored: Exception) {
            }
        }
    }

    private fun stopPlayer() {
        token++
        handler.removeCallbacksAndMessages(null)
        releasePlayer()
        candidates.clear()
        currentUrl = null
    }

    // ------------------------------------------------------------ Siklus hidup

    override fun onCreate() {
        super.onCreate()
        instance = this

        val nm = getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(CHANNEL_ID, getString(R.string.channel_name), NotificationManager.IMPORTANCE_LOW)
        channel.setShowBadge(false)
        nm.createNotificationChannel(channel)

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "FreqMan:playback").apply { setReferenceCounted(false) }
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        @Suppress("DEPRECATION")
        wifiLock = wm?.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "FreqMan:playback")?.apply { setReferenceCounted(false) }

        session = MediaSession(this, "FreqMan").apply {
            setCallback(object : MediaSession.Callback() {
                override fun onPlay() {
                    if (!playing) MainActivity.runJs("window.FreqMan && FreqMan.togglePlay()")
                }

                override fun onPause() {
                    if (playing) MainActivity.runJs("window.FreqMan && FreqMan.togglePlay()")
                }

                override fun onStop() {
                    MainActivity.runJs("window.FreqMan && FreqMan.close()")
                }

                override fun onCustomAction(action: String, extras: Bundle?) {
                    // Tombol X di kontrol media Android 13+ (sama dengan tombol X di aplikasi)
                    if (CUSTOM_CLOSE == action) MainActivity.runJs("window.FreqMan && FreqMan.close()")
                }
            })
            setSessionActivity(
                PendingIntent.getActivity(
                    this@PlaybackService, 3,
                    Intent(this@PlaybackService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            )
            isActive = true
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_UPDATE -> {
                apply(intent)
                pendingUrls?.let {
                    pendingUrls = null
                    startPlayback(it)
                }
            }
            ACTION_TOGGLE -> if (MainActivity.instance == null) shutdown() else MainActivity.runJs("window.FreqMan && FreqMan.togglePlay()")
            ACTION_CLOSE -> if (MainActivity.instance == null) shutdown() else MainActivity.runJs("window.FreqMan && FreqMan.close()")
            else -> shutdown()
        }
        return START_NOT_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        shutdown()
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        stopPlayer()
        sleepHandler.removeCallbacksAndMessages(null)
        exo?.release()
        exo = null
        FreqManWidget.showIdle(this)
        releaseLocks()
        session?.let {
            it.isActive = false
            it.release()
        }
        session = null
        if (instance === this) instance = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ------------------------------------------------------------ Notifikasi, widget & kunci

    private var lastIntent: Intent? = null

    private fun apply(i: Intent) {
        lastIntent = i
        playing = i.getBooleanExtra("playing", false)
        val title = text(i.getStringExtra("title"), "FREQMAN")
        val location = text(i.getStringExtra("subtitle"), "")
        val pauseLabel = text(i.getStringExtra("pause"), "Pause")
        val playLabel = text(i.getStringExtra("play"), "Play")
        val closeLabel = text(i.getStringExtra("close"), "Close")
        val live = i.getBooleanExtra("live", false)
        val liveLabel = text(i.getStringExtra("liveLabel"), "Live")
        // Android tidak punya tempat badge di kontrol media: "Live" ditulis di baris kedua
        val info = songTitle ?: location // judul lagu bila dikirim stasiun
        val subtitle = if (live) "\uD83D\uDD34 $liveLabel" + (if (info.isEmpty()) "" else " \u00B7 $info") else location
        val art = artworkFor(i)
        val s = session ?: return

        val meta = MediaMetadata.Builder()
            .putString(MediaMetadata.METADATA_KEY_TITLE, title)
            .putString(MediaMetadata.METADATA_KEY_ARTIST, subtitle)
            .putString(MediaMetadata.METADATA_KEY_ALBUM, "FREQMAN")
        if (art != null) {
            meta.putBitmap(MediaMetadata.METADATA_KEY_ART, art)
            meta.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, art)
            meta.putBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON, art)
        }
        s.setMetadata(meta.build())
        s.setPlaybackState(
            PlaybackState.Builder()
                .setActions(
                    PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or
                            PlaybackState.ACTION_PLAY_PAUSE or PlaybackState.ACTION_STOP
                )
                .addCustomAction(PlaybackState.CustomAction.Builder(CUSTOM_CLOSE, closeLabel, R.drawable.ic_close).build())
                .setState(
                    if (playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED,
                    PlaybackState.PLAYBACK_POSITION_UNKNOWN, 1f
                )
                .build()
        )

        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val toggle = PendingIntent.getService(
            this, 1, Intent(this, PlaybackService::class.java).setAction(ACTION_TOGGLE),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val close = PendingIntent.getService(
            this, 2, Intent(this, PlaybackService::class.java).setAction(ACTION_CLOSE),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val nb = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_freqman)
            .setContentTitle(title)
            .setContentText(subtitle)
            .setContentIntent(openApp)
            .setDeleteIntent(close)
            .setOngoing(playing)
            .setShowWhen(false)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_TRANSPORT)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, if (playing) R.drawable.ic_pause else R.drawable.ic_play),
                    if (playing) pauseLabel else playLabel, toggle
                ).build()
            )
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_close), closeLabel, close).build())
            .setStyle(Notification.MediaStyle().setMediaSession(s.sessionToken).setShowActionsInCompactView(0, 1))
        if (art != null) nb.setLargeIcon(art)
        val notification = nb.build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        if (playing) acquireLocks() else releaseLocks()
        FreqManWidget.showPlaying(this, title, subtitle, art, playing)
    }

    // ------------------------------------------------------------ Cover art untuk kontrol media

    private var artKey: String? = null        // stasiun yang art-nya sedang tersimpan
    private var artBitmap: Bitmap? = null
    private var artLoadingKey: String? = null // sedang diunduh

    /** Cover art resmi (alas putih seperti di aplikasi), atau kotak warna + inisial bila tidak ada / gagal. */
    private fun artworkFor(i: Intent): Bitmap? {
        val url = text(i.getStringExtra("art"), "")
        val color = text(i.getStringExtra("color"), "#475569")
        val initials = text(i.getStringExtra("initials"), "")
        val key = "$url|$color|$initials"
        val cached = artBitmap
        if (key == artKey && cached != null) return cached
        if (url.isEmpty()) {
            artKey = key
            return Artwork.initialsTile(color, initials).also { artBitmap = it }
        }
        if (key != artLoadingKey) {
            artLoadingKey = key
            Thread {
                val loaded = Artwork.download(url, USER_AGENT)
                handler.post {
                    if (key != artLoadingKey) return@post // stasiun sudah berganti
                    artLoadingKey = null
                    artKey = key
                    artBitmap = loaded ?: Artwork.initialsTile(color, initials)
                    if (instance === this) lastIntent?.let { apply(it) }
                }
            }.start()
        }
        return Artwork.initialsTile(color, initials) // sementara, sampai cover art selesai diunduh
    }

    private fun shutdown() {
        stopPlayer()
        sleepHandler.removeCallbacksAndMessages(null)
        FreqManWidget.showIdle(this)
        releaseLocks()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        if (instance === this) instance = null
    }

    private fun acquireLocks() {
        wakeLock?.let { if (!it.isHeld) it.acquire() }
        wifiLock?.let { if (!it.isHeld) it.acquire() }
    }

    private fun releaseLocks() {
        wakeLock?.let { if (it.isHeld) it.release() }
        wifiLock?.let { if (it.isHeld) it.release() }
    }
}
