plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Kunci tanda tangan dibaca dari variabel lingkungan (GitHub Secrets di workflow).
// Tanpa kunci (mis. build lokal pertama kali), APK ditandatangani kunci debug.
val releaseKeystore: String? = System.getenv("FREQMAN_KEYSTORE")

android {
    namespace = "id.freqman.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "id.freqman.app"
        minSdk = 26
        targetSdk = 36
        // Versi dikunci 1.0 selama pengembangan; versionCode dinaikkan agar terpasang di atas build lama (6).
        versionCode = 7
        versionName = "1.0"
    }

    signingConfigs {
        create("release") {
            if (!releaseKeystore.isNullOrBlank()) {
                storeFile = file(releaseKeystore)
                storePassword = System.getenv("FREQMAN_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("FREQMAN_KEY_ALIAS") ?: "freqman"
                keyPassword = System.getenv("FREQMAN_KEY_PASSWORD") ?: System.getenv("FREQMAN_KEYSTORE_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = if (releaseKeystore.isNullOrBlank()) signingConfigs.getByName("debug")
            else signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    sourceSets {
        getByName("main") {
            java.srcDirs("src/main/kotlin")
        }
    }

    lint {
        // Lint tidak boleh menggagalkan build rilis di GitHub Actions
        checkReleaseBuilds = false
        abortOnError = false
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}

dependencies {
    // Pemutar radio: Media3 ExoPlayer (+ HLS)
    implementation("androidx.media3:media3-exoplayer:1.6.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.6.1")
}
