// Kerangka uji kecil: memuat aplikasi web FREQMAN di browser simulasi (jsdom)
const { JSDOM } = require('jsdom');
const fs = require('fs');
const path = require('path');
const WEB = process.env.FREQMAN_WEB || path.join(__dirname, '..', 'app', 'src', 'main', 'assets', 'www');

const later = (value, err) => new Promise((res, rej) => setTimeout(() => (err ? rej(err) : res(value)), 2));

function boot(opts = {}) {
  const html = fs.readFileSync(path.join(WEB, 'index.html'), 'utf8').replace('<script src="app.js"></script>', '');
  const dom = new JSDOM(html, { url: 'https://freqman.test/', runScripts: 'outside-only', pretendToBeVisual: true });
  const w = dom.window, d = w.document;
  const log = { api: [], probes: 0, probedHosts: new Set(), played: [], bridge: [], wake: 0, seq: [] };
  Object.entries(opts.storage || {}).forEach(([k, v]) => w.localStorage.setItem('freqman:' + k, JSON.stringify(v)));
  if (opts.session) Object.entries(opts.session).forEach(([k, v]) => w.sessionStorage.setItem(k, v));
  w.fetch = (url, init) => {
    if (/radio-browser/.test(url)) {
      log.api.push(url);
      // Katalog palsu: halaman kedua dst. kosong, dan jawaban selalu asinkron seperti jaringan sungguhan
      const body = /offset=(?!0&)\d+/.test(url) ? [] : (opts.api ? opts.api(url) : []);
      return later({ ok: true, json: () => Promise.resolve(body) });
    }
    if (url === 'blocklist.json') return Promise.resolve({ ok: true, json: () => Promise.resolve(opts.blocklist || {}) });
    if (url.startsWith('licenses/')) return Promise.resolve({ ok: true, text: () => Promise.resolve('LICENSE ' + url) });
    log.probes++; log.probedHosts.add(String(url).replace(/^https?:\/\//, '').split('/')[0]);
    const b = opts.probe ? opts.probe(url) : 'ok';
    if (b === 'ok') return later({ type: 'opaque' });
    if (b === 'dead') return later(null, new TypeError('Failed to fetch'));
    if (b === 'slow') return new Promise((res) => { const prev = w.__releaseSlow; w.__releaseSlow = () => { if (prev) prev(); res({ type: 'opaque' }); }; });
    return new Promise((res, rej) => { if (init && init.signal) init.signal.addEventListener('abort', () => { const e = new Error('abort'); e.name = 'AbortError'; rej(e); }); });
  };
  w.IntersectionObserver = class { observe() {} };
  w.HTMLMediaElement.prototype.load = () => {};
  w.HTMLMediaElement.prototype.pause = function () { this.dispatchEvent(new w.Event('pause')); };
  w.HTMLMediaElement.prototype.play = function () {
    const src = this.getAttribute('src'); log.played.push(src); log.seq.push('web');
    const ok = opts.plays ? opts.plays(src) : true;
    setTimeout(() => this.dispatchEvent(new w.Event(ok ? 'playing' : 'error')), 3);
    return Promise.resolve();
  };
  if (opts.wakeLock) Object.defineProperty(w.navigator, 'wakeLock', { value: { request: () => { log.wake++; const l = new w.EventTarget(); l.release = () => l.dispatchEvent(new w.Event('release')); return Promise.resolve(l); } } });
  if (opts.bridge) w.FreqManAndroid = new Proxy({}, { get: (_, name) => (...a) => { if (name === 'nativePlay') log.seq.push('native'); log.bridge.push([name, ...a]); if (name === 'engine') return opts.engine || ''; } });
  Object.defineProperty(w.HTMLElement.prototype, 'offsetHeight', { configurable: true, get() { return this.classList && this.classList.contains('drawer') ? 700 : 0; } });
  if (opts.longScreen) {
    const orig = w.HTMLElement.prototype.getBoundingClientRect;
    w.HTMLElement.prototype.getBoundingClientRect = function () { return this.id === 'sentinel' ? { top: 99999, bottom: 99999, left: 0, right: 0, width: 0, height: 0 } : orig.call(this); };
  }
  w.eval(fs.readFileSync(path.join(WEB, 'app.js'), 'utf8'));
  const $ = (q) => d.querySelector(q), $$ = (q) => [...d.querySelectorAll(q)];
  return { w, d, $, $$, log, wait: (ms) => new Promise((r) => setTimeout(r, ms)) };
}

const station = (id, extra = {}) => Object.assign({ stationuuid: id, name: 'Radio ' + id, url_resolved: 'https://' + id + '.ex/live', url: 'https://' + id + '.ex/live', countrycode: 'ID', country: 'Indonesia', state: 'DKI Jakarta', codec: 'MP3', bitrate: 128, clickcount: 0, tags: 'pop' }, extra);

let passed = 0, failed = 0;
async function test(name, fn) {
  try { await fn(); passed++; console.log('  ✓ ' + name); }
  catch (e) { failed++; console.log('  ✗ ' + name + '\n      ' + (e && e.message)); }
}
function ok(cond, msg) { if (!cond) throw new Error(msg || 'assertion failed'); }
function eq(a, b, msg) { if (JSON.stringify(a) !== JSON.stringify(b)) throw new Error((msg || 'not equal') + ': ' + JSON.stringify(a) + ' !== ' + JSON.stringify(b)); }
function summary() { console.log('\n' + passed + ' lulus, ' + failed + ' gagal'); process.exit(failed ? 1 : 0); }

module.exports = { boot, station, test, ok, eq, summary };
