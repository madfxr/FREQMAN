// Jalankan:  npm install && npm test
const { boot, station, test, ok, eq, summary } = require('./harness');
const SEEN = { 'freqman:splash': '1' }; // lewati splash 5 detik agar tes cepat

(async () => {
  console.log('Daftar & pencarian');
  await test('hanya stasiun yang servernya menjawab yang tampil', async () => {
    const st = [station('A'), station('B'), station('C')];
    const app = boot({ session: SEEN, api: (u) => (u.includes('/search') ? st : []), probe: (u) => (u.includes('B.ex') ? 'dead' : 'ok') });
    await app.wait(400);
    eq(app.$$('#list .item-title').map((e) => e.textContent), ['Radio A', 'Radio C']);
  });
  await test('format tidak didukung (WMA, mms) disembunyikan', async () => {
    const st = [station('A'), station('W', { codec: 'WMA' }), station('M', { url_resolved: 'mms://x/a', url: 'mms://x/a' })];
    const app = boot({ session: SEEN, api: (u) => (u.includes('/search') ? st : []) });
    await app.wait(400);
    eq(app.$$('#list .item-title').map((e) => e.textContent), ['Radio A']);
  });
  await test('pencarian mencakup nama, genre, dan kota', async () => {
    const app = boot({ session: SEEN, api: (u) => {
      if (!u.includes('/search')) return [];
      if (u.includes('name=jazz')) return [station('N', { name: 'Jazz FM', clickcount: 5 })];
      if (u.includes('tag=jazz')) return [station('T', { name: 'Smooth Radio', tags: 'jazz', clickcount: 9 })];
      if (u.includes('state=jazz')) return [];
      return [];
    } });
    await app.wait(300);
    app.w.document.getElementById('search').value = 'jazz';
    app.$('#search').dispatchEvent(new app.w.Event('input'));
    await app.wait(900);
    const q = app.log.api.filter((u) => u.includes('jazz'));
    ok(q.some((u) => u.includes('name=jazz')) && q.some((u) => u.includes('tag=jazz')) && q.some((u) => u.includes('state=jazz')), 'tiga jenis pencarian dikirim');
    eq(app.$$('#list .item-title').map((e) => e.textContent), ['Smooth Radio', 'Jazz FM'], 'digabung & diurutkan terpopuler');
  });
  await test('hemat kuota: hanya ±24 stasiun yang dicek di awal', async () => {
    const st = Array.from({ length: 60 }, (_, i) => station('S' + i));
    const app = boot({ session: SEEN, longScreen: true, api: (u) => (u.includes('/search') ? st : []) });
    await app.wait(500);
    ok(app.log.probedHosts.size <= 24, 'stasiun yang dicek di awal: ' + app.log.probedHosts.size);
    ok(app.$$('#list .item').length === 24, 'stasiun tampil: ' + app.$$('#list .item').length);
  });
  await test('stasiun terblokir hilang dari daftar dan favorit', async () => {
    const st = [station('A'), station('B')];
    const app = boot({ session: SEEN, storage: { favs: [station('B')] }, blocklist: { stations: ['B'] }, api: (u) => (u.includes('/search') ? st : []) });
    await app.wait(400);
    eq(app.$$('#list .item-title').map((e) => e.textContent), ['Radio A']);
    app.$('#tabFav').click(); await app.wait(5);
    eq(app.$$('#favList .item').length, 0);
  });
  await test('label jumlah: "di Katalog" / "in Catalog"', async () => {
    const app = boot({ session: SEEN, storage: { lang: 'id', country: '' }, api: (u) => (u.includes('/countries') ? [{ name: 'Indonesia', iso_3166_1: 'ID', stationcount: 616 }] : []) });
    await app.wait(100);
    ok(/616 di Katalog/.test(app.$('#countBadge').textContent), app.$('#countBadge').textContent);
    app.$('#langGroup [data-lang=en]').click();
    ok(/616 in Catalog/.test(app.$('#countBadge').textContent), app.$('#countBadge').textContent);
  });

  await test('penanda kualitas: HQ (≥256 kbps) dan HQ+ (lossless/FLAC)', async () => {
    const st = [station('A', { name: 'Biasa', bitrate: 128 }), station('B', { name: 'Jernih', bitrate: 320 }), station('C', { name: 'Murni', codec: 'FLAC', bitrate: 0 })];
    const app = boot({ session: SEEN, api: (u) => (u.includes('/search') ? st : []) });
    await app.wait(400);
    const badges = app.$$('#list .item').map((i) => i.querySelector('.item-title').textContent + ':' + ((i.querySelector('.q-badge') || {}).textContent || '-'));
    eq(badges, ['Biasa:-', 'Jernih:HQ', 'Murni:HQ+']);
  });
  await test('HQ tanpa hasil: pesan khusus + tombol tampilkan semua', async () => {
    const app = boot({ session: SEEN, storage: { lang: 'id', country: 'ID' }, api: (u) => (u.includes('/search') ? [station('A', { bitrate: 64 })] : []) });
    await app.wait(300);
    app.$('#sortGroup [data-sort=hq]').click(); await app.wait(500);
    eq(app.$('#list .empty h2').textContent, 'Belum Ada Stasiun Kualitas Tinggi');
    app.$('#list [data-action=showAll]').click(); await app.wait(500);
    eq(app.$('#sortGroup [data-sort=popular]').getAttribute('aria-checked'), 'true', 'kembali ke Terpopuler');
    eq(app.$$('#list .item').length, 1, 'semua stasiun tampil lagi');
  });
  await test('Nama A–Z: seluruh negara dimuat & diurutkan seperti dibaca manusia', async () => {
    const names = [' Radio Suara Al-Iman', 'Dark Symphony', 'gadingharjo Core', '101.1 Insania', '9 FM', 'Ardan', '"Bens Radio"', 'looks Radio'];
    const st = names.map((n, i) => station('N' + i, { name: n }));
    const app = boot({ session: SEEN, storage: { lang: 'id', country: 'ID' }, api: (u) => (u.includes('/search') ? st : []) });
    await app.wait(300);
    app.$('#sortGroup [data-sort=name]').click(); await app.wait(500);
    const q = app.log.api.filter((u) => u.includes('/search')).pop();
    ok(q.includes('limit=2500') && q.includes('countrycode=ID'), 'seluruh negara diminta sekaligus: ' + q);
    eq(app.$$('#list .item-title').map((e) => e.textContent), ['9 FM', '101.1 Insania', 'Ardan', '"Bens Radio"', 'Dark Symphony', 'gadingharjo Core', 'looks Radio', 'Radio Suara Al-Iman']);
  });
  await test('Kota A–Z: urut nama provinsi/kota, tanpa kota paling bawah', async () => {
    const st = [station('A', { name: 'Tanpa Kota 1', state: '' }), station('B', { name: 'Radio Bali', state: 'Bali' }),
      station('C', { name: 'Tanpa Kota 2', state: '' }), station('D', { name: 'Radio Aceh', state: 'Aceh' }), station('E', { name: 'Radio Yogya', state: 'Yogyakarta' })];
    const app = boot({ session: SEEN, storage: { lang: 'id', country: 'ID' }, api: (u) => (u.includes('/search') ? st : []) });
    await app.wait(300);
    app.$('#sortGroup [data-sort=city]').click(); await app.wait(500);
    eq(app.$$('#list .item-title').map((e) => e.textContent), ['Radio Aceh', 'Radio Bali', 'Radio Yogya', 'Tanpa Kota 1', 'Tanpa Kota 2']);
  });
  await test('stasiun yang lambat dicek tetap di posisi urutannya', async () => {
    const st = ['Alfa', 'Bravo', 'Charlie', 'Delta'].map((n, i) => station('L' + i, { name: n }));
    const app = boot({ session: SEEN, storage: { lang: 'id', country: 'ID' }, api: (u) => (u.includes('/search') ? st : []),
      probe: (u) => (u.includes('L0.ex') && u.startsWith('https') ? 'slow' : (u.includes('L0.ex') ? 'dead' : 'ok')) });
    await app.wait(300);
    app.$('#sortGroup [data-sort=name]').click(); await app.wait(2200);
    eq(app.$$('#list .item-title').map((e) => e.textContent), ['Bravo', 'Charlie', 'Delta'], 'Alfa lambat: yang lain tidak ditahan');
    app.w.__releaseSlow && app.w.__releaseSlow(); await app.wait(300);
    eq(app.$$('#list .item-title').map((e) => e.textContent), ['Alfa', 'Bravo', 'Charlie', 'Delta'], 'Alfa lolos: masuk di posisinya');
  });
  await test('HQ: hanya HQ & HQ+, HQ+ dulu lalu kbps tertinggi', async () => {
    const st = [station('A', { name: 'Biasa 128', bitrate: 128, clickcount: 99 }), station('B', { name: 'HQ 256', bitrate: 256 }),
      station('C', { name: 'Murni', codec: 'FLAC', bitrate: 0 }), station('D', { name: 'HQ 320', bitrate: 320 }), station('E', { name: 'Biasa 192', bitrate: 192 })];
    const app = boot({ session: SEEN, storage: { lang: 'id' }, api: (u) => (u.includes('/search') ? st : []) });
    await app.wait(300);
    eq(app.$$('#sortGroup [role=radio]').map((b) => b.textContent), ['Terpopuler', 'Nama A–Z', 'Kota A–Z', 'HQ'], 'HQ jadi pilihan urutan ke-4');
    app.$('#sortGroup [data-sort=hq]').click(); await app.wait(500);
    eq(app.$('#sortGroup [data-sort=hq]').getAttribute('aria-checked'), 'true');
    eq(app.$('#sortGroup [data-sort=popular]').getAttribute('aria-checked'), 'false', 'hanya satu urutan aktif');
    const q = app.log.api.filter((u) => u.includes('/search')).slice(-2);
    ok(q.every((u) => u.includes('order=bitrate') && u.includes('reverse=true')), 'urut bitrate: ' + q.join(' | '));
    ok(q.some((u) => u.includes('bitrateMin=256')) && q.some((u) => u.includes('codec=FLAC')), 'hanya HQ & FLAC diminta: ' + q.join(' | '));
    eq(app.$$('#list .item-title').map((e) => e.textContent), ['Murni', 'HQ 320', 'HQ 256'], 'hanya HQ & HQ+ tampil');
  });

  await test('stasiun yang sudah dicek: cukup alamat terbukti + 1 cadangan', async () => {
    const st = [station('A', { url_resolved: 'http://a.ex/r', url: 'http://a.ex/u' })];
    const app = boot({ session: SEEN, bridge: true, api: (u) => (u.includes('/search') ? st : []), probe: (u) => (u === 'http://a.ex/u' ? 'ok' : 'dead') });
    await app.wait(400);
    app.$('#list .item [data-action=play]').click(); await app.wait(5);
    const play = app.log.bridge.filter((c) => c[0] === 'nativePlay').pop();
    eq(JSON.parse(play[1]), ['http://a.ex/u', 'http://a.ex/r']);
  });
  await test('pemutar Android gagal: pemutar web selalu dicoba selama waktu masih ada', async () => {
    const app = boot({ session: SEEN, bridge: true, storage: { lang: 'id' }, api: (u) => (u.includes('/search') ? [station('A')] : []) });
    await app.wait(400);
    const realNow = app.w.Date.now; let shift = 0; app.w.Date.now = () => realNow() + shift;
    app.$('#list .item [data-action=play]').click(); await app.wait(5);
    eq(app.log.seq[0], 'native', 'stasiun biasa: pemutar Android dulu');
    shift = 13000; app.w.FreqMan.nativeState('error'); await app.wait(30);
    ok(app.log.played.length >= 1, 'sesudah 13 dtk pemutar web tetap dicoba (dulu langsung gagal)');
    ok(/Live/.test(app.$('#playerBadge').textContent), 'stasiun berhasil diputar lewat pemutar web');
  });
  await test('batas 30 dtk: lewat dari itu langsung gagal, tanpa menunggu lagi', async () => {
    const app = boot({ session: SEEN, bridge: true, storage: { lang: 'id' }, api: (u) => (u.includes('/search') ? [station('A')] : []) });
    await app.wait(400);
    const realNow = app.w.Date.now; let shift = 0; app.w.Date.now = () => realNow() + shift;
    app.$('#list .item [data-action=play]').click(); await app.wait(5);
    shift = 28000; app.w.FreqMan.nativeState('error'); await app.wait(10);
    ok(/Gagal Memutar Siaran/.test(app.$('#toast').textContent), 'langsung gagal: ' + app.$('#toast').textContent);
    eq(app.log.played.length, 0, 'tidak mencoba pemutar web lagi');
  });
  await test('stasiun bitrate rendah: pemutar web dulu (mulai cepat), Android sebagai cadangan', async () => {
    const app = boot({ session: SEEN, bridge: true, storage: { lang: 'id' }, api: (u) => (u.includes('/search') ? [station('A', { codec: 'AAC+', bitrate: 32 })] : []), plays: () => false });
    await app.wait(400);
    app.$('#list .item [data-action=play]').click(); await app.wait(120);
    eq(app.log.seq[0], 'web', 'pemutar web dulu');
    ok(app.log.seq.indexOf('native') > 0, 'web gagal: pindah ke pemutar Android (' + app.log.seq.join(' → ') + ')');
  });

  await test('versi Kotlin (ExoPlayer): stasiun bitrate rendah tetap lewat pemutar Android dulu', async () => {
    const app = boot({ session: SEEN, bridge: true, engine: 'exoplayer', storage: { lang: 'id' }, api: (u) => (u.includes('/search') ? [station('A', { codec: 'AAC+', bitrate: 32 })] : []) });
    await app.wait(400);
    app.$('#list .item [data-action=play]').click(); await app.wait(5);
    eq(app.log.seq[0], 'native');
  });

  console.log('Pemutaran');
  const one = [station('A', { name: 'Delta FM', tags: 'hits', codec: 'AAC', bitrate: 0 })];
  await test('memutar stasiun: badge Live & tiga baris info', async () => {
    const app = boot({ session: SEEN, storage: { lang: 'id' }, api: (u) => (u.includes('/search') ? one : []) });
    await app.wait(400);
    app.$('#list .item [data-action=play]').click(); await app.wait(30);
    ok(/Live/.test(app.$('#playerBadge').textContent), 'badge Live');
    eq(app.$$('#list .item-current .bars span').length, 5, 'animasi 5 garis seperti logo');
    eq([app.$('#playerTitle').textContent, app.$('#playerSub').textContent, app.$('#playerDetail').textContent], ['Delta FM', 'DKI Jakarta, Indonesia', 'Hits / AAC']);
  });
  await test('judul lagu dari pemutar Android tampil di pemutar', async () => {
    const app = boot({ session: SEEN, bridge: true, api: (u) => (u.includes('/search') ? one : []) });
    await app.wait(400);
    app.$('#list .item [data-action=play]').click(); await app.wait(5);
    app.w.FreqMan.nativeState('playing'); app.w.FreqMan.nativeTitle('Tulus - Hati-Hati di Jalan');
    eq(app.$('#playerSub').textContent, '♪ Tulus - Hati-Hati di Jalan');
  });
  await test('internet putus: stasiun tidak ditandai gagal, tersambung lagi saat online', async () => {
    const app = boot({ session: SEEN, api: (u) => (u.includes('/search') ? one : []), plays: () => false });
    await app.wait(400);
    Object.defineProperty(app.w.navigator, 'onLine', { configurable: true, get: () => false });
    app.$('#list .item [data-action=play]').click(); await app.wait(60);
    ok(/Koneksi Terputus|Connection Lost/.test(app.$('#toast').textContent), 'toast koneksi terputus');
    ok(!app.w.localStorage.getItem('freqman:fails') || app.w.localStorage.getItem('freqman:fails') === '{}', 'tidak ditandai gagal');
    const before = app.log.played.length;
    Object.defineProperty(app.w.navigator, 'onLine', { configurable: true, get: () => true });
    app.w.dispatchEvent(new app.w.Event('online')); await app.wait(10);
    ok(app.log.played.length > before, 'mencoba memutar lagi setelah online');
  });
  await test('sempat diputar lalu putus: stasiun tidak disembunyikan', async () => {
    const app = boot({ session: SEEN, bridge: true, api: (u) => (u.includes('/search') ? [station('A')] : []), plays: () => false });
    await app.wait(400);
    app.$('#list .item [data-action=play]').click(); await app.wait(5);
    app.w.FreqMan.nativeState('playing');
    app.w.FreqMan.nativeState('error'); await app.wait(10);
    ok(!/\"A\"/.test(app.w.localStorage.getItem('freqman:fails') || ''), 'tidak ditandai gagal');
  });
  await test('gagal sungguhan: ditandai "Terakhir Gagal"', async () => {
    const app = boot({ session: SEEN, storage: { lang: 'id' }, api: (u) => (u.includes('/search') ? one : []), plays: () => false });
    await app.wait(400);
    app.$('#list .item [data-action=play]').click(); await app.wait(80);
    ok(!app.$('#list .fail-badge').hidden, 'badge Terakhir Gagal tampil');
  });
  await test('riwayat mencatat stasiun yang berhasil diputar', async () => {
    const app = boot({ session: SEEN, storage: { lang: 'id' }, api: (u) => (u.includes('/search') ? one : []) });
    await app.wait(400);
    app.$('#list .item [data-action=play]').click(); await app.wait(30);
    app.$('#tabHist').click(); await app.wait(5);
    eq(app.$$('#histList .item-title').map((e) => e.textContent), ['Delta FM']);
    app.$('#histList [data-action=clearHistory]').click(); await app.wait(5);
    eq(app.$$('#histList .item').length, 0, 'riwayat dihapus');
  });

  console.log('Sedang Diputar & timer tidur');
  await test('mengetuk pemutar membuka "Sedang Diputar"', async () => {
    const app = boot({ session: SEEN, storage: { lang: 'id' }, api: (u) => (u.includes('/search') ? one : []) });
    await app.wait(400);
    app.$('#list .item [data-action=play]').click(); await app.wait(30);
    app.$('#playerOpen').click();
    ok(!app.$('#np').hidden, 'lembar terbuka');
    eq(app.$('.np-name').textContent, 'Delta FM');
    eq(app.$$('.np-sleep-group button').map((b) => b.textContent), ['Mati', '15 mnt', '30 mnt', '60 mnt', '90 mnt']);
    ok(app.w.FreqMan.onBack() === true && app.$('#np').hidden, 'tombol Kembali menutup');
  });
  await test('timer tidur menghentikan radio', async () => {
    const app = boot({ session: SEEN, bridge: true, storage: { lang: 'id' }, api: (u) => (u.includes('/search') ? one : []) });
    await app.wait(400);
    app.$('#list .item [data-action=play]').click(); await app.wait(5);
    app.w.FreqMan.nativeState('playing');
    app.$('#playerOpen').click();
    app.$('.np-sleep-group [data-sleep="15"]').click();
    ok(app.log.bridge.some((c) => c[0] === 'setSleepTimer' && c[1] === 900000), 'diteruskan ke layanan Android');
    ok(/berhenti dalam 1[45]:/.test(app.$('#npSleepInfo').textContent), app.$('#npSleepInfo').textContent);
    app.w.FreqMan.nativeState('sleep'); await app.wait(5);
    ok(!/Live/.test(app.$('#playerBadge').textContent), 'radio berhenti');
    ok(/Timer Tidur Selesai/.test(app.$('#toast').textContent), 'toast selesai');
  });

  console.log('Tampilan & pengaturan');
  await test('splash hanya sekali per pembukaan aplikasi', async () => {
    const app = boot({ session: SEEN });
    await app.wait(20);
    ok(!app.$('#splash'), 'splash tidak muncul lagi di sesi yang sama');
  });
  await test('layar tetap menyala hanya saat radio diputar (web)', async () => {
    const app = boot({ session: SEEN, wakeLock: true, api: (u) => (u.includes('/search') ? one : []) });
    await app.wait(400);
    eq(app.log.wake, 0, 'tidak diminta sebelum memutar');
    app.$('#list .item [data-action=play]').click(); await app.wait(30);
    ok(app.log.wake >= 1, 'diminta saat memutar');
  });
  await test('Tentang: versi di bawah hak cipta, Radio Browser "Public Domain"', async () => {
    const app = boot({ session: SEEN, storage: { lang: 'id' } });
    app.$('#aboutBtn').click();
    ok(/All Rights Reserved\.\s*Versi 1\.0/.test(app.$('.about-copy').textContent), app.$('.about-copy').textContent);
    ok(!app.$('.about-head').textContent.includes('Versi'), 'versi tidak lagi di kepala');
    eq(app.$('.lic-link .lic-type').textContent, 'Public Domain');
    ok(app.$$('.license').some((l) => l.textContent.includes('shadcn/ui') && l.textContent.includes('MIT')), 'shadcn/ui MIT tercantum');
  });
  await test('Tentang: nama pengembang & radio-browser.info jadi tautan', async () => {
    const app = boot({ session: SEEN, storage: { lang: 'id' } });
    app.$('#aboutBtn').click();
    const dev = app.$$('#aboutBody a').find((a) => a.textContent === 'Nur Mukhammad Agus');
    ok(dev && dev.getAttribute('href').startsWith('mailto:madfxr@protonmail.com?subject='), 'tautan email pengembang');
    const p = dev.parentNode.textContent;
    eq(p, 'Hubungi pengembang: Nur Mukhammad Agus.');
    const rb = app.$$('#aboutBody a').filter((a) => a.textContent === 'radio-browser.info');
    eq(rb.length, 2, 'kedua penyebutan radio-browser.info bertautan');
    app.$('#langGroup [data-lang=en]').click();
    ok(/^Contact the developer: Nur Mukhammad Agus\.$/.test(app.$$('#aboutBody a').find((a) => a.textContent === 'Nur Mukhammad Agus').parentNode.textContent), 'versi EN');
  });
  await test('awalan "Now Playing:" pada judul lagu dibuang', async () => {
    const app = boot({ session: SEEN, bridge: true, api: (u) => (u.includes('/search') ? [station('A')] : []) });
    await app.wait(400);
    app.$('#list .item [data-action=play]').click(); await app.wait(5);
    app.w.FreqMan.nativeState('playing'); app.w.FreqMan.nativeTitle('Now Playing: Spandau Ballet - True');
    eq(app.$('#playerSub').textContent, '♪ Spandau Ballet - True');
  });
  await test('ganti bahasa ID ↔ EN', async () => {
    const app = boot({ session: SEEN, storage: { lang: 'id' } });
    eq(app.$('h1').textContent, 'Dengarkan Radio');
    app.$('#langGroup [data-lang=en]').click();
    eq(app.$('h1').textContent, 'Listen to Radio');
    eq(app.$('#tabHist').textContent, 'Recent');
  });
  await test('mode gelap tersimpan', async () => {
    const app = boot({ session: SEEN });
    const before = app.d.documentElement.dataset.theme;
    app.$('#themeBtn').click();
    ok(app.d.documentElement.dataset.theme !== before, 'tema berganti');
    ok(/light|dark/.test(app.w.localStorage.getItem('freqman:theme')), 'disimpan');
  });
  summary();
})();
