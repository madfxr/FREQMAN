Sumber tampilan FREQMAN (dipakai aplikasi Android & versi web)
==============================================================
src/  : kode JavaScript, dipecah per bagian (bagian dari satu fungsi besar; urutan berkas penting).
        00-awal      pengaturan (CONTACT_EMAIL, BLOCKLIST_URL, versi)
        01-teks      semua teks ID & EN
        02-ikon-util ikon Lucide & fungsi bantu
        03-katalog   Radio Browser API, pengecekan & urutan stasiun, blocklist
        04-stasiun   data stasiun (lokasi, genre, kualitas HQ/HQ+, warna cover)
        05-tampilan  menggambar daftar, favorit, riwayat, pemutar, toast
        06-pemutar   pemutaran (Android / browser), coba ulang, batas waktu
        07-lembar    pemilih negara, Sedang Diputar + timer tidur, Tentang & Lisensi
        08-event     ketukan, pencarian, tab, swipe
        09-tema-mulai tema, logo, splash, layar menyala, mulai

Setelah mengubah berkas di src/:   ./build.sh        (menulis ../app/src/main/assets/www/app.js)
Lalu uji:                          cd ../tests && npm install && npm test
Lalu:                              unggah ke GitHub; APK dibuat otomatis oleh GitHub Actions
