#!/bin/sh
# Gabungkan src/*.js (urut nama berkas) menjadi app.js yang dimuat aplikasi.
# Pemakaian: ./build.sh [folder-tujuan]   (bawaan: ../app/src/main/assets/www)
set -e
cd "$(dirname "$0")"
OUT="${1:-../app/src/main/assets/www}"
cat src/*.js > "$OUT/app.js"
node --check "$OUT/app.js" 2>/dev/null && echo "OK: $OUT/app.js" || echo "Selesai: $OUT/app.js (node tidak tersedia, cek sintaks dilewati)"
