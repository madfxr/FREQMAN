  // ------------------------------------------------------------------ Ikon (Lucide, ISC)
  var ICON = {
    history: '<path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l4 2"/>',
    clock: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
    heart: '<path d="M2 9.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5l-5.492 5.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5"/>',
    play: '<path d="M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z"/>',
    pause: '<rect x="14" y="3" width="5" height="18" rx="1"/><rect x="5" y="3" width="5" height="18" rx="1"/>',
    loader: '<path d="M21 12a9 9 0 1 1-6.219-8.56"/>',
    check: '<path d="M20 6 9 17l-5-5"/>',
    circleCheck: '<circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/>',
    alert: '<circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/>',
    heartOff: '<path d="M10.5 4.893a5.5 5.5 0 0 1 1.091.931.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5c0 1.872-1.002 3.356-2.187 4.655"/><path d="m16.967 16.967-3.459 3.346a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5a5.5 5.5 0 0 1 2.747-4.761"/><path d="m2 2 20 20"/>',
    wifiOff: '<path d="M12 20h.01"/><path d="M8.5 16.429a5 5 0 0 1 7 0"/><path d="M5 12.859a10 10 0 0 1 5.17-2.69"/><path d="M19 12.859a10 10 0 0 0-2.007-1.523"/><path d="M2 8.82a15 15 0 0 1 4.177-2.643"/><path d="M22 8.82a15 15 0 0 0-11.288-3.764"/><path d="m2 2 20 20"/>',
    searchX: '<path d="m13.5 8.5-5 5"/><path d="m8.5 8.5 5 5"/><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
    tower: '<path d="M4.9 16.1C1 12.2 1 5.8 4.9 1.9"/><path d="M7.8 4.7a6.14 6.14 0 0 0-.8 7.5"/><circle cx="12" cy="9" r="2"/><path d="M16.2 4.8c2 2 2.26 5.11.8 7.47"/><path d="M19.1 1.9a9.96 9.96 0 0 1 0 14.1"/><path d="M9.5 18h5"/><path d="m8 22 4-11 4 11"/>'
  };
  function svg(name, size, opts) {
    opts = opts || {};
    return '<svg width="' + (size || 16) + '" height="' + (size || 16) + '" viewBox="0 0 24 24" fill="' + (opts.fill ? 'currentColor' : 'none') +
      '" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"' +
      (opts.cls ? ' class="' + opts.cls + '"' : '') + '>' + ICON[name] + '</svg>';
  }

  // ------------------------------------------------------------------ Util
  function $(id) { return document.getElementById(id); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  var store = {
    get: function (k, d) { try { var v = localStorage.getItem('freqman:' + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem('freqman:' + k, JSON.stringify(v)); } catch (e) { /* penyimpanan penuh/nonaktif */ } }
  };

  var navLang = (navigator.language || 'en').toLowerCase();
  var navRegion = ((navigator.language || '').split('-')[1] || '').toUpperCase();
  var isIndonesian = navLang.indexOf('id') === 0 || navLang.indexOf('in') === 0;
  var savedCountry = store.get('country', null);

  var state = {
    lang: store.get('lang', isIndonesian ? 'id' : 'en'),
    country: savedCountry !== null ? savedCountry : (/^[A-Z]{2}$/.test(navRegion) ? navRegion : (isIndonesian ? 'ID' : '')),
    query: '',
    sort: 'popular',
    tab: 'browse',
    stations: [],
    offset: 0,
    loading: false,
    loadingMore: false,
    endReached: false,
    error: false,
    countries: [],
    countriesLoading: false,
    countryFilter: '',
    favorites: store.get('favs', []),
    history: store.get('history', []),
    nowTitle: '',        // judul lagu dari stasiun (bila dikirim)
    sleepEnd: 0,         // waktu timer tidur berakhir (0 = mati)
    waitingNetwork: false,
    current: null,
    playing: false,
    buffering: false
  };
  if (I18N[state.lang] === undefined) state.lang = 'id';
  function T() { return I18N[state.lang]; }

  function fmt(n) { try { return new Intl.NumberFormat(T().locale).format(n); } catch (e) { return String(n); } }
  var displayNames = {};
  function countryName(code, fallback) {
    if (!code) return T().worldwide;
    try {
      if (!displayNames[state.lang]) displayNames[state.lang] = new Intl.DisplayNames([T().locale], { type: 'region' });
      var n = displayNames[state.lang].of(code);
      if (n && n !== code) return n;
    } catch (e) { /* browser lama */ }
    return fallback || code;
  }

