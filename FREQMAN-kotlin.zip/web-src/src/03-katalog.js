  // ------------------------------------------------------------------ Radio Browser API
  var FALLBACK_SERVERS = ['de1.api.radio-browser.info', 'de2.api.radio-browser.info', 'fi1.api.radio-browser.info'];
  // Langsung pakai alamat utama (round-robin DNS) + cadangan; daftar server lengkap
  // diambil di belakang layar tanpa menunda pencarian pertama.
  var hostList = ['all.api.radio-browser.info'].concat(FALLBACK_SERVERS);
  var API_TIMEOUT_MS = 6000; // server yang macet dilewati setelah 6 detik
  fetchWithTimeout('https://all.api.radio-browser.info/json/servers', null, API_TIMEOUT_MS)
    .then(function (r) { return r.ok ? r.json() : []; })
    .then(function (list) {
      (list || []).forEach(function (sv) { if (sv && sv.name && hostList.indexOf(sv.name) < 0) hostList.push(sv.name); });
    })
    .catch(function () { /* tetap pakai daftar cadangan */ });

  function fetchWithTimeout(url, outerSignal, ms) {
    if (typeof AbortController === 'undefined') return fetch(url);
    var ctrl = new AbortController();
    var timedOut = false;
    var timer = setTimeout(function () { timedOut = true; ctrl.abort(); }, ms);
    var onOuterAbort = function () { ctrl.abort(); };
    if (outerSignal) {
      if (outerSignal.aborted) ctrl.abort();
      else outerSignal.addEventListener('abort', onOuterAbort);
    }
    return fetch(url, { signal: ctrl.signal })
      .then(function (r) { return r; }, function (e) {
        if (timedOut) { var te = new Error('timeout'); te.name = 'TimeoutError'; throw te; }
        throw e; // AbortError dari pemanggil diteruskan apa adanya
      })
      .then(function (r) { clearTimeout(timer); if (outerSignal) outerSignal.removeEventListener('abort', onOuterAbort); return r; },
        function (e) { clearTimeout(timer); if (outerSignal) outerSignal.removeEventListener('abort', onOuterAbort); throw e; });
  }

  function api(path, signal) {
    var hosts = hostList.slice();
    var i = 0;
    function attempt(lastErr) {
      if (signal && signal.aborted) { var ae = new Error('aborted'); ae.name = 'AbortError'; return Promise.reject(ae); }
      if (i >= hosts.length) return Promise.reject(lastErr || new Error('no server'));
      var host = hosts[i++];
      return fetchWithTimeout('https://' + host + path, signal, API_TIMEOUT_MS)
        .then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
        .catch(function (e) { if (e && e.name === 'AbortError') throw e; return attempt(e); });
    }
    return attempt(null);
  }

  // Format yang tidak bisa diputar di HP maupun browser (WMA, RealAudio, protokol mms/rtsp/rtmp)
  // disembunyikan dari daftar, supaya tidak muncul lalu gagal saat diketuk.
  var UNSUPPORTED_CODEC = /^(wma|wmav1|wmav2|wmapro|asf|ra|rm|real|realaudio)$/i;
  var UNSUPPORTED_URL = /^(mms|mmsh|mmst|rtsp|rtmp|rtmps|pnm):/i;
  var UNSUPPORTED_EXT = /\.(wma|wax|wvx|ram|rm|ra)(\?|$)/i;
  function isPlayable(s) {
    var urls = [s.url_resolved, s.url].map(function (u) { return String(u || '').trim(); }).filter(Boolean);
    var codec = String(s.codec || '').trim();
    if (UNSUPPORTED_CODEC.test(codec)) return false;
    return urls.some(function (u) { return /^https?:\/\//i.test(u) && !UNSUPPORTED_EXT.test(u); }) &&
      !urls.every(function (u) { return UNSUPPORTED_URL.test(u); });
  }

  // ---- Stasiun yang terakhir gagal diputar (disimpan di HP ini, kedaluwarsa 24 jam)
  var FAIL_TTL = 24 * 60 * 60 * 1000;
  var fails = store.get('fails', {});
  (function pruneFails() {
    var now = Date.now(), keys = Object.keys(fails);
    keys.forEach(function (k) { if (!(now - fails[k] < FAIL_TTL)) delete fails[k]; });
    keys = Object.keys(fails).sort(function (a, b) { return fails[b] - fails[a]; });
    keys.slice(500).forEach(function (k) { delete fails[k]; }); // batasi ukuran
    store.set('fails', fails);
  })();
  function hasFailed(s) { var t = s && fails[s.stationuuid]; return !!t && Date.now() - t < FAIL_TTL; }
  function markFailed(s) { if (!s) return; fails[s.stationuuid] = Date.now(); store.set('fails', fails); }
  function markPlayed(s) {
    if (!s) return;
    addHistory(s);
    if (!fails[s.stationuuid]) return;
    delete fails[s.stationuuid]; store.set('fails', fails);
    refreshItems();
  }

  // ---- Riwayat: 30 stasiun terakhir yang berhasil diputar (disimpan di HP ini)
  var HISTORY_MAX = 30;
  function addHistory(s) {
    var item = slim(s);
    state.history = [item].concat(state.history.filter(function (h) { return h.stationuuid !== s.stationuuid; })).slice(0, HISTORY_MAX);
    store.set('history', state.history);
    if (state.tab === 'hist') renderHistory();
  }
  function visibleHistory() { return state.history.filter(function (h) { return !isBlocked(h); }); }

  // ---- Pemeriksaan cepat: hanya stasiun yang servernya menjawab (dalam 5 detik) yang ditampilkan.
  // Koneksi langsung ditutup begitu server menjawab, jadi kuota yang terpakai sangat kecil.
  var PROBE_TIMEOUT = 5000, PROBE_PARALLEL = 8, PROBE_TTL = 6 * 60 * 60 * 1000;
  var probeCache = store.get('probe', {}); // id -> { ok: 1|0, url: alamat yang menjawab, t: waktu }
  (function pruneProbe() {
    var now = Date.now();
    Object.keys(probeCache).forEach(function (k) { if (!(now - probeCache[k].t < PROBE_TTL)) delete probeCache[k]; });
    var keys = Object.keys(probeCache);
    if (keys.length > 3000) {
      keys.sort(function (a, b) { return probeCache[a].t - probeCache[b].t; })
        .slice(0, keys.length - 3000).forEach(function (k) { delete probeCache[k]; });
    }
    store.set('probe', probeCache);
  })();
  var saveProbeTimer = null;
  function saveProbeSoon() {
    clearTimeout(saveProbeTimer);
    saveProbeTimer = setTimeout(function () { store.set('probe', probeCache); }, 600);
  }
  var shownIds = {}; // yang sudah tampil tidak dihilangkan sampai daftar dimuat ulang
  function verdict(s) {
    if (shownIds[s.stationuuid]) return 'ok';
    if (hasFailed(s)) return 'fail';
    var c = probeCache[s.stationuuid];
    if (c && Date.now() - c.t < PROBE_TTL) return c.ok ? 'ok' : 'fail';
    return 'pending';
  }
  function okUrl(s) { var c = probeCache[s.stationuuid]; return c && c.ok ? c.url : ''; }

  function probeOne(url) {
    return new Promise(function (resolve) {
      var ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
      var done = false;
      var timer = setTimeout(function () { if (done) return; done = true; if (ctrl) ctrl.abort(); resolve(false); }, PROBE_TIMEOUT);
      fetch(url, { mode: 'no-cors', cache: 'no-store', credentials: 'omit', referrerPolicy: 'no-referrer', signal: ctrl ? ctrl.signal : undefined })
        .then(function () { if (done) return; done = true; clearTimeout(timer); if (ctrl) ctrl.abort(); resolve(true); },
          function () { if (done) return; done = true; clearTimeout(timer); resolve(false); });
    });
  }
  // Semua alamat stasiun dicoba bersamaan; alamat pertama yang menjawab dipakai saat diputar
  function probeAny(urls) {
    return new Promise(function (resolve) {
      var left = urls.length, settled = false;
      if (!left) { resolve(''); return; }
      urls.forEach(function (u) {
        probeOne(u).then(function (ok) {
          if (settled) return;
          if (ok) { settled = true; resolve(u); return; }
          if (--left === 0) resolve('');
        });
      });
    });
  }
  var probeQueue = [], probeRunning = 0, probeGen = 0, renderSoonTimer = null;
  var HOLD_MS = 1500;          // stasiun lambat hanya menahan yang di bawahnya maksimal 1,5 detik
  // Hemat kuota: hanya stasiun di sekitar layar yang dicek; sisanya dicek saat daftar digulir
  var PROBE_AHEAD = 24, probeHorizon = PROBE_AHEAD;
  function growProbeHorizon() {
    if (probeRunning > 0) return true; // tunggu kelompok yang sedang dicek selesai dulu
    if (!probeQueue.length) return false;
    var nextIdx = stationIndex[probeQueue[0].stationuuid] || 0;
    probeHorizon = Math.max(probeHorizon, nextIdx) + PROBE_AHEAD;
    pumpProbes();
    return true;
  }
  var probeStart = {}, skippedIds = {};
  function renderSoon() {
    if (renderSoonTimer) return;
    renderSoonTimer = setTimeout(function () { renderSoonTimer = null; renderList(); maybeLoadMore(); }, 120);
  }
  function queueProbes(list) {
    list.forEach(function (st) { if (verdict(st) === 'pending') probeQueue.push(st); });
    pumpProbes();
  }
  function pumpProbes() {
    while (probeRunning < PROBE_PARALLEL && probeQueue.length) {
      var idx = stationIndex[probeQueue[0].stationuuid];
      if (idx !== undefined && idx >= probeHorizon) break; // belum dekat layar
      (function (st, gen) {
        probeRunning++;
        probeStart[st.stationuuid] = Date.now();
        probeAny(streamCandidates(st)).then(function (url) {
          probeRunning--;
          probeCache[st.stationuuid] = { ok: url ? 1 : 0, url: url, t: Date.now() };
          // Lolos setelah dilewati: ditambahkan di akhir daftar agar baris lain tidak bergeser
          saveProbeSoon();
          if (gen === probeGen) renderSoon();
          pumpProbes();
        });
      })(probeQueue.shift(), probeGen);
    }
  }
  // Daftar yang tampil: urutan asli dipertahankan, ditampilkan sampai stasiun pertama yang belum selesai diperiksa
  function visibleStations() {
    var out = [], pending = false, now = Date.now();
    for (var i = 0; i < state.stations.length; i++) {
      var st = state.stations[i], id = st.stationuuid;
      if (isBlocked(st)) continue;
      if (skippedIds[id] && !shownIds[id]) {
        // Lambat dicek: tidak menahan yang di bawahnya, tapi bila lolos tampil di posisi urutannya sendiri
        var sv = verdict(st);
        if (sv === 'pending') pending = true;
        else if (sv === 'ok') out.push(st);
        continue;
      }
      var v = verdict(st);
      if (v === 'pending') {
        pending = true;
        var started = probeStart[id];
        if (!started) break; // belum mulai dicek (menunggu giliran / di luar jangkauan layar)
        if (now - started < HOLD_MS) {
          // tahan sebentar, lalu tampilkan ulang saat batas tahan habis
          setTimeout(renderSoon, Math.max(50, HOLD_MS - (started ? now - started : 0)));
          break;
        }
        skippedIds[id] = 1; // terlalu lama: jangan tahan stasiun di bawahnya
        continue;
      }
      if (v === 'ok') out.push(st);
    }
    return { list: out, pending: pending };
  }

  // ---- Blocklist: stasiun yang disembunyikan (mis. atas permintaan pemilik stasiun)
  var blocked = { ids: {}, names: {}, domains: [] };
  function normName(n) { return String(n || '').trim().toLowerCase().replace(/\s+/g, ' '); }
  function addBlocklist(data) {
    if (!data || typeof data !== 'object') return;
    (data.stations || []).forEach(function (id) { if (id) blocked.ids[String(id).trim()] = 1; });
    (data.names || []).forEach(function (n) { if (n) blocked.names[normName(n)] = 1; });
    (data.domains || []).forEach(function (d) {
      d = String(d || '').trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '');
      if (d && blocked.domains.indexOf(d) < 0) blocked.domains.push(d);
    });
  }
  function hostOf(u) { var m = /^https?:\/\/([^\/:?#]+)/i.exec(String(u || '')); return m ? m[1].toLowerCase() : ''; }
  function isBlocked(s) {
    if (!s) return false;
    if (blocked.ids[s.stationuuid]) return true;
    if (blocked.names[normName(s.name)]) return true;
    if (!blocked.domains.length) return false;
    return [s.url_resolved, s.url, s.homepage].some(function (u) {
      var h = hostOf(u);
      return h && blocked.domains.some(function (d) { return h === d || h.slice(-(d.length + 1)) === '.' + d; });
    });
  }
  function visibleFavorites() { return state.favorites.filter(function (f) { return !isBlocked(f); }); }
  function loadBlocklist() {
    var jobs = [fetch('blocklist.json', { cache: 'no-cache' }).then(function (r) { return r.ok ? r.json() : null; }).catch(function () { return null; })];
    if (BLOCKLIST_URL) {
      addBlocklist(store.get('remoteBlocklist', null)); // salinan terakhir, dipakai bila sedang offline
      jobs.push(fetch(BLOCKLIST_URL, { cache: 'no-cache' }).then(function (r) { return r.ok ? r.json() : null; })
        .then(function (d) { if (d) store.set('remoteBlocklist', d); return d; }).catch(function () { return null; }));
    }
    Promise.all(jobs).then(function (lists) {
      lists.forEach(addBlocklist);
      renderStatic(); renderList(); renderFavs();
    });
  }

  var SORTS = {
    popular: { order: 'clickcount', reverse: 'true' },
    name: { order: 'name', reverse: 'false' },
    city: { order: 'state', reverse: 'false' },
    hq: { order: 'bitrate', reverse: 'true' } // kualitas tertinggi dulu (lihat sortStations)
  };
  var PAGE = 60;
  var FULL_LIMIT = 2500; // batas satu negara dimuat sekaligus (Indonesia ±615 stasiun)
  var TIER_RANK = { lossless: 2, hq: 1, '': 0 };
  // Urutan seperti manusia membaca: huruf besar/kecil sama, simbol & spasi di depan diabaikan, 2 sebelum 10
  var LEAD_JUNK = (function () { try { return new RegExp('^[^\\p{L}\\p{N}]+', 'u'); } catch (e) { return /^[^A-Za-z0-9\u00C0-\uFFFF]+/; } })();
  function textCollator() {
    try { return new Intl.Collator(state.lang === 'en' ? 'en' : 'id', { sensitivity: 'base', numeric: true }); }
    catch (e) { return { compare: function (a, b) { return a.toLowerCase().localeCompare(b.toLowerCase()); } }; }
  }
  function nameKey(s) { return stationName(s).replace(LEAD_JUNK, '') || stationName(s); }
  function cityKey(s) { return localRegion(s.state, String(s.countrycode || '').toUpperCase(), s.country) || ''; }
  function sortStations(list) {
    var by = state.sort;
    var col = textCollator();
    return list.slice().sort(function (a, b) {
      if (by === 'name') return col.compare(nameKey(a), nameKey(b));
      if (by === 'city') {
        // Stasiun tanpa kota/provinsi ditaruh paling bawah
        var ca = cityKey(a), cb = cityKey(b);
        if (!ca !== !cb) return ca ? -1 : 1;
        return col.compare(ca, cb) || col.compare(nameKey(a), nameKey(b));
      }
      // HQ: Lossless dulu, lalu HQ (256 kbps ke atas), lalu lainnya; masing-masing dari kbps tertinggi
      if (by === 'hq') return (TIER_RANK[qualityTier(b)] - TIER_RANK[qualityTier(a)]) || ((b.bitrate || 0) - (a.bitrate || 0)) || ((b.clickcount || 0) - (a.clickcount || 0));
      return (b.clickcount || 0) - (a.clickcount || 0);
    });
  }
  var stationIndex = {};
  function indexStations() {
    stationIndex = {};
    state.stations.forEach(function (st, i) { stationIndex[st.stationuuid] = i; });
  }
  var reqId = 0;
  var controller = null;

  function loadStations(reset) {
    if (reset) {
      if (controller) controller.abort();
      state.offset = 0; state.endReached = false; state.error = false; state.loading = true; state.loadingMore = false;
      state.autoPages = 0;
      probeGen++; probeQueue = []; shownIds = {}; probeStart = {}; skippedIds = {}; probeHorizon = PROBE_AHEAD;
    } else {
      if (state.loading || state.loadingMore || state.endReached || state.error) return;
      if (visibleStations().pending) return; // tunggu halaman ini selesai diperiksa dulu
      // Pengaman: jangan terus memuat halaman bila hampir tidak ada stasiun yang lolos pemeriksaan
      if (visibleStations().list.length < 10) {
        if ((state.autoPages || 0) >= 5) return;
        state.autoPages = (state.autoPages || 0) + 1;
      }
      state.loadingMore = true;
    }
    renderList();
    var my = ++reqId;
    controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
    var offset = reset ? 0 : state.offset;
    // Nama / Kota / HQ di satu negara: ambil seluruh daftar negara itu sekaligus lalu urutkan dengan benar
    // (urutan bawaan katalog per karakter & per halaman tidak cocok untuk dibaca)
    var full = state.sort !== 'popular' && !!state.country;
    var limit = full ? FULL_LIMIT : PAGE;
    var q = state.query.trim();
    // Pencarian mencakup nama stasiun, genre (tag), dan kota/provinsi: tiga permintaan sekaligus
    var fields = q ? ['name', 'tag', 'state'] : [null];
    // HQ: hanya stasiun 256 kbps ke atas, ditambah stasiun FLAC (lossless, sering tercatat 0 kbps)
    var tiers = state.sort === 'hq' ? [{ bitrateMin: '256' }, { codec: 'FLAC' }] : [{}];
    var requests = [];
    fields.forEach(function (field) { tiers.forEach(function (tier) { requests.push({ field: field, tier: tier }); }); });
    var signal = controller ? controller.signal : undefined;
    Promise.all(requests.map(function (rq) {
      var p = new URLSearchParams({
        order: SORTS[state.sort].order, reverse: SORTS[state.sort].reverse, hidebroken: 'true',
        offset: String(offset), limit: String(limit)
      });
      if (state.country) p.set('countrycode', state.country);
      if (rq.field) p.set(rq.field, q);
      Object.keys(rq.tier).forEach(function (k) { p.set(k, rq.tier[k]); });
      return api('/json/stations/search?' + p.toString(), signal).then(function (r) { return Array.isArray(r) ? r : []; });
    }))
      .then(function (results) {
        if (my !== reqId) return;
        var more = !full && results.some(function (r) { return r.length >= PAGE; });
        var raw = [].concat.apply([], results);
        if (state.sort === 'hq') raw = raw.filter(function (st) { return qualityTier(st) !== ''; }); // hanya HQ & Lossless
        if (results.length > 1 || state.sort !== 'popular') raw = sortStations(raw);
        var page = raw.filter(function (s) { return s && s.stationuuid && (s.url_resolved || s.url) && isPlayable(s) && !isBlocked(s); });
        var merged = (reset ? [] : state.stations).concat(page);
        var seen = {};
        state.stations = merged.filter(function (s) { if (seen[s.stationuuid]) return false; seen[s.stationuuid] = 1; return true; });
        state.offset = offset + (results.length > 1 ? PAGE : raw.length);
        state.endReached = !more;
        indexStations();
        state.loading = false; state.loadingMore = false;
        queueProbes(page);
        renderList();
        maybeLoadMore();
      })
      .catch(function (e) {
        if (e && e.name === 'AbortError') return;
        if (my !== reqId) return;
        state.error = true; state.loading = false; state.loadingMore = false;
        renderList();
      });
  }

  function loadCountries() {
    if (state.countries.length || state.countriesLoading) return;
    state.countriesLoading = true;
    api('/json/countries?order=stationcount&reverse=true&hidebroken=true')
      .then(function (raw) {
        var map = {};
        (raw || []).forEach(function (c) {
          var code = String(c.iso_3166_1 || '').toUpperCase();
          if (!/^[A-Z]{2}$/.test(code) || !c.stationcount) return;
          if (!map[code]) map[code] = { code: code, name: c.name, count: 0, best: 0 };
          map[code].count += c.stationcount;
          if (c.stationcount > map[code].best) { map[code].best = c.stationcount; map[code].name = c.name; }
        });
        state.countries = Object.keys(map).map(function (k) { return map[k]; }).sort(function (a, b) { return b.count - a.count; });
      })
      .catch(function () { /* dicoba lagi saat pemilih negara dibuka */ })
      .then(function () { state.countriesLoading = false; renderStatic(); if (!$('drawer').hidden) renderCountries(); });
  }

  function registerClick(s) { api('/json/url/' + encodeURIComponent(s.stationuuid)).catch(function () {}); }

