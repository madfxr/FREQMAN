  // ------------------------------------------------------------------ Pemutar audio
  var audio = new Audio();
  audio.preload = 'none';
  var hls = null;
  var streamActive = false;
  var stallTimer = null;
  var hlsLoader = null;

  function loadHls() {
    if (window.Hls) return Promise.resolve(window.Hls);
    if (!hlsLoader) {
      hlsLoader = new Promise(function (resolve) {
        var sc = document.createElement('script');
        sc.src = 'hls.light.min.js';
        sc.onload = function () { resolve(window.Hls || null); };
        sc.onerror = function () { resolve(null); };
        document.head.appendChild(sc);
      });
    }
    return hlsLoader;
  }

  // ---- Daftar alamat yang dicoba berurutan untuk satu stasiun:
  // alamat terselesaikan, alamat asli, lalu variasi http <-> https dari keduanya.
  function streamCandidates(s) {
    var list = [];
    function add(u) {
      u = String(u || '').trim();
      if (/^https?:\/\//i.test(u) && list.indexOf(u) < 0) list.push(u);
    }
    var base = [s.url_resolved, s.url];
    var verified = okUrl(s);
    if (verified) {
      // Sudah terbukti menjawab saat diperiksa: cukup alamat itu + satu cadangan (cepat mulai / cepat gagal)
      add(verified);
      base.forEach(function (u) { if (list.length < 2) add(u); });
    } else {
      base.forEach(add);
      base.forEach(function (u) {
        u = String(u || '').trim();
        if (/^http:\/\//i.test(u)) add('https://' + u.slice(7));
        else if (/^https:\/\//i.test(u)) add('http://' + u.slice(8));
      });
      list = list.slice(0, 3);
    }
    // Di halaman https (versi web), browser menolak http: dahulukan https.
    if (!nativeAudio && location.protocol === 'https:') {
      list = list.filter(function (u) { return /^https:/i.test(u); }).concat(list.filter(function (u) { return !/^https:/i.test(u); }));
    }
    return list;
  }

  // Di aplikasi Android, suara diputar pemutar bawaan Android (lebih banyak format, HLS tanpa
  // batasan CORS). Bila semua alamat gagal di sana, pemutar browser dicoba sebagai cadangan.
  var nativeAudio = !!(window.FreqManAndroid && window.FreqManAndroid.nativePlay);
  var candidates = [];
  var candIdx = 0;
  var useWebAudio = !nativeAudio;

  function teardown() {
    streamActive = false;
    clearTimeout(stallTimer);
    if (hls) { try { hls.destroy(); } catch (e) { /* abaikan */ } hls = null; }
    try { audio.pause(); } catch (e) { /* abaikan */ }
    audio.removeAttribute('src');
    try { audio.load(); } catch (e) { /* abaikan */ }
    if (nativeAudio) { try { window.FreqManAndroid.nativeStop(); } catch (e) { /* abaikan */ } }
  }

  function armStallTimer() {
    clearTimeout(stallTimer);
    // Alamat yang tidak merespons dalam 8 detik dilewati
    stallTimer = setTimeout(function () { if (streamActive && state.buffering) onStreamError(); }, 8000);
  }

  // Mulai dari awal (saat stasiun dipilih atau tombol Putar ditekan lagi)
  // Batas waktu total sejak stasiun diketuk: lewat dari ini langsung "Gagal Memutar Siaran"
  var START_DEADLINE_MS = 30000;
  var startedAt = 0, deadlineTimer = null;

  // ---- Urutan pemutar untuk satu stasiun.
  // Pemutar Android dulu (HLS & playlist tanpa batasan, judul lagu), lalu pemutar web sebagai cadangan.
  // Kecuali stasiun bitrate rendah: pemutar Android mengisi buffer dengan jumlah data tetap, sehingga
  // stasiun 32–64 kbps bisa butuh puluhan detik untuk mulai; pemutar web mulai dalam 1–2 detik.
  var LOW_BITRATE = 96;
  var plan = ['web'], planIdx = 0;
  // Aplikasi versi Kotlin memakai ExoPlayer: cepat di semua bitrate, jadi selalu pemutar Android dulu.
  var exoEngine = (function () { try { return window.FreqManAndroid.engine() === 'exoplayer'; } catch (e) { return false; } })();
  function playerPlan(s) {
    if (!nativeAudio) return ['web'];
    if (exoEngine) return ['native', 'web'];
    var first = candidates[0] || '';
    var needsNative = s.hls === 1 || /\.m3u8(\?|$)/i.test(first) || /\.(pls|m3u|asx|xspf)(\?|$)/i.test(first);
    var lowRate = (s.bitrate > 0 && s.bitrate < LOW_BITRATE) || /aac\+|he-?aac/i.test(String(s.codec || ''));
    return (lowRate && !needsNative) ? ['web', 'native'] : ['native', 'web'];
  }
  // Pemutar ini gagal: coba pemutar satunya selama sisa waktu masih ada (bukan langsung "Gagal")
  function nextPlayer() {
    if (playedThisStream || planIdx + 1 >= plan.length) return false;
    if (Date.now() - startedAt > START_DEADLINE_MS - 3000) return false;
    planIdx++;
    useWebAudio = plan[planIdx] === 'web';
    candIdx = 0;
    openCandidate();
    return true;
  }
  function startStream() {
    var s = state.current;
    if (!s) return;
    startedAt = Date.now();
    clearTimeout(deadlineTimer);
    deadlineTimer = setTimeout(function () {
      if (streamActive && !playedThisStream) { useWebAudio = true; candIdx = candidates.length; failPlayback(); }
    }, START_DEADLINE_MS);
    candidates = streamCandidates(s);
    candIdx = 0;
    plan = playerPlan(s); planIdx = 0;
    useWebAudio = plan[0] === 'web';
    playedThisStream = false;
    reconnects = 0;
    if (!candidates.length) { failPlayback(); return; }
    openCandidate();
  }

  function openCandidate() {
    var s = state.current;
    teardown();
    streamActive = true;
    state.buffering = true; state.playing = false;
    syncPlayback();
    if (!useWebAudio) {
      try { window.FreqManAndroid.nativePlay(JSON.stringify(candidates)); }
      catch (e) { useWebAudio = true; openCandidate(); }
      return;
    }
    armStallTimer();
    var url = candidates[candIdx];
    var isHls = s.hls === 1 || /\.m3u8(\?|$)/i.test(url);
    if (isHls && !audio.canPlayType('application/vnd.apple.mpegurl')) {
      loadHls().then(function (Hls) {
        if (state.current !== s || !streamActive) return;
        if (!Hls || !Hls.isSupported()) { onStreamError(); return; }
        hls = new Hls();
        hls.on(Hls.Events.ERROR, function (e, d) { if (d && d.fatal) onStreamError(); });
        hls.loadSource(url);
        hls.attachMedia(audio);
        audio.play().catch(onPlayRejected);
      });
    } else {
      audio.src = url;
      audio.play().catch(onPlayRejected);
    }
  }

  function onPlayRejected(err) {
    if (!streamActive) return;
    if (err && err.name === 'AbortError') return;
    if (err && err.name === 'NotAllowedError') { // browser menolak autoplay
      teardown(); state.playing = false; state.buffering = false; syncPlayback(); return;
    }
    onStreamError();
  }

  // Satu alamat gagal di pemutar browser: coba alamat berikutnya sebelum menyerah
  var playedThisStream = false, reconnects = 0;
  function onStreamError() {
    if (!state.current) return;
    // Sempat berbunyi lalu putus (mis. ganti Wi-Fi ke data): sambung ulang alamat yang sama dulu
    if (useWebAudio && playedThisStream && reconnects < 2 && navigator.onLine !== false) {
      reconnects++;
      openCandidate();
      return;
    }
    if (useWebAudio && candIdx + 1 < candidates.length) {
      candIdx++;
      openCandidate();
      return;
    }
    if (!nextPlayer()) failPlayback();
  }

  function failPlayback() {
    // Internet sedang putus: jangan anggap stasiun mati; sambung lagi otomatis saat online
    if (navigator.onLine === false) {
      teardown();
      state.playing = false; state.buffering = false; state.waitingNetwork = true;
      syncPlayback();
      toast('offlineTitle', 'offlineDesc', 'wifiOff', true);
      return;
    }
    // Sempat berbunyi lalu putus: gangguan sementara, stasiun tidak disembunyikan
    if (!playedThisStream) {
      markFailed(state.current);
      if (state.current) { probeCache[state.current.stationuuid] = { ok: 0, url: '', t: Date.now() }; saveProbeSoon(); }
    }
    teardown();
    state.playing = false; state.buffering = false;
    syncPlayback();
    toast('playbackFailedTitle', 'playbackFailedDesc', 'alert', true);
  }

  // Laporan dari pemutar bawaan Android
  function onNativeState(st) {
    if (st === 'sleep') { sleepFired(); return; } // timer tidur dari layanan Android
    if (!nativeAudio || !state.current || !streamActive || useWebAudio) return;
    if (st === 'playing') {
      playedThisStream = true;
      markPlayed(state.current);
      state.playing = true; state.buffering = false; syncPlayback();
    } else if (st === 'buffering') {
      state.buffering = true; syncPlayback();
    } else if (st === 'error') {
      // Semua alamat gagal di pemutar Android: coba pemutar web (bila belum dan waktu masih ada)
      if (!nextPlayer()) failPlayback();
    } else if (st === 'stopped') {
      // Dihentikan sistem: headset dicabut atau aplikasi lain memutar audio
      streamActive = false;
      state.playing = false; state.buffering = false; syncPlayback();
    }
  }

  audio.addEventListener('playing', function () {
    if (!streamActive) return;
    playedThisStream = true;
    markPlayed(state.current);
    clearTimeout(stallTimer);
    state.playing = true; state.buffering = false; syncPlayback();
  });
  audio.addEventListener('waiting', function () {
    if (!streamActive) return;
    state.buffering = true; syncPlayback(); armStallTimer();
  });
  audio.addEventListener('pause', function () {
    if (!streamActive || !useWebAudio) return; // jeda dari sistem (mis. headset dicabut)
    teardown(); state.playing = false; state.buffering = false; syncPlayback();
  });
  audio.addEventListener('error', function () { if (streamActive && useWebAudio && !hls) onStreamError(); });

  function playStation(s) {
    state.current = slim(s);
    state.nowTitle = '';
    startStream();
    registerClick(s);
  }
  // Radio siaran langsung: jeda = putus koneksi; putar lagi = sambung ulang ke siaran terkini.
  function togglePlay() {
    if (!state.current) return;
    if (state.playing || state.buffering) {
      teardown(); state.playing = false; state.buffering = false; syncPlayback();
    } else {
      state.waitingNetwork = false;
      startStream();
    }
  }
  function closePlayer() {
    teardown();
    state.current = null; state.playing = false; state.buffering = false;
    state.nowTitle = ''; state.waitingNetwork = false;
    if (state.sleepEnd) setSleep(0, true);
    closeNp();
    syncPlayback();
  }

  function syncPlayback() {
    renderPlayer();
    refreshItems();
    updateNowPlaying();
    updateMediaSession();
    notifyNative();
    updateScreenLock();
  }

  function updateMediaSession() {
    if (!('mediaSession' in navigator)) return;
    var s = state.current;
    try {
      if (!s) { navigator.mediaSession.metadata = null; navigator.mediaSession.playbackState = 'none'; return; }
      var art = /^https?:\/\//i.test(s.favicon || '') ? [{ src: s.favicon, sizes: '512x512' }] : [];
      navigator.mediaSession.metadata = new MediaMetadata({ title: stationName(s), artist: stationLocation(s) || T().liveBroadcast, album: 'FREQMAN', artwork: art });
      navigator.mediaSession.playbackState = state.playing ? 'playing' : 'paused';
    } catch (e) { /* tidak didukung */ }
  }
  if ('mediaSession' in navigator) {
    try {
      navigator.mediaSession.setActionHandler('play', function () { if (!state.playing && !state.buffering) togglePlay(); });
      navigator.mediaSession.setActionHandler('pause', function () { if (state.playing || state.buffering) togglePlay(); });
      navigator.mediaSession.setActionHandler('stop', closePlayer);
    } catch (e) { /* tidak didukung */ }
  }

  // Jembatan ke aplikasi Android (notifikasi, layar kunci, putar di latar belakang)
  function notifyNative() {
    var bridge = window.FreqManAndroid;
    if (!bridge || !bridge.onPlaybackState) return;
    var s = state.current;
    var t = T();
    try {
      // Info tambahan untuk kontrol media di HP: status Live, cover art, atau warna + inisial
      bridge.onPlaybackState(!!s, !!(state.playing || state.buffering), s ? stationName(s) : '',
        s ? (stationLocation(s) || t.liveBroadcast) : '', t.pause, t.play, t.closePlayer,
        !!state.playing, t.live, s ? artUrl(s) : '', s ? tileColor(s) : '', s ? initials(stationName(s)) : '');
    } catch (e) { /* abaikan */ }
  }

