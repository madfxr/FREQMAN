  // ------------------------------------------------------------------ Event
  function toggleFavorite(s) {
    var t = T();
    if (isFav(s.stationuuid)) {
      state.favorites = state.favorites.filter(function (f) { return f.stationuuid !== s.stationuuid; });
      toast('removedFromFavorites', stationName(s), 'heartOff');
    } else {
      state.favorites = [slim(s)].concat(state.favorites);
      toast('savedToFavorites', stationName(s), 'circleCheck');
    }
    store.set('favs', state.favorites);
    renderStatic();
    refreshItems();
    renderFavs();
  }

  function onListClick(e) {
    var btn = e.target.closest('[data-action]');
    if (!btn) return;
    var action = btn.getAttribute('data-action');
    var item = btn.closest('.item');
    var s = item ? findStation(item.getAttribute('data-id')) : null;
    if (action === 'play' && s) {
      if (state.current && state.current.stationuuid === s.stationuuid) togglePlay(); else playStation(s);
    } else if (action === 'fav' && s) {
      toggleFavorite(s);
    } else if (action === 'retry') {
      loadStations(true);
    } else if (action === 'more') {
      state.error = false; loadStations(false);
    } else if (action === 'clear') {
      setQuery('');
    } else if (action === 'country') {
      openDrawer();
    } else if (action === 'showAll') {
      state.sort = 'popular'; // kembali ke semua stasiun
      renderStatic(); loadStations(true);
    } else if (action === 'clearHistory') {
      state.history = []; store.set('history', []);
      renderHistory();
      toast('historyCleared', '', 'circleCheck');
    } else if (action === 'browse') {
      state.tab = 'browse'; renderStatic(); renderList();
    }
  }
  $('list').addEventListener('click', onListClick);
  $('favList').addEventListener('click', onListClick);
  $('histList').addEventListener('click', onListClick);

  var searchTimer = null;
  function setQuery(q) {
    state.query = q;
    $('search').value = q;
    $('clearSearch').hidden = !q;
    clearTimeout(searchTimer);
    searchTimer = setTimeout(function () { loadStations(true); }, q ? 400 : 0);
  }
  $('search').addEventListener('input', function (e) { setQuery(e.target.value); });
  $('search').addEventListener('keydown', function (e) { if (e.key === 'Enter') e.target.blur(); });
  $('clearSearch').addEventListener('click', function () { setQuery(''); $('search').focus(); });

  $('langGroup').addEventListener('click', function (e) {
    var b = e.target.closest('[data-lang]');
    if (!b) return;
    state.lang = b.getAttribute('data-lang');
    store.set('lang', state.lang);
    renderAll();
    renderThemeButton();
    renderToast();
    if (!$('about').hidden) renderAbout();
    if (!$('np').hidden) renderNowPlaying();
    if (!$('drawer').hidden) renderCountries();
    updateMediaSession(); notifyNative();
  });

  $('sortGroup').addEventListener('click', function (e) {
    var b = e.target.closest('[data-sort]');
    if (!b || b.getAttribute('data-sort') === state.sort) return;
    state.sort = b.getAttribute('data-sort');
    renderStatic();
    loadStations(true);
  });

  $('tabBrowse').addEventListener('click', function () { state.tab = 'browse'; renderStatic(); renderList(); });
  $('tabFav').addEventListener('click', function () { state.tab = 'fav'; renderStatic(); renderFavs(); });
  $('tabHist').addEventListener('click', function () { state.tab = 'hist'; renderStatic(); renderHistory(); });

  $('countryBtn').addEventListener('click', openDrawer);
  $('drawer').addEventListener('click', function (e) {
    if (e.target.closest('[data-close]')) { closeDrawer(); return; }
    var b = e.target.closest('[data-country]');
    if (!b) return;
    state.country = b.getAttribute('data-country');
    store.set('country', state.country);
    closeDrawer();
    renderStatic();
    window.scrollTo(0, 0);
    loadStations(true);
  });
  $('countrySearch').addEventListener('input', function (e) { state.countryFilter = e.target.value; renderCountries(); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') { if (!closeNp() && !closeAbout()) closeDrawer(); } });

  $('playerToggle').addEventListener('click', togglePlay);
  $('playerClose').addEventListener('click', closePlayer);

  function maybeLoadMore() {
    if (state.tab !== 'browse') return;
    var r = $('sentinel').getBoundingClientRect();
    if (r.top < window.innerHeight + 600) wantMoreStations();
  }
  // Dekat bawah daftar: cek stasiun berikutnya dulu, baru muat halaman katalog baru
  function wantMoreStations() {
    if (!growProbeHorizon()) loadStations(false);
  }
  if ('IntersectionObserver' in window) {
    new IntersectionObserver(function (entries) {
      if (entries.some(function (en) { return en.isIntersecting; })) wantMoreStations();
    }, { rootMargin: '600px 0px' }).observe($('sentinel'));
  } else {
    window.addEventListener('scroll', maybeLoadMore, { passive: true });
  }

  // API untuk aplikasi Android
  function onNativeTitle(title) {
    // Buang awalan yang sering ditulis stasiun sendiri (ikon ♪ sudah menandainya)
    title = String(title || '').trim().replace(/^(now\s*playing|np|on\s*air|playing|sedang\s*diputar)\s*[:\-–|]\s*/i, '').trim();
    if (!state.current || title === state.nowTitle) return;
    state.nowTitle = title;
    renderPlayer();
    updateNowPlaying();
  }

  window.FreqMan = {
    nativeState: onNativeState,
    nativeTitle: onNativeTitle,
    systemTheme: function (dark) { if (!themePref) applyTheme(dark ? 'dark' : 'light', false); },
    togglePlay: togglePlay,
    close: closePlayer,
    onBack: function () {
      if ($('splash')) return false;
      if (closeNp()) return true;
      if (closeAbout()) return true;
      if (closeDrawer()) return true;
      if (state.tab !== 'browse') { state.tab = 'browse'; renderStatic(); renderList(); return true; }
      return false;
    }
  };

  window.addEventListener('online', function () {
    if (state.waitingNetwork && state.current) { state.waitingNetwork = false; startStream(); }
  });

