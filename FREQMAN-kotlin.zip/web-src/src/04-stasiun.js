  // ------------------------------------------------------------------ Data stasiun
  function stationName(s) { return String(s.name || '').trim() || 'Radio'; }
  // Nama provinsi/kota Indonesia dalam dua bahasa: [Indonesia, English, ...ejaan lain]
  var ID_REGIONS = [
    ['Aceh', 'Aceh', 'nanggroe aceh darussalam', 'nad', 'di aceh'],
    ['Sumatera Utara', 'North Sumatra', 'sumatra utara', 'north sumatera', 'sumut'],
    ['Sumatera Barat', 'West Sumatra', 'sumatra barat', 'west sumatera', 'sumbar'],
    ['Riau', 'Riau'],
    ['Kepulauan Riau', 'Riau Islands', 'kepri'],
    ['Jambi', 'Jambi'],
    ['Sumatera Selatan', 'South Sumatra', 'sumatra selatan', 'south sumatera', 'sumsel'],
    ['Kepulauan Bangka Belitung', 'Bangka Belitung Islands', 'bangka belitung', 'babel'],
    ['Bengkulu', 'Bengkulu'],
    ['Lampung', 'Lampung'],
    ['DKI Jakarta', 'Jakarta', 'jakarta', 'dki', 'jakarta raya', 'special capital region of jakarta'],
    ['Jakarta Pusat', 'Central Jakarta'],
    ['Jakarta Selatan', 'South Jakarta'],
    ['Jakarta Barat', 'West Jakarta'],
    ['Jakarta Timur', 'East Jakarta'],
    ['Jakarta Utara', 'North Jakarta'],
    ['Jawa Barat', 'West Java', 'jabar'],
    ['Banten', 'Banten'],
    ['Jawa Tengah', 'Central Java', 'jateng'],
    ['DI Yogyakarta', 'Special Region of Yogyakarta', 'yogyakarta', 'daerah istimewa yogyakarta', 'diy', 'jogja', 'jogjakarta', 'yogya'],
    ['Jawa Timur', 'East Java', 'jatim'],
    ['Bali', 'Bali'],
    ['Nusa Tenggara Barat', 'West Nusa Tenggara', 'ntb'],
    ['Nusa Tenggara Timur', 'East Nusa Tenggara', 'ntt'],
    ['Kalimantan Barat', 'West Kalimantan', 'kalbar'],
    ['Kalimantan Tengah', 'Central Kalimantan', 'kalteng'],
    ['Kalimantan Selatan', 'South Kalimantan', 'kalsel'],
    ['Kalimantan Timur', 'East Kalimantan', 'kaltim'],
    ['Kalimantan Utara', 'North Kalimantan', 'kaltara'],
    ['Sulawesi Utara', 'North Sulawesi', 'sulut'],
    ['Gorontalo', 'Gorontalo'],
    ['Sulawesi Tengah', 'Central Sulawesi', 'sulteng'],
    ['Sulawesi Barat', 'West Sulawesi', 'sulbar'],
    ['Sulawesi Selatan', 'South Sulawesi', 'sulsel'],
    ['Sulawesi Tenggara', 'Southeast Sulawesi', 'sultra'],
    ['Maluku', 'Maluku', 'moluccas'],
    ['Maluku Utara', 'North Maluku', 'malut'],
    ['Papua', 'Papua'],
    ['Papua Barat', 'West Papua'],
    ['Papua Barat Daya', 'Southwest Papua'],
    ['Papua Tengah', 'Central Papua'],
    ['Papua Pegunungan', 'Highland Papua'],
    ['Papua Selatan', 'South Papua']
  ];
  function regionKey(x) { return String(x || '').toLowerCase().replace(/[.,_()-]/g, ' ').replace(/\s+/g, ' ').trim(); }
  var REGION_MAP = {};
  ID_REGIONS.forEach(function (row) { row.forEach(function (name) { REGION_MAP[regionKey(name)] = row; }); });
  function localRegion(name, countryCode, countryText) {
    var raw = String(name || '').trim();
    if (!raw) return '';
    var isIndonesia = countryCode === 'ID' || /indonesia/i.test(countryText || '');
    var row = isIndonesia ? REGION_MAP[regionKey(raw)] : null;
    if (row) return state.lang === 'en' ? row[1] : row[0];
    return raw === raw.toLowerCase() ? titleTag(raw) : raw; // "jakarta" -> "Jakarta"
  }
  function localCountry(s) {
    var code = String(s.countrycode || '').toUpperCase();
    if (/^[A-Z]{2}$/.test(code)) return countryName(code, s.country);
    return String(s.country || '').trim();
  }
  function stationLocation(s) {
    var code = String(s.countrycode || '').toUpperCase();
    return [localRegion(s.state, code, s.country), localCountry(s)].filter(Boolean).join(', ');
  }
  // Genre/kategori dengan huruf kapital di awal kata: "pop, news" -> "Pop, News"
  var TAG_FIX = {
    'rnb': 'R&B', 'r&b': 'R&B', 'r & b': 'R&B', 'edm': 'EDM', 'idm': 'IDM', 'ebm': 'EBM', 'mpb': 'MPB',
    'fm': 'FM', 'am': 'AM', 'dj': 'DJ', 'djs': 'DJs', 'uk': 'UK', 'us': 'US', 'usa': 'USA',
    'npr': 'NPR', 'bbc': 'BBC', 'rri': 'RRI', 'lgbt': 'LGBT', 'lgbtq': 'LGBTQ', 'lgbtq+': 'LGBTQ+',
    'kpop': 'K-Pop', 'k-pop': 'K-Pop', 'jpop': 'J-Pop', 'j-pop': 'J-Pop', 'cpop': 'C-Pop', 'c-pop': 'C-Pop',
    'opm': 'OPM', 'aac': 'AAC', 'mp3': 'MP3'
  };
  var CAP_RE = (function () { try { return new RegExp('(^|[\\s\\-/&(])([\\p{L}\\d])', 'gu'); } catch (e) { return /(^|[\s\-\/&(])([a-z0-9])/g; } })();
  function titleTag(tag) {
    var k = tag.toLowerCase();
    if (TAG_FIX[k]) return TAG_FIX[k];
    return k.replace(CAP_RE, function (m, p, c) { return p + c.toUpperCase(); });
  }
  function stationGenres(s) {
    var seen = {};
    return String(s.tags || '').split(',').map(function (x) { return x.trim(); }).filter(function (x) {
      var k = x.toLowerCase();
      if (!x || seen[k]) return false;
      seen[k] = 1; return true;
    }).slice(0, 3).map(titleTag).join(', ');
  }
  // Kualitas tinggi: lossless (FLAC/ALAC/WAV) atau 256 kbps ke atas
  var LOSSLESS_CODEC = /^(flac|alac|wav|pcm|ape|wavpack)/i;
  function qualityTier(s) {
    var codec = String(s.codec || '').trim();
    if (LOSSLESS_CODEC.test(codec) || /\.flac(\?|$)/i.test(s.url_resolved || s.url || '')) return 'lossless';
    if ((s.bitrate || 0) >= 256) return 'hq';
    return '';
  }
  function qualityBadge(s) {
    var tier = qualityTier(s);
    // HQ+ = lossless (FLAC dsb.), HQ = 256 kbps ke atas
    return tier ? '<span class="q-badge">' + (tier === 'lossless' ? 'HQ+' : 'HQ') + '</span>' : '';
  }
  function stationDetail(s) {
    var genres = stationGenres(s);
    var q = s.codec ? (s.bitrate > 0 ? s.codec + ' ' + s.bitrate + ' kbps' : s.codec) : '';
    return [genres, q].filter(Boolean).join(' / ');
  }
  function initials(name) {
    var parts = name.split(/\s+/).filter(Boolean);
    return ((parts[0] || '?').charAt(0) + (parts[1] ? parts[1].charAt(0) : '')).toUpperCase();
  }
  function slim(s) {
    return {
      stationuuid: s.stationuuid, name: s.name, url: s.url, url_resolved: s.url_resolved, favicon: s.favicon,
      tags: s.tags, country: s.country, countrycode: s.countrycode, state: s.state, codec: s.codec, bitrate: s.bitrate, hls: s.hls, homepage: s.homepage
    };
  }
  function isFav(id) { return state.favorites.some(function (f) { return f.stationuuid === id; }); }
  function findStation(id) {
    var all = state.stations.concat(state.favorites, state.history);
    for (var i = 0; i < all.length; i++) if (all[i].stationuuid === id) return all[i];
    return null;
  }

