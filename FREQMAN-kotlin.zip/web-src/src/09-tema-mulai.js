  // ------------------------------------------------------------------ Tema terang / gelap
  var themePref = store.get('theme', null); // 'light' | 'dark' | null (ikuti sistem)
  var splashActive = !!document.getElementById('splash'); // splash selalu gelap
  function currentTheme() { return document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light'; }
  function applyTheme(theme, save) {
    document.documentElement.setAttribute('data-theme', theme);
    var meta = $('themeColor');
    if (meta) meta.setAttribute('content', splashActive || theme === 'dark' ? '#0a0a0a' : '#ffffff');
    if (save) { themePref = theme; store.set('theme', theme); }
    renderThemeButton();
    var bridge = window.FreqManAndroid;
    if (bridge && bridge.onThemeChange) { try { bridge.onThemeChange(splashActive || theme === 'dark'); } catch (e) { /* abaikan */ } }
  }
  function renderThemeButton() {
    var t = T();
    var label = currentTheme() === 'dark' ? t.themeToLight : t.themeToDark;
    $('themeBtn').setAttribute('aria-label', label);
    $('themeBtn').setAttribute('title', label);
  }
  $('themeBtn').addEventListener('click', function () { applyTheme(currentTheme() === 'dark' ? 'light' : 'dark', true); });
  if (window.matchMedia) {
    var mq = window.matchMedia('(prefers-color-scheme: dark)');
    var onSystemTheme = function (e) { if (!themePref) applyTheme(e.matches ? 'dark' : 'light', false); };
    if (mq.addEventListener) mq.addEventListener('change', onSystemTheme); else if (mq.addListener) mq.addListener(onSystemTheme);
  }
  applyTheme(themePref || currentTheme(), false);

  // ------------------------------------------------------------------ Logo simetris
  // "Frequency Manager" diberi jarak huruf agar persis selebar "FREQMAN" (atau sebaliknya
  // bila tulisan kecil lebih lebar). Diukur di perangkat, jadi tepat untuk font apa pun.
  function fitLockups() {
    Array.prototype.forEach.call(document.querySelectorAll('[data-lockup-base]'), function (box) {
      var name = box.querySelector('[data-lockup="name"]');
      var tag = box.querySelector('[data-lockup="tag"]');
      if (!name || !tag) return;
      var base = parseFloat(box.getAttribute('data-lockup-base')) || 0;
      function set(el, ls) { el.style.letterSpacing = ls + 'px'; el.style.marginRight = (-ls) + 'px'; }
      function visible(el, ls) { return el.getBoundingClientRect().width - ls; }
      set(name, base); set(tag, 0);
      var nameW = visible(name, base), tagW = visible(tag, 0);
      if (!nameW || !tagW) return; // belum tampil
      var gapsName = Math.max(1, name.textContent.length - 1), gapsTag = Math.max(1, tag.textContent.length - 1);
      if (tagW < nameW) set(tag, (nameW - tagW) / gapsTag);
      else set(name, base + (tagW - nameW) / gapsName);
    });
  }
  fitLockups();
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(fitLockups);
  if (document.fonts && document.fonts.addEventListener) document.fonts.addEventListener('loadingdone', fitLockups);
  window.addEventListener('resize', fitLockups);

  // ------------------------------------------------------------------ Splash 5 detik
  // Katalog sudah mulai dimuat di belakang layar selama splash tampil.
  // Tampil sekali per pembukaan aplikasi; memuat ulang halaman di sesi yang sama tidak memunculkannya lagi.
  var SPLASH_MS = 5000;
  var splashSeen = false;
  try { splashSeen = sessionStorage.getItem('freqman:splash') === '1'; sessionStorage.setItem('freqman:splash', '1'); } catch (e) { /* abaikan */ }
  function endSplash(fade) {
    var sp = $('splash');
    if (!sp) return;
    splashActive = false;
    applyTheme(currentTheme(), false); // kembalikan warna status bar sesuai tema
    if ($('drawer').hidden) document.body.classList.remove('lock');
    if (!fade) { sp.parentNode.removeChild(sp); return; }
    sp.classList.add('hide');
    setTimeout(function () { if (sp.parentNode) sp.parentNode.removeChild(sp); }, 450);
  }
  if (splashSeen) endSplash(false); else setTimeout(function () { endSplash(true); }, SPLASH_MS);

  // ------------------------------------------------------------------ Layar tetap menyala
  // Hanya selama radio diputar (hemat baterai). Versi web: Screen Wake Lock browser;
  // di aplikasi Android diatur oleh Android lewat status pemutaran.
  var wakeLock = null;
  function updateScreenLock() {
    if (state.playing || state.buffering) keepScreenOn();
    else if (wakeLock) { try { wakeLock.release(); } catch (e) { /* abaikan */ } wakeLock = null; }
  }
  function keepScreenOn() {
    if (!(state.playing || state.buffering)) return;
    if (window.FreqManAndroid || wakeLock || !('wakeLock' in navigator) || document.visibilityState !== 'visible') return;
    navigator.wakeLock.request('screen').then(function (lock) {
      wakeLock = lock;
      lock.addEventListener('release', function () { wakeLock = null; });
    }).catch(function () { /* tidak didukung / ditolak browser */ });
  }
  document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'visible') keepScreenOn(); });
  document.addEventListener('pointerdown', keepScreenOn, { passive: true }); // sebagian browser butuh sentuhan dulu
  keepScreenOn();

  // ------------------------------------------------------------------ Mulai
  renderAll();
  loadBlocklist();
  loadCountries();
  loadStations(true);
})();
