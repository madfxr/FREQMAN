  // ------------------------------------------------------------------ Render
  // Warna latar untuk stasiun tanpa cover art: tampak acak, tapi tetap sama untuk stasiun yang sama.
  // Semua warna cukup gelap agar inisial putih tetap terbaca (kontras >= 4.5:1).
  var TILE_COLORS = ['#b91c1c', '#c2410c', '#a16207', '#4d7c0f', '#15803d', '#0f766e', '#0e7490',
    '#0369a1', '#1d4ed8', '#4338ca', '#6d28d9', '#a21caf', '#be185d', '#be123c', '#475569'];
  function tileColor(s) {
    var key = String(s.stationuuid || s.name || ''), h = 0;
    for (var i = 0; i < key.length; i++) h = (h * 31 + key.charCodeAt(i)) >>> 0;
    return TILE_COLORS[h % TILE_COLORS.length];
  }
  // 5 garis seperti logo FREQMAN (lihat .bars di styles.css)
  var BARS_HTML = '<span class="bars" aria-hidden="true"><span></span><span></span><span></span><span></span><span></span></span>';
  function artUrl(s) { return /^https?:\/\//i.test(s.favicon || '') ? s.favicon : ''; }
  // Cover art resmi ditampilkan apa adanya (tanpa warna). Warna + inisial hanya dipakai
  // bila stasiun tidak punya cover art, atau cover art-nya gagal dimuat / terlalu kecil.
  window.FreqManArtFail = function (img) {
    var tile = img.parentNode;
    if (tile) {
      tile.classList.remove('has-art');
      tile.style.background = tile.getAttribute('data-color') || '';
    }
    if (img.parentNode) img.parentNode.removeChild(img);
  };
  function mediaAttrs(s) {
    return artUrl(s)
      ? ' class="media has-art" data-color="' + tileColor(s) + '"'
      : ' class="media" data-color="' + tileColor(s) + '" style="background:' + tileColor(s) + '"';
  }
  function mediaHtml(s, showBars) {
    var art = artUrl(s);
    return '<span class="media-initials">' + esc(initials(stationName(s))) + '</span>' +
      (art ? '<img src="' + esc(art) + '" alt="" loading="lazy" referrerpolicy="no-referrer" onerror="FreqManArtFail(this)" onload="if(this.naturalWidth<24||this.naturalHeight<24)FreqManArtFail(this)">' : '') +
      (showBars ? BARS_HTML : '');
  }
  // Animasi "sedang diputar" dipasang/dilepas tanpa menyentuh gambar logo
  function setBars(media, on) {
    if (!media) return;
    var bars = media.querySelector('.bars');
    if (on && !bars) media.insertAdjacentHTML('beforeend', BARS_HTML);
    else if (!on && bars) media.removeChild(bars);
  }

  function itemHtml(s) {
    var t = T();
    var name = stationName(s);
    var cur = state.current && state.current.stationuuid === s.stationuuid;
    var fav = isFav(s.stationuuid);
    var loc = stationLocation(s) || t.unknownLocation;
    var detail = stationDetail(s);
    return '<div class="item' + (cur ? ' item-current' : '') + '" data-id="' + esc(s.stationuuid) + '">' +
      '<button type="button" class="item-main" data-action="play" aria-label="' + esc((cur && state.playing ? t.pause : t.play) + ': ' + name) + '">' +
      '<span' + mediaAttrs(s) + '>' + mediaHtml(s, cur && state.playing) + '</span>' +
      '<span class="item-content"><span class="item-title-row"><span class="item-title">' + esc(name) + '</span>' +
      qualityBadge(s) +
      '<span class="fail-badge"' + (hasFailed(s) ? '' : ' hidden') + '>' + esc(t.failedLastTime) + '</span></span>' +
      '<span class="item-desc">' + esc(loc) + '</span>' +
      (detail ? '<span class="item-desc xs">' + esc(detail) + '</span>' : '') +
      '</span></button>' +
      '<button type="button" class="btn btn-ghost btn-icon-lg" data-action="fav" aria-pressed="' + fav + '" aria-label="' + esc((fav ? t.removeFavorite : t.saveFavorite) + ': ' + name) + '">' +
      svg('heart', 16, { fill: fav }) + '</button></div>';
  }

  // Label tombol dalam ID & EN ditumpuk (yang tidak aktif disembunyikan): lebar tombol sama di kedua bahasa
  function bothLangs(key) {
    return '<span class="same-width">' + ['id', 'en'].map(function (lang) {
      var txt = esc(I18N[lang][key]);
      return lang === state.lang ? '<span>' + txt + '</span>' : '<span class="ghost" aria-hidden="true">' + txt + '</span>';
    }).join('') + '</span>';
  }
  function emptyHtml(icon, title, desc, actionKey, action, dashed) {
    return '<div class="empty' + (dashed ? ' dashed' : '') + '"><div class="empty-media">' + svg(icon, 24) + '</div>' +
      '<h2>' + esc(title) + '</h2><p>' + esc(desc) + '</p>' +
      (actionKey ? '<button type="button" class="btn btn-outline" data-action="' + action + '">' + bothLangs(actionKey) + '</button>' : '') + '</div>';
  }

  function skeletonHtml() {
    var w = [['62%', '40%'], ['54%', '36%'], ['70%', '44%'], ['48%', '32%'], ['64%', '42%'], ['58%', '38%'], ['66%', '40%'], ['52%', '34%']];
    return w.map(function (x) {
      return '<div class="skeleton-row" aria-hidden="true"><div class="skeleton" style="width:44px;height:44px"></div>' +
        '<div style="display:flex;flex-direction:column;gap:8px;flex:1"><div class="skeleton" style="height:14px;width:' + x[0] + '"></div>' +
        '<div class="skeleton" style="height:12px;width:' + x[1] + '"></div></div></div>';
    }).join('');
  }

  function currentCountryLabel() {
    var c = state.countries.filter(function (x) { return x.code === state.country; })[0];
    return countryName(state.country, c ? c.name : '');
  }

  // Perbarui satu baris stasiun di tempat: status putar, hati, label, lokasi.
  function updateItem(el, s) {
    var t = T();
    var fb = el.querySelector('.fail-badge');
    if (fb) {
      fb.hidden = !hasFailed(s);
      if (fb.textContent !== t.failedLastTime) fb.textContent = t.failedLastTime;
    }
    var name = stationName(s);
    var cur = !!(state.current && state.current.stationuuid === s.stationuuid);
    var playingHere = cur && state.playing;
    var fav = isFav(s.stationuuid);
    el.classList.toggle('item-current', cur);
    var main = el.querySelector('[data-action="play"]');
    if (main) main.setAttribute('aria-label', (playingHere ? t.pause : t.play) + ': ' + name);
    setBars(el.querySelector('.media'), playingHere);
    var loc = el.querySelector('.item-desc');
    var locText = stationLocation(s) || t.unknownLocation;
    if (loc && loc.textContent !== locText) loc.textContent = locText;
    var heart = el.querySelector('[data-action="fav"]');
    if (heart) {
      if (heart.getAttribute('aria-pressed') !== String(fav)) {
        heart.setAttribute('aria-pressed', String(fav));
        heart.innerHTML = svg('heart', 16, { fill: fav });
      }
      heart.setAttribute('aria-label', (fav ? t.removeFavorite : t.saveFavorite) + ': ' + name);
    }
  }

  function htmlToElement(html) {
    var tpl = document.createElement('template');
    tpl.innerHTML = html.trim();
    return tpl.content.firstChild;
  }

  // Cocokkan isi daftar dengan data berdasarkan id stasiun: baris yang sudah ada dipakai ulang
  // (gambar logonya tidak dimuat ulang), hanya baris baru yang dibuat, yang hilang dihapus.
  function syncItems(container, stations, headHtml, footHtml) {
    Array.prototype.slice.call(container.children).forEach(function (ch) {
      if (!ch.classList.contains('item')) container.removeChild(ch);
    });
    var existing = {};
    Array.prototype.forEach.call(container.children, function (el) { existing[el.getAttribute('data-id')] = el; });
    var cursor = container.firstElementChild;
    stations.forEach(function (s) {
      var el = existing[s.stationuuid];
      if (el) { delete existing[s.stationuuid]; updateItem(el, s); }
      else el = htmlToElement(itemHtml(s));
      if (el === cursor) cursor = cursor.nextElementSibling;
      else container.insertBefore(el, cursor);
    });
    Object.keys(existing).forEach(function (id) { var el = existing[id]; if (el.parentNode) el.parentNode.removeChild(el); });
    if (headHtml) container.insertAdjacentHTML('afterbegin', headHtml);
    if (footHtml) container.insertAdjacentHTML('beforeend', footHtml);
  }

  function renderList() {
    var t = T();
    var list = $('list');
    var html = null;
    var vis = visibleStations();
    var mayLoadMore = !state.endReached && !state.error && (state.autoPages || 0) < 5;
    if (state.loading && !vis.list.length) {
      html = skeletonHtml();
    } else if (state.error && !vis.list.length) {
      html = emptyHtml('wifiOff', t.errorTitle, t.errorDesc, 'retry', 'retry');
    } else if (!vis.list.length && (vis.pending || state.loadingMore || mayLoadMore)) {
      html = skeletonHtml(); // masih memeriksa stasiun
    } else if (!vis.list.length && state.sort === 'hq') {
      html = emptyHtml('tower', t.hqEmptyTitle, t.hqEmptyDesc(currentCountryLabel()), 'showAll', 'showAll');
    } else if (!vis.list.length && state.query.trim()) {
      html = emptyHtml('searchX', t.notFoundTitle, t.notFoundDesc(state.query.trim(), currentCountryLabel()), 'clearSearch', 'clear');
    } else if (!vis.list.length) {
      html = emptyHtml('tower', t.noStationsTitle, t.noStationsDesc(currentCountryLabel()), 'pickOtherCountry', 'country');
    }
    if (html !== null) { list.innerHTML = html; return; }
    var head = state.loading ? '<div class="list-footer">' + svg('loader', 16, { cls: 'spinner' }) + esc(t.refreshing) + '</div>' : '';
    var foot = '';
    if (state.loadingMore || vis.pending) foot = '<div class="list-footer">' + svg('loader', 20, { cls: 'spinner' }) + '<span class="sr-only">' + esc(t.loadingMore) + '</span></div>';
    else if (state.error) foot = '<div class="list-footer"><button type="button" class="btn btn-outline" data-action="more">' + bothLangs('loadMoreFailed') + '</button></div>';
    vis.list.forEach(function (st) { shownIds[st.stationuuid] = 1; });
    syncItems(list, vis.list, head, foot);
  }

  function renderHistory() {
    var t = T();
    var box = $('histList');
    var list = visibleHistory();
    if (!list.length) {
      box.innerHTML = emptyHtml('history', t.emptyHistTitle, t.emptyHistDesc, 'browseStations', 'browse', true);
      return;
    }
    syncItems(box, list, '', '<div class="list-footer"><button type="button" class="btn btn-outline" data-action="clearHistory">' + bothLangs('clearHistory') + '</button></div>');
  }

  function renderFavs() {
    var t = T();
    var box = $('favList');
    var favs = visibleFavorites();
    if (!favs.length) {
      box.innerHTML = emptyHtml('heart', t.emptyFavTitle, t.emptyFavDesc, 'browseStations', 'browse', true);
      return;
    }
    syncItems(box, favs, '', '');
  }

  // Hanya memperbarui status baris yang sudah tampil (dipakai saat putar/jeda & favorit)
  function refreshItems() {
    ['list', 'favList', 'histList'].forEach(function (id) {
      Array.prototype.forEach.call($(id).querySelectorAll('.item'), function (el) {
        var s = findStation(el.getAttribute('data-id'));
        if (s) updateItem(el, s);
      });
    });
  }

  function renderStatic() {
    var t = T();
    document.documentElement.lang = state.lang;
    document.title = 'FREQMAN — Frequency Manager';
    Array.prototype.forEach.call(document.querySelectorAll('[data-t]'), function (el) { el.textContent = t[el.getAttribute('data-t')]; });
    $('langGroup').setAttribute('aria-label', t.switchLanguage);
    $('aboutBtn').setAttribute('aria-label', 'FREQMAN, ' + t.aboutOpen);
    Array.prototype.forEach.call(document.querySelectorAll('#langGroup button'), function (b) {
      b.setAttribute('aria-checked', String(b.getAttribute('data-lang') === state.lang));
    });
    var search = $('search');
    search.placeholder = t.searchPlaceholder;
    search.setAttribute('aria-label', t.searchPlaceholder);
    $('clearSearch').setAttribute('aria-label', t.clearSearch);
    $('clearSearch').hidden = !state.query;
    $('countrySearch').placeholder = t.searchCountry;
    $('countrySearch').setAttribute('aria-label', t.searchCountry);

    var label = currentCountryLabel();
    $('countryCode').textContent = state.country || 'ALL';
    $('countryLabel').textContent = label;
    $('countryBtn').setAttribute('aria-label', t.changeCountry + ': ' + label);

    var count = state.country
      ? (state.countries.filter(function (c) { return c.code === state.country; })[0] || { count: 0 }).count
      : state.countries.reduce(function (a, c) { return a + c.count; }, 0);
    // Teks ID dan EN ditumpuk di tempat yang sama (yang tidak aktif disembunyikan),
    // jadi lebar badge selalu sama di kedua bahasa tanpa perlu ukuran tetap.
    var labels = ['id', 'en'].map(function (lang) {
      var d = I18N[lang];
      var n = count > 0 ? (function () { try { return new Intl.NumberFormat(d.locale).format(count); } catch (e) { return String(count); } })() : '';
      return { lang: lang, text: count > 0 ? d.stations(n) : d.loadingCatalog };
    });
    $('countBadge').innerHTML = (count > 0 ? '' : svg('loader', 12, { cls: 'spinner' })) +
      '<span class="same-width">' + labels.map(function (l) {
        return l.lang === state.lang ? '<span>' + esc(l.text) + '</span>' : '<span class="ghost" aria-hidden="true">' + esc(l.text) + '</span>';
      }).join('') + '</span>';

    $('tabBrowse').textContent = t.tabBrowse;
    var favCount = visibleFavorites().length;
    $('tabFav').textContent = favCount ? t.tabFavorites + ' (' + favCount + ')' : t.tabFavorites;
    $('tabHist').textContent = t.tabHistory;
    $('tabBrowse').setAttribute('aria-selected', String(state.tab === 'browse'));
    $('tabFav').setAttribute('aria-selected', String(state.tab === 'fav'));
    $('tabHist').setAttribute('aria-selected', String(state.tab === 'hist'));
    $('browsePane').hidden = state.tab !== 'browse';
    $('sortRow').hidden = state.tab !== 'browse';
    $('favPane').hidden = state.tab !== 'fav';
    $('histPane').hidden = state.tab !== 'hist';

    var sg = $('sortGroup');
    sg.setAttribute('aria-label', t.sortGroup);
    sg.innerHTML = Object.keys(SORTS).map(function (k) {
      var short = t.sortsShort && t.sortsShort[k];
      var label = short ? '<span class="lbl-long">' + esc(t.sorts[k]) + '</span><span class="lbl-short">' + esc(short) + '</span>' : esc(t.sorts[k]);
      return '<button type="button" role="radio" data-sort="' + k + '" aria-checked="' + (state.sort === k) + '" aria-label="' + esc(t.sorts[k]) + '">' + label + '</button>';
    }).join('');
  }

  function renderPlayer() {
    var t = T();
    var s = state.current;
    var player = $('player');
    document.body.classList.toggle('has-player', !!s);
    player.hidden = !s;
    if (!s) return;
    var name = stationName(s);
    var pm = $('playerMedia');
    if (pm.getAttribute('data-id') !== s.stationuuid) {
      pm.setAttribute('data-id', s.stationuuid);
      var art = !!artUrl(s);
      pm.classList.toggle('has-art', art);
      pm.setAttribute('data-color', tileColor(s));
      pm.style.background = art ? '' : tileColor(s);
      pm.innerHTML = mediaHtml(s, state.playing);
    } else {
      setBars(pm, state.playing);
    }
    $('playerTitle').textContent = name;
    $('playerOpen').setAttribute('aria-label', t.openPlayer + ': ' + name);
    var badge;
    badge = state.playing ? '<span class="badge badge-status badge-live"><span class="live-dot"></span>' + esc(t.live) + '</span>' : '';
    $('playerBadge').innerHTML = badge;
    // Judul lagu (bila stasiun mengirimkannya) menggantikan lokasi
    $('playerSub').textContent = state.nowTitle ? '♪ ' + state.nowTitle : (stationLocation(s) || t.liveBroadcast);
    // Sama seperti di daftar: genre / kualitas siaran
    var detail = stationDetail(s);
    $('playerDetail').textContent = detail;
    $('playerDetail').hidden = !detail;
    var active = state.playing || state.buffering;
    var toggle = $('playerToggle');
    toggle.setAttribute('aria-label', active ? t.pause : t.play);
    toggle.innerHTML = state.buffering ? svg('loader', 16, { cls: 'spinner' }) : svg(state.playing ? 'pause' : 'play', 16, { fill: true });
    $('playerClose').setAttribute('aria-label', t.closePlayer);
  }

  function renderCountries() {
    var t = T();
    var f = state.countryFilter.trim().toLowerCase();
    var rows = state.countries.map(function (c) { return { c: c, name: countryName(c.code, c.name) }; })
      .filter(function (r) {
        return !f || r.name.toLowerCase().indexOf(f) >= 0 || String(r.c.name).toLowerCase().indexOf(f) >= 0 || r.c.code.toLowerCase() === f;
      });
    var html = '';
    if (!f) {
      html += '<div class="command-heading">' + esc(t.groupGeneral) + '</div>' +
        '<button type="button" class="command-item" role="option" data-country="" aria-selected="' + (!state.country) + '">' +
        '<span class="code-chip">ALL</span><span class="grow">' + esc(t.worldwide) + '</span>' +
        (!state.country ? svg('check') : '') + '</button>';
    }
    if (!state.countries.length) {
      html += '<div class="command-empty" style="display:flex;justify-content:center;gap:8px">' + svg('loader', 16, { cls: 'spinner' }) + esc(t.loadingCountries) + '</div>';
    } else if (!rows.length) {
      html += '<div class="command-empty">' + esc(t.countryNotFound) + '</div>';
    } else {
      html += '<div class="command-heading">' + esc(t.groupCountries) + '</div>' + rows.map(function (r) {
        var sel = r.c.code === state.country;
        return '<button type="button" class="command-item" role="option" data-country="' + r.c.code + '" aria-selected="' + sel + '">' +
          '<span class="code-chip">' + r.c.code + '</span><span class="grow ellipsis">' + esc(r.name) + '</span>' +
          (sel ? svg('check') : '<span class="count">' + fmt(r.c.count) + '</span>') + '</button>';
      }).join('');
    }
    $('countryList').innerHTML = html;
  }

  function renderAll() { renderStatic(); renderList(); renderFavs(); renderHistory(); renderPlayer(); }

  // ------------------------------------------------------------------ Toast
  var toastTimer = null;
  var toastData = null; // { title: kunci teks, desc: kunci teks atau teks bebas, descIsKey, icon }
  function renderToast() {
    var el = $('toast');
    if (!toastData || el.hidden) return;
    var t = T();
    var title = t[toastData.title];
    var desc = toastData.descIsKey ? t[toastData.desc] : toastData.desc;
    el.innerHTML = svg(toastData.icon || 'circleCheck') + '<div class="toast-text"><span class="toast-title">' + esc(title) + '</span>' +
      (desc ? '<span class="muted">' + esc(desc) + '</span>' : '') + '</div>';
  }
  function toast(titleKey, desc, icon, descIsKey) {
    var el = $('toast');
    toastData = { title: titleKey, desc: desc, descIsKey: !!descIsKey, icon: icon };
    el.hidden = false;
    renderToast();
    el.style.animation = 'none'; void el.offsetWidth; el.style.animation = '';
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.hidden = true; }, 3500);
  }
  $('toast').addEventListener('click', function () { $('toast').hidden = true; });

