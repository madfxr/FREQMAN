/* FreqMan — Frequency Manager
 * Katalog: Radio Browser API (https://api.radio-browser.info), publik & gratis.
 * Dipakai bersama oleh versi web dan aplikasi Android (WebView).
 */
(function () {
  'use strict';

  // ================================================================== PENGATURAN
  // Isi email kontak untuk pemilik stasiun yang ingin stasiunnya dihapus dari FREQMAN.
  // Selama kosong, halaman "Tentang" hanya menampilkan nama pengembang tanpa tombol email.
  var CONTACT_EMAIL = 'madfxr@protonmail.com';
  // Opsional: alamat blocklist.json yang di-hosting online (mis. di server versi web),
  // agar stasiun bisa disembunyikan tanpa merilis APK baru. Server harus mengizinkan CORS.
  var BLOCKLIST_URL = '';
  var DEVELOPER = 'Nur Mukhammad Agus';
  var APP_VERSION = '1.0';

