  // ------------------------------------------------------------------ Laci negara
  var lastFocus = null;
  function openDrawer() {
    loadCountries();
    state.countryFilter = '';
    $('countrySearch').value = '';
    renderCountries();
    lastFocus = document.activeElement;
    $('drawer').hidden = false;
    document.body.classList.add('lock');
    setTimeout(function () { $('countryList').scrollTop = 0; }, 0);
  }
  function closeDrawer() {
    if ($('drawer').hidden) return false;
    $('drawer').hidden = true;
    document.body.classList.remove('lock');
    if (lastFocus && lastFocus.focus) lastFocus.focus();
    return true;
  }

  // ------------------------------------------------------------------ Sedang Diputar + Timer Tidur
  var SLEEP_OPTIONS = [0, 15, 30, 60, 90];
  var sleepTimer = null, sleepTick = null;
  function fmtLeft(ms) {
    var sec = Math.max(0, Math.round(ms / 1000)), h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), x = sec % 60;
    function two(n) { return (n < 10 ? '0' : '') + n; }
    return h ? h + ':' + two(m) + ':' + two(x) : m + ':' + two(x);
  }
  function setSleep(min, silent) {
    clearTimeout(sleepTimer);
    state.sleepEnd = min ? Date.now() + min * 60000 : 0;
    state.sleepMinutes = min || 0;
    // Di Android, layanan pemutar ikut menghitung agar tetap tepat saat aplikasi di latar belakang
    var bridge = window.FreqManAndroid;
    if (bridge && bridge.setSleepTimer) { try { bridge.setSleepTimer(min ? min * 60000 : 0); } catch (e) { /* abaikan */ } }
    if (min) {
      sleepTimer = setTimeout(sleepFired, min * 60000);
      if (!silent) toast('sleepSetTitle', T().sleepSetDesc(min), 'clock');
    }
    updateNowPlaying();
  }
  function sleepFired() {
    if (!state.sleepEnd) return;
    clearTimeout(sleepTimer);
    state.sleepEnd = 0; state.sleepMinutes = 0;
    if (state.playing || state.buffering) {
      teardown(); state.playing = false; state.buffering = false; syncPlayback();
    }
    toast('sleepEndTitle', 'sleepEndDesc', 'clock', true);
    updateNowPlaying();
  }

  function renderNowPlaying() {
    var s = state.current;
    if (!s) return;
    var t = T();
    var body = $('npBody');
    body.setAttribute('data-id', s.stationuuid);
    body.innerHTML =
      '<h2 id="npTitle" class="sr-only">' + esc(t.nowPlayingTitle) + '</h2>' +
      '<div class="np-art"><span' + mediaAttrs(s) + ' id="npMedia">' + mediaHtml(s, state.playing) + '</span></div>' +
      '<div class="np-info">' +
        '<div class="np-kicker"><span id="npKicker"></span><span id="npBadge"></span></div>' +
        '<div class="np-name">' + esc(stationName(s)) + '</div>' +
        '<div class="np-song" id="npSong"></div>' +
        '<div class="np-meta" id="npLoc"></div>' +
        '<div class="np-meta" id="npDetail"></div>' +
      '</div>' +
      '<div class="np-controls">' +
        '<button type="button" class="btn btn-outline btn-icon-lg" id="npFav"></button>' +
        '<button type="button" class="btn btn-default btn-icon-lg" id="npToggle"></button>' +
      '</div>' +
      '<section class="np-sleep">' +
        '<h3>' + esc(t.sleepTimer) + '</h3>' +
        '<div class="toggle-group np-sleep-group" role="radiogroup" aria-label="' + esc(t.sleepTimer) + '">' +
          SLEEP_OPTIONS.map(function (m) {
            return '<button type="button" role="radio" data-sleep="' + m + '">' + esc(m ? t.sleepMin(m) : t.sleepOff) + '</button>';
          }).join('') +
        '</div>' +
        '<p class="np-sleep-info" id="npSleepInfo"></p>' +
      '</section>';
    updateNowPlaying();
  }
  // Perbarui bagian yang berubah tanpa membangun ulang (logo tidak dimuat ulang)
  function updateNowPlaying() {
    if ($('np').hidden) return;
    var s = state.current;
    if (!s) { closeNp(); return; }
    var body = $('npBody');
    if (body.getAttribute('data-id') !== s.stationuuid) { renderNowPlaying(); return; }
    var t = T();
    setBars($('npMedia'), state.playing);
    $('npKicker').textContent = t.nowPlayingTitle;
    $('npBadge').innerHTML = (state.playing ? '<span class="badge badge-status badge-live"><span class="live-dot"></span>' + esc(t.live) + '</span>' : '') + qualityBadge(s);
    $('npSong').textContent = state.nowTitle ? '♪ ' + state.nowTitle : '';
    $('npSong').hidden = !state.nowTitle;
    $('npLoc').textContent = stationLocation(s) || t.liveBroadcast;
    var detail = stationDetail(s);
    $('npDetail').textContent = detail; $('npDetail').hidden = !detail;
    var fav = isFav(s.stationuuid);
    $('npFav').innerHTML = svg('heart', 16, { fill: fav });
    $('npFav').setAttribute('aria-pressed', String(fav));
    $('npFav').setAttribute('aria-label', fav ? t.removeFavorite : t.saveFavorite);
    var active = state.playing || state.buffering;
    $('npToggle').innerHTML = state.buffering ? svg('loader', 16, { cls: 'spinner' }) : svg(state.playing ? 'pause' : 'play', 16, { fill: true });
    $('npToggle').setAttribute('aria-label', active ? t.pause : t.play);
    Array.prototype.forEach.call(body.querySelectorAll('[data-sleep]'), function (b) {
      b.setAttribute('aria-checked', String(+b.getAttribute('data-sleep') === (state.sleepEnd ? state.sleepMinutes : 0)));
    });
    $('npSleepInfo').textContent = state.sleepEnd ? t.sleepLeft(fmtLeft(state.sleepEnd - Date.now())) : t.sleepIdle;
  }
  var npLastFocus = null;
  function openNp() {
    if (!state.current) return;
    npLastFocus = document.activeElement;
    $('np').hidden = false;
    document.body.classList.add('lock');
    renderNowPlaying();
    clearInterval(sleepTick);
    sleepTick = setInterval(function () { if (state.sleepEnd) updateNowPlaying(); }, 1000);
  }
  function closeNp() {
    if ($('np').hidden) return false;
    $('np').hidden = true;
    clearInterval(sleepTick);
    if ($('drawer').hidden && $('about').hidden) document.body.classList.remove('lock');
    if (npLastFocus && npLastFocus.focus) npLastFocus.focus();
    return true;
  }
  $('playerOpen').addEventListener('click', openNp);
  $('np').addEventListener('click', function (e) {
    if (e.target.closest('[data-close]')) { closeNp(); return; }
    var sl = e.target.closest('[data-sleep]');
    if (sl) { setSleep(+sl.getAttribute('data-sleep')); return; }
    if (e.target.closest('#npToggle')) { togglePlay(); return; }
    if (e.target.closest('#npFav') && state.current) { toggleFavorite(state.current); updateNowPlaying(); }
  });

  // ------------------------------------------------------------------ Tentang & Lisensi
  var LICENSES = [
    { name: 'Radio Browser', type: 'Public Domain', file: null, url: 'https://www.radio-browser.info' },
    { name: 'shadcn/ui', type: 'MIT', file: 'licenses/shadcn-ui-MIT.txt' }, // dasar desain antarmuka (warna, ukuran, gaya komponen)
    { name: 'Geist', type: 'SIL OFL 1.1', file: 'licenses/Geist-OFL.txt' },
    { name: 'Orbitron', type: 'SIL OFL 1.1', file: 'licenses/Orbitron-OFL.txt' },
    { name: 'Lucide Icons', type: 'ISC', file: 'licenses/Lucide-ISC.txt' },
    { name: 'hls.js', type: 'Apache 2.0', file: 'licenses/hlsjs-Apache-2.0.txt' }
  ];
  var EXTERNAL = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/></svg>';
  var CHEVRON = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>';
  function renderAbout() {
    var t = T();
    // Nama pengembang menjadi tautan email (subjek sudah terisi)
    var devName = CONTACT_EMAIL
      ? '<a href="mailto:' + esc(CONTACT_EMAIL) + '?subject=' + encodeURIComponent(t.ownersMailSubject) + '">' + esc(DEVELOPER) + '</a>'
      : esc(DEVELOPER);
    var contact = '<p>' + esc(t.ownersContact) + ' ' + devName + '.</p>';
    var rbLink = '<a href="https://www.radio-browser.info" target="_blank" rel="noopener">radio-browser.info</a>';
    var lic = LICENSES.map(function (l) {
      if (!l.file) {
        // Radio Browser: membuka situsnya (ikon tautan luar), bukan teks lisensi
        // Hanya ikon yang menjadi tautan; nama & lisensi teks biasa
        return '<div class="license"><div class="lic-link">' +
          '<span class="lic-name">' + esc(l.name) + '</span><span class="lic-type">' + esc(l.type) + '</span>' +
          '<a class="lic-ext" href="' + l.url + '" target="_blank" rel="noopener" aria-label="' + esc(l.name) + ': radio-browser.info">' + EXTERNAL + '</a>' +
          '</div></div>';
      }
      return '<details class="license" data-file="' + l.file + '"><summary><span class="lic-name">' + esc(l.name) + '</span><span class="lic-type">' + esc(l.type) + '</span>' + CHEVRON + '</summary><pre>' + esc(t.licenseLoading) + '</pre></details>';
    }).join('');
    $('aboutBody').innerHTML =
      '<div class="about-head">' +
        '<span class="mark" aria-hidden="true"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 10.5v3M8 7.5v9M12 4v16M16 7.5v9M20 10.5v3"/></svg></span>' +
        '<h2 id="aboutTitle" class="sr-only">' + esc(t.aboutTitle) + '</h2>' +
        '<span class="about-name">FREQMAN</span>' +
        '<span class="about-meta">Frequency Manager</span>' +
        '<span class="about-meta">' + esc(t.developedBy) + ' ' + esc(DEVELOPER) + '</span>' +
      '</div>' +
      '<section class="about-sec"><h3>' + esc(t.statementTitle) + '</h3><p>' + esc(t.statement1) + '</p><p>' + esc(t.statement2) + '</p></section>' +
      '<section class="about-sec"><h3>' + esc(t.sourceTitle) + '</h3><p>' + esc(t.source1) + ' <a href="https://www.radio-browser.info" target="_blank" rel="noopener">radio-browser.info</a></p></section>' +
      '<section class="about-sec"><h3>' + esc(t.ownersTitle) + '</h3><p>' + esc(t.owners1) + '</p>' + contact + '<p>' + esc(t.ownersFix) + ' ' + rbLink + '.</p></section>' +
      '<section class="about-sec"><h3>' + esc(t.privacyTitle) + '</h3><p>' + esc(t.privacy1) + '</p><p>' + esc(t.privacy2) + '</p></section>' +
      '<section class="about-sec"><h3>' + esc(t.licensesTitle) + '</h3><p>' + esc(t.licensesIntro) + '</p>' + lic + '</section>' +
      '<p class="about-copy">© 2026 FREQMAN. All Rights Reserved.<br>' + esc(t.version) + ' ' + APP_VERSION + '</p>';
    // Teks lisensi dimuat dari berkas yang ikut di dalam aplikasi saat dibuka
    Array.prototype.forEach.call($('aboutBody').querySelectorAll('details.license'), function (d) {
      d.addEventListener('toggle', function () {
        if (!d.open || d.getAttribute('data-loaded')) return;
        d.setAttribute('data-loaded', '1');
        fetch(d.getAttribute('data-file')).then(function (r) { return r.text(); })
          .then(function (txt) { d.querySelector('pre').textContent = txt; })
          .catch(function () { d.querySelector('pre').textContent = d.getAttribute('data-file'); });
      });
    });
  }
  var aboutLastFocus = null;
  function openAbout() {
    renderAbout();
    aboutLastFocus = document.activeElement;
    $('about').hidden = false;
    document.body.classList.add('lock');
    $('aboutBody').scrollTop = 0;
  }
  function closeAbout() {
    if ($('about').hidden) return false;
    $('about').hidden = true;
    if ($('drawer').hidden) document.body.classList.remove('lock');
    if (aboutLastFocus && aboutLastFocus.focus) aboutLastFocus.focus();
    return true;
  }
  $('aboutBtn').addEventListener('click', openAbout);
  $('about').addEventListener('click', function (e) { if (e.target.closest('[data-close]')) closeAbout(); });

  // Geser ke bawah untuk menutup laci negara (sentuh & mouse)
  function setupSheetSwipe(rootSel, scrollId, onClose) {
    var sheet = document.querySelector(rootSel + ' .drawer');
    var scrim = document.querySelector(rootSel + ' .scrim');
    var list = $(scrollId);
    var startY = 0, lastY = 0, lastT = 0, velocity = 0, dy = 0;
    var active = false, decided = false;

    function begin(y, target) {
      if (target.closest('input')) return false;
      var fromList = !!target.closest('#' + scrollId);
      if (fromList && list.scrollTop > 0) return false; // daftar sedang di-scroll
      active = true;
      decided = !fromList; // dari daftar: tunggu arah gerakan dulu
      startY = lastY = y; lastT = Date.now(); dy = 0; velocity = 0;
      return true;
    }
    function move(y, e) {
      if (!active) return;
      var delta = y - startY;
      if (!decided) {
        if (Math.abs(delta) < 6) return;
        if (delta < 0 || list.scrollTop > 0) { active = false; return; } // biarkan daftar scroll ke atas
        decided = true;
      }
      if (e && e.cancelable) e.preventDefault();
      var now = Date.now();
      velocity = (y - lastY) / Math.max(1, now - lastT);
      lastY = y; lastT = now;
      dy = Math.max(0, delta);
      sheet.classList.add('dragging');
      sheet.style.transform = 'translateY(' + dy + 'px)';
      scrim.style.opacity = String(Math.max(0, 1 - dy / sheet.offsetHeight));
    }
    function reset() {
      sheet.classList.remove('dragging', 'settling');
      scrim.classList.remove('settling');
      sheet.style.transform = '';
      scrim.style.opacity = '';
    }
    function end() {
      if (!active) return;
      active = false;
      if (!decided || dy === 0) { reset(); return; }
      sheet.classList.remove('dragging');
      sheet.classList.add('settling');
      scrim.classList.add('settling');
      var close = dy > Math.min(140, sheet.offsetHeight * 0.25) || velocity > 0.5;
      if (close) {
        sheet.style.transform = 'translateY(100%)';
        scrim.style.opacity = '0';
        setTimeout(function () { onClose(); reset(); }, 220);
      } else {
        sheet.style.transform = '';
        scrim.style.opacity = '';
        setTimeout(reset, 220);
      }
    }
    sheet.addEventListener('touchstart', function (e) { if (e.touches.length === 1) begin(e.touches[0].clientY, e.target); }, { passive: true });
    sheet.addEventListener('touchmove', function (e) { if (active) move(e.touches[0].clientY, e); }, { passive: false });
    sheet.addEventListener('touchend', end);
    sheet.addEventListener('touchcancel', end);
    sheet.addEventListener('mousedown', function (e) {
      if (!e.target.closest('.drawer-grab, .drawer-header, .about-head, .np-art')) return;
      if (begin(e.clientY, e.target)) e.preventDefault();
    });
    window.addEventListener('mousemove', function (e) { if (active) move(e.clientY, e); });
    window.addEventListener('mouseup', end);
  }
  setupSheetSwipe('#drawer', 'countryList', function () { closeDrawer(); });
  setupSheetSwipe('#about', 'aboutBody', function () { closeAbout(); });
  setupSheetSwipe('#np', 'npBody', function () { closeNp(); });

